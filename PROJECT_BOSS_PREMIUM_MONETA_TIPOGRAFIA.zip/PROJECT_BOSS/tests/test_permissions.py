from werkzeug.security import generate_password_hash

from app import db
from app.models.user import User


def test_viewer_cannot_access_admin(app, client):
    with app.app_context():
        viewer = User(name='Viewer', email='viewer@teste.com', role='viewer', is_active=True, password_hash=generate_password_hash('Viewer@123'))
        db.session.add(viewer)
        db.session.commit()
    client.post('/auth/login', data={'email': 'viewer@teste.com', 'password': 'Viewer@123'}, follow_redirects=False)
    response = client.get('/admin/users', follow_redirects=False)
    assert response.status_code in (302, 403)

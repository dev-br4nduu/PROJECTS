from datetime import date, timedelta

from app import db
from app.models.core import InsuranceType, Vehicle
from app.models.insurance import Policy
from app.services.business_rules import validate_policy_business_rules
from app.services.dashboard_service import build_dashboard_snapshot


def test_policy_auto_requires_vehicle_and_insurer(app):
    with app.app_context():
        client = db.session.execute(db.select(__import__('app.models.core', fromlist=['Client']).Client).filter_by(document='12345678901')).scalar_one()
        auto = InsuranceType.query.filter_by(name='Seguro Auto').first()
        policy = Policy(
            client_id=client.id, insurance_type_id=auto.id, title='Teste Auto', policy_number='POL-VAL-01',
            status='ativa', starts_at=date.today(), ends_at=date.today() + timedelta(days=30)
        )
        errors = validate_policy_business_rules(policy)
        assert any('veículo' in e.lower() for e in errors)
        assert any('seguradora' in e.lower() for e in errors)


def test_policy_vehicle_must_belong_to_client(app):
    with app.app_context():
        from app.models.core import Client, Insurer
        other = Client(full_name='Outro Cliente', client_type='pf', document='99988877766', status='ativo')
        db.session.add(other)
        db.session.flush()
        vehicle = Vehicle(client_id=other.id, brand='VW', model='Gol', plate='ABC1234')
        insurer = Insurer.query.filter_by(name='Porto').first()
        auto = InsuranceType.query.filter_by(name='Seguro Auto').first()
        db.session.add(vehicle)
        db.session.commit()
        client = Client.query.filter_by(document='12345678901').first()
        policy = Policy(
            client_id=client.id, vehicle_id=vehicle.id, insurance_type_id=auto.id, insurer_id=insurer.id,
            title='Teste Auto 2', policy_number='POL-VAL-02', status='ativa',
            starts_at=date.today(), ends_at=date.today() + timedelta(days=30)
        )
        errors = validate_policy_business_rules(policy)
        assert any('não pertence ao cliente' in e.lower() for e in errors)


def test_dashboard_snapshot_has_expected_kpis(app):
    with app.app_context():
        stats, *_ = build_dashboard_snapshot()
        assert 'proposals_waiting' in stats
        assert 'renewal_success_pct' in stats
        assert 'Convênio Médico' in stats['line_stats']

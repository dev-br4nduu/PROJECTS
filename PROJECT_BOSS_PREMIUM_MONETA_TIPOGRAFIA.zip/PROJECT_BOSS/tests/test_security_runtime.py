from datetime import datetime, timedelta

from app import db
from app.models.user import User


def test_health_storage_endpoint(client):
    response = client.get('/health/storage')
    assert response.status_code in (200, 503)
    assert b'status' in response.data


def test_login_lockout_after_multiple_failures(app, client):
    for _ in range(5):
        client.post('/auth/login', data={'email': 'admin@teste.com', 'password': 'senha-errada'}, follow_redirects=True)

    with app.app_context():
        user = User.query.filter_by(email='admin@teste.com').first()
        assert user.locked_until is not None
        assert user.locked_until > datetime.utcnow()


def test_unlock_user_cli(app):
    runner = app.test_cli_runner()
    with app.app_context():
        user = User.query.filter_by(email='admin@teste.com').first()
        user.locked_until = datetime.utcnow() + timedelta(minutes=10)
        db.session.commit()
    result = runner.invoke(args=['unlock-user', 'admin@teste.com'])
    assert result.exit_code == 0
    with app.app_context():
        user = User.query.filter_by(email='admin@teste.com').first()
        assert user.locked_until is None

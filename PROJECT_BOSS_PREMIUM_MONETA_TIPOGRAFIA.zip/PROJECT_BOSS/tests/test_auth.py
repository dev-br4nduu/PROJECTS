from app.models.user import User
from app.services.email_service import generate_password_reset_token, verify_password_reset_token


def test_login_page_loads(client):
    response = client.get('/auth/login')
    assert response.status_code == 200
    assert b'Entrar' in response.data


def test_login_success_redirects(client):
    response = client.post('/auth/login', data={'email': 'admin@teste.com', 'password': 'Admin@123'}, follow_redirects=False)
    assert response.status_code in (302, 303)
    assert response.headers['Location'].endswith('/')


def test_password_reset_token_roundtrip(app):
    with app.app_context():
        user = User.query.filter_by(email='admin@teste.com').first()
        token = generate_password_reset_token(user)
        loaded = verify_password_reset_token(token)
        assert loaded is not None
        assert loaded.email == user.email

def test_dashboard_requires_login(client):
    response = client.get('/', follow_redirects=False)
    assert response.status_code in (302, 401)


def test_dashboard_loads_when_authenticated(logged_client):
    response = logged_client.get('/')
    assert response.status_code == 200
    assert b'Dashboard' in response.data or b'KPI' in response.data or b'Clientes' in response.data


def test_health_and_ready(client):
    assert client.get('/health').status_code == 200
    ready = client.get('/ready')
    assert ready.status_code in (200, 503)

from app.services.saas_service import ensure_default_plans, provision_organization_from_signup
from app.models.core import Organization, SaaSPlan, OrganizationSubscription
from app.models.user import User


def test_seed_plans(app):
    with app.app_context():
        ensure_default_plans()
        assert SaaSPlan.query.filter_by(code='pro').first() is not None


def test_provision_workspace(app):
    with app.app_context():
        ensure_default_plans()
        org, admin, sub = provision_organization_from_signup(organization_name='Acme', organization_slug='acme', contact_name='Owner', contact_email='owner@acme.test', password='Owner@12345', plan_code='pro')
        assert Organization.query.filter_by(slug='acme').first() is not None
        assert User.query.filter_by(email='owner@acme.test', organization_id=org.id).first() is not None
        assert OrganizationSubscription.query.filter_by(organization_id=org.id).first() is not None

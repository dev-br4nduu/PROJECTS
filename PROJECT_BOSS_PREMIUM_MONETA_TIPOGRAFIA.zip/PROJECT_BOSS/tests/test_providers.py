from app import db
from app.models.core import Insurer, MedicalOperator


def test_admin_can_open_providers_page(logged_client):
    response = logged_client.get('/admin/providers')
    assert response.status_code == 200
    assert b'Empresas parceiras' in response.data


def test_create_provider_records(app, logged_client):
    response = logged_client.post('/admin/providers/insurers/new', data={
        'name': 'Tokio Marine',
        'legal_name': 'Tokio Marine Seguradora SA',
        'document': '12345678000199',
        'contact_name': 'Comercial',
        'email': 'comercial@tokio.test',
        'phone': '1130000000',
        'whatsapp': '11999999999',
        'website': 'https://tokio.test',
        'is_active': 'y',
        'notes': 'Parceira teste'
    }, follow_redirects=False)
    assert response.status_code in (302, 303)
    with app.app_context():
        assert Insurer.query.filter_by(name='Tokio Marine').first() is not None

    response = logged_client.post('/admin/providers/operators/new', data={
        'name': 'Unimed',
        'legal_name': 'Unimed Teste',
        'document': '99887766000111',
        'email': 'relacionamento@unimed.test',
        'is_active': 'y',
    }, follow_redirects=False)
    assert response.status_code in (302, 303)
    with app.app_context():
        assert MedicalOperator.query.filter_by(name='Unimed').first() is not None

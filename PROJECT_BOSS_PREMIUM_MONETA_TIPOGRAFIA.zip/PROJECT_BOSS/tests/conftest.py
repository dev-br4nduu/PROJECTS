import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pytest
from werkzeug.security import generate_password_hash

from app import create_app, db
from app.models.user import User
from app.models.core import Client, InsuranceType, Insurer
from app.models.insurance import Policy
from config import Config


class TestConfig(Config):
    TESTING = True
    WTF_CSRF_ENABLED = False
    LOGIN_DISABLED = False
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    SECRET_KEY = "test-secret-key"
    SERVER_NAME = "localhost.localdomain"


@pytest.fixture()
def app():
    app = create_app(TestConfig)
    with app.app_context():
        db.create_all()
        admin = User(
            name="Admin Teste",
            email="admin@teste.com",
            role="admin",
            is_active=True,
            password_hash=generate_password_hash("Admin@123"),
        )
        insurance_type = InsuranceType(name="Seguro Auto")
        insurer = Insurer(name="Porto")
        client = Client(full_name="Cliente Teste", client_type="pf", document="12345678901", status="ativo", email="cliente@teste.com")
        db.session.add_all([admin, insurance_type, insurer, client])
        db.session.flush()
        policy = Policy(
            client_id=client.id,
            insurance_type_id=insurance_type.id,
            insurer_id=insurer.id,
            title="Apólice Teste",
            policy_number="POL-001",
            status="ativa",
            starts_at=__import__("datetime").date.today(),
            ends_at=__import__("datetime").date.today(),
        )
        db.session.add(policy)
        db.session.commit()
        yield app
        db.session.remove()
        db.drop_all()


@pytest.fixture()
def client(app):
    return app.test_client()


@pytest.fixture()
def logged_client(client):
    response = client.post(
        "/auth/login",
        data={"email": "admin@teste.com", "password": "Admin@123", "remember": "y"},
        follow_redirects=False,
    )
    assert response.status_code in (302, 303)
    return client

from app.models.core import Organization
from app.models.user import User


def test_workspace_slug_unique(app):
    with app.app_context():
        org = Organization(name='Boss', slug='boss-default', is_active=True)
        app.extensions['sqlalchemy'].db.session.add(org)
        app.extensions['sqlalchemy'].db.session.commit()
        assert Organization.query.filter_by(slug='boss-default').count() == 1

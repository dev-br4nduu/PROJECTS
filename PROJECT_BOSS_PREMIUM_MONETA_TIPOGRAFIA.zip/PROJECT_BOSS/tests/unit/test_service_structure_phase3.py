from pathlib import Path


def test_phase3_services_exist():
    base = Path("app/services")
    expected = {
        "admin_service.py",
        "crm_service.py",
        "import_app_service.py",
        "report_service.py",
    }
    assert expected.issubset({item.name for item in base.iterdir()})


def test_phase3_repositories_exist():
    base = Path("app/repositories")
    expected = {
        "admin.py",
        "crm.py",
        "import_batches.py",
    }
    assert expected.issubset({item.name for item in base.iterdir()})

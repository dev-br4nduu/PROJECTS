from pathlib import Path


def test_repository_layer_exists():
    assert Path("app/repositories/clients.py").exists()
    assert Path("app/repositories/policies.py").exists()


def test_service_layer_exists():
    assert Path("app/services/client_service.py").exists()
    assert Path("app/services/policy_service.py").exists()

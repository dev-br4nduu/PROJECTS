from app import create_app
from config.testing import TestingConfig


def test_create_app():
    app = create_app(TestingConfig)
    assert app.config["TESTING"] is True
    assert "clients" in app.blueprints
    assert "policies" in app.blueprints

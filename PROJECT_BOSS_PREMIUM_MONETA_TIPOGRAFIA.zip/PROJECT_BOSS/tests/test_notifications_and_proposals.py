from datetime import date, timedelta

from app import db
from app.models.core import AuditLog, Client
from app.models.insurance import NotificationLog, Policy, Renewal
from app.models.user import User
from app.services.notification_service import process_due_notifications
from app.services.proposal_service import build_whatsapp_link


def test_process_due_notifications_sends_internal_and_client(app, monkeypatch):
    sent = []

    def fake_send_email(subject, recipients, html_body, text_body=None, attachments=None):
        sent.append({
            "subject": subject,
            "recipients": recipients,
            "text": text_body,
            "attachments": attachments or [],
        })

    monkeypatch.setattr("app.services.notification_service.send_email", fake_send_email)

    with app.app_context():
        admin = User.query.filter_by(email="admin@teste.com").first()
        policy = Policy.query.filter_by(policy_number="POL-001").first()
        policy.ends_at = date.today() + timedelta(days=20)
        policy.assigned_user_id = admin.id
        policy.client.secondary_email = "secundario@teste.com"
        db.session.add(policy)
        db.session.commit()

        created = process_due_notifications()
        db.session.expire_all()

        assert created == 3
        assert len(sent) == 3
        logs = NotificationLog.query.filter_by(policy_id=policy.id).all()
        assert len(logs) == 3
        assert any(item.notification_type == "internal_due_policy" for item in logs)
        assert sum(1 for item in logs if item.notification_type == "due_policy") == 2


def test_process_due_notifications_stops_due_flow_when_renewed(app, monkeypatch):
    sent = []

    def fake_send_email(subject, recipients, html_body, text_body=None, attachments=None):
        sent.append({"subject": subject, "recipients": recipients})

    monkeypatch.setattr("app.services.notification_service.send_email", fake_send_email)

    with app.app_context():
        policy = Policy.query.filter_by(policy_number="POL-001").first()
        policy.ends_at = date.today() + timedelta(days=10)
        policy.client.secondary_email = "secundario@teste.com"
        renewal = Renewal(client_id=policy.client_id, policy_id=policy.id, stage="renovado")
        db.session.add(renewal)
        db.session.commit()

        created = process_due_notifications()
        db.session.expire_all()

        assert created == 2
        assert len(sent) == 2
        logs = NotificationLog.query.filter_by(policy_id=policy.id, notification_type="renewal_success").all()
        assert len(logs) == 2
        assert NotificationLog.query.filter_by(policy_id=policy.id, notification_type="due_policy").count() == 0


def test_build_whatsapp_link_normalizes_number(app):
    with app.app_context():
        link = build_whatsapp_link("(11) 99888-7766", "Olá Boss")
        assert link.startswith("https://wa.me/5511998887766")
        assert "Ol%C3%A1%20Boss" in link


def test_view_policy_email_flow_records_audit(app, logged_client, monkeypatch):
    captured = {}

    def fake_send_proposal_email(recipient, subject, message_html, message_text, attachment_path=None):
        captured.update({
            "recipient": recipient,
            "subject": subject,
            "message_text": message_text,
            "attachment_path": attachment_path,
        })

    monkeypatch.setattr("app.blueprints.policies.routes.send_proposal_email", fake_send_proposal_email)

    response = logged_client.post(
        "/policies/1",
        data={
            "recipient_email": "cliente@teste.com",
            "recipient_whatsapp": "11999990000",
            "message": "Segue sua proposta em anexo.",
            "submit_email": True,
        },
        follow_redirects=True,
    )

    assert response.status_code == 200
    assert b"Proposta enviada por e-mail com sucesso" in response.data
    assert captured["recipient"] == "cliente@teste.com"
    assert "POL-001" in captured["subject"]

    with app.app_context():
        log = AuditLog.query.filter_by(action="proposal_email", entity="policy", entity_id="1").first()
        assert log is not None


def test_view_policy_whatsapp_redirect(app, logged_client):
    response = logged_client.post(
        "/policies/1",
        data={
            "recipient_email": "cliente@teste.com",
            "recipient_whatsapp": "(11) 98888-7766",
            "message": "Olá cliente",
            "submit_whatsapp": True,
        },
        follow_redirects=False,
    )
    assert response.status_code in (302, 303)
    assert response.headers["Location"].startswith("https://wa.me/")

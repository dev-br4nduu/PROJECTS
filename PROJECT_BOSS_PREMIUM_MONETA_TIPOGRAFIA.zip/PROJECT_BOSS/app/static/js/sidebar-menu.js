/**
 * Menu lateral em cascata + modo compacto (ícones).
 * Um grupo aberto por vez (acordeão) ao expandir manualmente.
 * Persistência: sessionStorage (grupos abertos + barra recolhida).
 */
(function () {
  "use strict";

  var STORAGE_KEY = "boss_sidebar_v1";
  var sidebar = document.getElementById("app-sidebar");
  if (!sidebar) return;

  function loadState() {
    try {
      return JSON.parse(sessionStorage.getItem(STORAGE_KEY) || "{}");
    } catch (e) {
      return {};
    }
  }

  function saveState(state) {
    try {
      sessionStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {}
  }

  function syncBodyCollapsed() {
    var c = sidebar.classList.contains("sidebar--collapsed");
    document.body.classList.toggle("sidebar-collapsed", c);
  }

  function closeOtherGroups(exceptAcc, state) {
    var all = sidebar.querySelectorAll(".sidebar-accordion[data-group-id]");
    state.openGroups = state.openGroups || {};
    all.forEach(function (other) {
      if (other === exceptAcc) return;
      var oid = other.getAttribute("data-group-id");
      var obtn = other.querySelector(".sidebar-group-toggle");
      var opanel = other.querySelector(".sidebar-group-panel");
      other.classList.remove("sidebar-group--open");
      if (obtn) obtn.setAttribute("aria-expanded", "false");
      if (opanel) opanel.hidden = true;
      if (oid) state.openGroups[oid] = false;
    });
  }

  var state = loadState();

  var groups = sidebar.querySelectorAll(".sidebar-accordion[data-group-id]");
  groups.forEach(function (acc) {
    var id = acc.getAttribute("data-group-id");
    var btn = acc.querySelector(".sidebar-group-toggle");
    var panel = acc.querySelector(".sidebar-group-panel");
    if (!btn || !panel) return;

    var hasPersisted =
      state.openGroups && Object.prototype.hasOwnProperty.call(state.openGroups, id);
    var shouldOpen;
    if (hasPersisted) {
      shouldOpen = state.openGroups[id] === true;
    } else {
      shouldOpen = acc.classList.contains("sidebar-group--default-open");
    }

    function setOpen(open) {
      acc.classList.toggle("sidebar-group--open", open);
      btn.setAttribute("aria-expanded", open ? "true" : "false");
      panel.hidden = !open;
    }

    setOpen(shouldOpen);

    btn.addEventListener("click", function () {
      if (sidebar.classList.contains("sidebar--collapsed")) {
        sidebar.classList.remove("sidebar--collapsed");
        state.collapsed = false;
        saveState(state);
        syncBodyCollapsed();
        closeOtherGroups(acc, state);
        setOpen(true);
        state.openGroups = state.openGroups || {};
        state.openGroups[id] = true;
        saveState(state);
        return;
      }
      var open = !acc.classList.contains("sidebar-group--open");
      if (open) {
        closeOtherGroups(acc, state);
      }
      setOpen(open);
      state.openGroups = state.openGroups || {};
      state.openGroups[id] = open;
      saveState(state);
    });
  });

  var collapseBtn = document.getElementById("sidebar-collapse-toggle");
  if (collapseBtn) {
    if (state.collapsed === true) {
      sidebar.classList.add("sidebar--collapsed");
    }
    syncBodyCollapsed();

    collapseBtn.addEventListener("click", function () {
      sidebar.classList.toggle("sidebar--collapsed");
      state.collapsed = sidebar.classList.contains("sidebar--collapsed");
      saveState(state);
      syncBodyCollapsed();
    });
  }
})();

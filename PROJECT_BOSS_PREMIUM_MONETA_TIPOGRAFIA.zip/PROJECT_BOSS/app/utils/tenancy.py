from functools import wraps
from flask import abort, g, request, current_app
from flask_login import current_user
from sqlalchemy import inspect
from app.models.core import Organization


def current_organization_id():
    return getattr(current_user, "organization_id", None) if getattr(current_user, "is_authenticated", False) else None


def current_organization_name():
    if getattr(current_user, "is_authenticated", False) and getattr(current_user, "organization", None):
        return current_user.organization.name
    org = get_request_organization()
    return org.name if org else None


def get_request_organization_slug():
    slug = getattr(g, "request_organization_slug", None)
    if slug:
        return slug
    slug = (request.args.get("org") or request.headers.get("X-Org-Slug") or "").strip().lower()
    if slug:
        return slug
    if current_app.config.get("TENANT_STRATEGY", "path") == "subdomain":
        host = (request.host or "").split(":")[0].lower()
        root_host = (current_app.config.get("ROOT_HOST") or "").lower().strip()
        if root_host and host.endswith(root_host) and host != root_host:
            sub = host[:-(len(root_host))].rstrip('.')
            if sub and sub not in {"www", "app"}:
                return sub
    return (current_app.config.get("DEFAULT_ORGANIZATION_SLUG") or "").strip().lower() or None


def get_request_organization():
    org = getattr(g, "request_organization", None)
    if org is not None:
        return org
    slug = get_request_organization_slug()
    if not slug:
        return None
    org = Organization.query.filter_by(slug=slug, is_deleted=False).first()
    g.request_organization = org
    g.request_organization_slug = slug
    return org


def _resolve_model_and_query(model_or_query, query=None):
    """Aceita tanto scoped_query(Model) quanto scoped_query(Query) ou scoped_query(Model, Query)."""
    if query is not None:
        return model_or_query, query

    try:
        mapper = inspect(model_or_query)
        if hasattr(mapper, "columns"):
            return model_or_query, model_or_query.query
    except Exception:
        pass

    query_obj = model_or_query
    entity = None
    for desc in getattr(query_obj, "column_descriptions", []) or []:
        candidate = desc.get("entity")
        if candidate is not None:
            entity = candidate
            break
    return entity, query_obj


def is_tenant_model(model):
    if model is None:
        return False
    try:
        return "organization_id" in inspect(model).columns
    except Exception:
        return False


def scoped_query(model_or_query, query=None):
    model, query_obj = _resolve_model_and_query(model_or_query, query=query)
    org_id = current_organization_id()
    if not org_id:
        request_org = get_request_organization()
        org_id = request_org.id if request_org else None
    if org_id and is_tenant_model(model):
        query_obj = query_obj.filter(model.organization_id == org_id)
    return query_obj


def assign_organization(instance, org_id=None):
    org_id = org_id or current_organization_id()
    if not org_id:
        request_org = get_request_organization()
        org_id = request_org.id if request_org else None
    if org_id and hasattr(instance, "organization_id") and not getattr(instance, "organization_id", None):
        instance.organization_id = org_id
    return instance


def assert_same_org(instance):
    org_id = current_organization_id()
    if not org_id:
        request_org = get_request_organization()
        org_id = request_org.id if request_org else None
    if org_id and hasattr(instance, "organization_id") and getattr(instance, "organization_id", None) != org_id:
        abort(404)
    return instance


def organization_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not (current_organization_id() or get_request_organization()):
            abort(403)
        return func(*args, **kwargs)
    return wrapper

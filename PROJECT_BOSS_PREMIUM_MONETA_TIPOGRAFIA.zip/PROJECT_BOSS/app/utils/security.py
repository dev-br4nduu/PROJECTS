from functools import wraps
from flask import flash, redirect, url_for
from flask_login import current_user

ROLE_HIERARCHY = {
    "viewer": 1,
    "assistant": 2,
    "broker": 3,
    "manager": 4,
    "admin": 5,
    "platform_admin": 6,
}

PERMISSIONS = {
    "dashboard.view": "viewer",
    "clients.view": "viewer",
    "clients.edit": "assistant",
    "policies.view": "viewer",
    "policies.edit": "assistant",
    "renewals.view": "viewer",
    "renewals.edit": "broker",
    "claims.view": "viewer",
    "claims.edit": "assistant",
    "claims.manage": "broker",
    "documents.view": "viewer",
    "documents.edit": "assistant",
    "imports.run": "manager",
    "reports.view": "manager",
    "smtp.manage": "manager",
    "users.manage": "admin",
    "providers.manage": "manager",
    "agenda.view": "viewer",
    "logs.view": "manager",
    "organizations.manage": "platform_admin",
}


def has_minimum_role(user, minimum_role: str) -> bool:
    if not user or not getattr(user, "is_authenticated", False):
        return False
    return ROLE_HIERARCHY.get(getattr(user, "role", "viewer"), 0) >= ROLE_HIERARCHY.get(minimum_role, 999)


def can_access(user, permission_key: str) -> bool:
    minimum_role = PERMISSIONS.get(permission_key)
    if not minimum_role:
        return False
    return has_minimum_role(user, minimum_role)


def role_required(minimum_role: str):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if not has_minimum_role(current_user, minimum_role):
                flash("Seu perfil não possui permissão para acessar este recurso.", "danger")
                return redirect(url_for("dashboard.index"))
            return func(*args, **kwargs)
        return wrapper
    return decorator


def permission_required(permission_key: str):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if not can_access(current_user, permission_key):
                flash("Seu perfil não possui permissão para executar esta ação.", "danger")
                return redirect(url_for("dashboard.index"))
            return func(*args, **kwargs)
        return wrapper
    return decorator

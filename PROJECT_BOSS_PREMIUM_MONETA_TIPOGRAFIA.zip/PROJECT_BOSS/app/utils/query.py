from flask import request

def get_page(default=1):
    try:
        page = int(request.args.get("page", default))
        return page if page > 0 else default
    except (TypeError, ValueError):
        return default

def get_per_page(default=15, maximum=100):
    try:
        value = int(request.args.get("per_page", default))
        value = default if value <= 0 else value
        return min(value, maximum)
    except (TypeError, ValueError):
        return default

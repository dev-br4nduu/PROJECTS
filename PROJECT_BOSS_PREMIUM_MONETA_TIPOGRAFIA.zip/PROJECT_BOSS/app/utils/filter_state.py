from __future__ import annotations
from flask import request, session


def bind_filter_state(namespace: str, allowed_keys: list[str], reset_param: str = "clear_filters") -> dict:
    key = f"filters:{namespace}"
    if request.args.get(reset_param):
        session.pop(key, None)
        return {k: "" for k in allowed_keys}
    incoming = {k: request.args.get(k, "") for k in allowed_keys if k in request.args}
    if incoming:
        session[key] = incoming
        return {k: incoming.get(k, "") for k in allowed_keys}
    stored = session.get(key, {})
    return {k: stored.get(k, "") for k in allowed_keys}

"""
Constantes alinhadas ao escopo funcional (tipos de produto e slugs de URL).
Nomes devem coincidir com os registros seed (seed-admin / ensure_admin_and_lookups).
"""
# slug na URL -> nome exato em insurance_types.name
INSURANCE_LINE_SLUGS = {
    "auto": "Seguro Auto",
    "saude": "Convênio Médico",
    "residencial": "Seguro Residencial",
    "eletro": "Eletro / Eletrodomésticos",
}

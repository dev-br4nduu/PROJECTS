from __future__ import annotations

from app.constants import INSURANCE_LINE_SLUGS
from app.models.core import Client, InsuranceType, Insurer, MedicalOperator, DocumentFile
from app.models.insurance import Policy
from app.repositories.base import SQLAlchemyRepository


class PolicyRepository(SQLAlchemyRepository):
    model = Policy

    def base_query(self):
        return Policy.query.join(Client).filter(
            Policy.is_deleted.is_(False),
            Client.is_deleted.is_(False),
        )

    def list_filtered(
        self,
        *,
        q: str = "",
        status: str = "",
        insurer: str = "",
        provider: str = "",
        line: str = "",
    ):
        query = self.base_query()
        line_title = None

        if line in INSURANCE_LINE_SLUGS:
            line_title = INSURANCE_LINE_SLUGS[line]
            query = query.join(
                InsuranceType,
                Policy.insurance_type_id == InsuranceType.id,
            ).filter(InsuranceType.name == line_title)

        if q:
            like = f"%{q}%"
            query = query.filter(
                (Policy.policy_number.ilike(like))
                | (Client.full_name.ilike(like))
                | (Policy.title.ilike(like))
            )
        if status:
            query = query.filter(Policy.status == status)
        if insurer:
            query = query.join(Insurer, Policy.insurer_id == Insurer.id, isouter=True).filter(
                Insurer.name == insurer
            )
        if provider:
            provider_type, _, provider_id = provider.partition(":")
            if provider_type == "insurer" and provider_id.isdigit():
                query = query.filter(Policy.insurer_id == int(provider_id))
            elif provider_type == "operator" and provider_id.isdigit():
                query = query.filter(Policy.operator_id == int(provider_id))

        return query, line_title

    def get_active_or_404(self, policy_id: int):
        return Policy.query.filter_by(id=policy_id, is_deleted=False).first_or_404()

    def provider_options(self):
        return (
            [("insurer:%s" % x.id, f"Seguradora • {x.name}") for x in Insurer.query.filter_by(is_deleted=False).order_by(Insurer.name).all()]
            + [("operator:%s" % x.id, f"Saúde • {x.name}") for x in MedicalOperator.query.filter_by(is_deleted=False).order_by(MedicalOperator.name).all()]
        )

    def latest_proposal_document(self, policy_id: int):
        return (
            DocumentFile.query.filter_by(policy_id=policy_id, is_deleted=False, category="proposta")
            .order_by(DocumentFile.id.desc())
            .first()
        )

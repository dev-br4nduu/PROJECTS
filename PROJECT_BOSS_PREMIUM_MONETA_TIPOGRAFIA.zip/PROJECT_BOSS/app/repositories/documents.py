from __future__ import annotations

from app.models.core import Claim, Client, DocumentFile
from app.models.insurance import Policy
from app.repositories.base import SQLAlchemyRepository
from app.utils.tenancy import scoped_query


class DocumentRepository(SQLAlchemyRepository):
    model = DocumentFile

    def base_query(self):
        return scoped_query(DocumentFile.query.join(Client)).filter(
            DocumentFile.is_deleted.is_(False),
            Client.is_deleted.is_(False),
        )

    def list_filtered(self, *, q: str = "", category: str = ""):
        query = self.base_query()
        if q:
            like = f"%{q}%"
            query = query.filter(
                (DocumentFile.file_name.ilike(like))
                | (Client.full_name.ilike(like))
                | (DocumentFile.category.ilike(like))
            )
        if category:
            query = query.filter(DocumentFile.category == category)
        return query

    def get_active_or_404(self, document_id: int):
        return self.base_query().filter(DocumentFile.id == document_id).first_or_404()

    def get_form_choices(self):
        clients = [
            (c.id, c.full_name)
            for c in scoped_query(Client).filter_by(is_deleted=False).order_by(Client.full_name).all()
        ]
        policies = [(0, "Sem vínculo")] + [
            (p.id, f"{p.policy_number} - {p.client.full_name}")
            for p in scoped_query(Policy).filter_by(is_deleted=False).order_by(Policy.policy_number).all()
        ]
        claims = [(0, "Sem vínculo")] + [
            (c.id, f"{c.claim_number} - {c.client.full_name}")
            for c in scoped_query(Claim).filter_by(is_deleted=False).order_by(Claim.claim_number).all()
        ]
        return {"client_id": clients, "policy_id": policies, "claim_id": claims}

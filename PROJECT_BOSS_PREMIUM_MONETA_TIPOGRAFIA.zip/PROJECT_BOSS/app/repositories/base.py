"""Abstrações simples de repositório para SQLAlchemy."""
from __future__ import annotations

from app.extensions import db


class SQLAlchemyRepository:
    model = None

    def save(self, entity, *, flush: bool = False):
        db.session.add(entity)
        if flush:
            db.session.flush()
        return entity

    def delete(self, entity):
        db.session.delete(entity)

    def commit(self):
        db.session.commit()

from __future__ import annotations

from app.models.core import Insurer, MedicalOperator
from app.models.insurance import Policy, Renewal
from app.repositories.base import SQLAlchemyRepository
from app.utils.tenancy import scoped_query


class RenewalRepository(SQLAlchemyRepository):
    model = Renewal

    def base_query(self):
        return scoped_query(Renewal)

    def list_filtered(self, *, provider: str = ""):
        query = self.base_query()
        if provider:
            provider_type, _, provider_id = provider.partition(":")
            query = query.join(Policy, Renewal.policy_id == Policy.id)
            if provider_type == "insurer" and provider_id.isdigit():
                query = query.filter(Policy.insurer_id == int(provider_id))
            elif provider_type == "operator" and provider_id.isdigit():
                query = query.filter(Policy.operator_id == int(provider_id))
        return query

    def get_or_404(self, renewal_id: int):
        return self.base_query().filter(Renewal.id == renewal_id).first_or_404()

    def provider_choices(self):
        insurers = [
            (f"insurer:{x.id}", f"Seguradora • {x.name}")
            for x in scoped_query(Insurer).filter_by(is_deleted=False).order_by(Insurer.name).all()
        ]
        operators = [
            (f"operator:{x.id}", f"Saúde • {x.name}")
            for x in scoped_query(MedicalOperator).filter_by(is_deleted=False).order_by(MedicalOperator.name).all()
        ]
        return insurers + operators

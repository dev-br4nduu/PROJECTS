from __future__ import annotations

from app.models.core import Client
from app.repositories.base import SQLAlchemyRepository
from app.utils.tenancy import scoped_query


class ClientRepository(SQLAlchemyRepository):
    model = Client

    def base_query(self):
        return scoped_query(Client).filter_by(is_deleted=False)

    def list_filtered(self, *, q: str = "", status: str = ""):
        query = self.base_query()
        if q:
            like = f"%{q}%"
            query = query.filter(
                (Client.full_name.ilike(like))
                | (Client.document.ilike(like))
                | (Client.email.ilike(like))
            )
        if status:
            query = query.filter(Client.status == status)
        return query

    def get_active_or_404(self, client_id: int):
        return self.base_query().filter_by(id=client_id).first_or_404()

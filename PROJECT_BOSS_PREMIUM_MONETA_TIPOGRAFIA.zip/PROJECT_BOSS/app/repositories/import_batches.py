from __future__ import annotations

from app.models.core import ImportBatch
from app.repositories.base import SQLAlchemyRepository
from app.utils.tenancy import scoped_query


class ImportBatchRepository(SQLAlchemyRepository):
    model = ImportBatch

    def recent(self, limit: int = 20):
        return scoped_query(ImportBatch).order_by(ImportBatch.created_at.desc()).limit(limit).all()

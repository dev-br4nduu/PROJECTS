from __future__ import annotations

from app.models.core import Claim, Client, Insurer, MedicalOperator
from app.models.insurance import Policy
from app.repositories.base import SQLAlchemyRepository
from app.utils.tenancy import scoped_query


class ClaimRepository(SQLAlchemyRepository):
    model = Claim

    def base_query(self):
        return scoped_query(Claim.query.join(Client)).filter(
            Claim.is_deleted.is_(False),
            Client.is_deleted.is_(False),
        )

    def list_filtered(self, *, q: str = "", status: str = "", provider: str = ""):
        query = self.base_query()
        if q:
            like = f"%{q}%"
            query = query.filter(
                (Claim.claim_number.ilike(like))
                | (Client.full_name.ilike(like))
                | (Claim.occurrence_type.ilike(like))
            )
        if status:
            query = query.filter(Claim.status == status)
        if provider:
            provider_type, _, provider_id = provider.partition(":")
            query = query.join(Policy, Claim.policy_id == Policy.id, isouter=True)
            if provider_type == "insurer" and provider_id.isdigit():
                query = query.filter(Policy.insurer_id == int(provider_id))
            elif provider_type == "operator" and provider_id.isdigit():
                query = query.filter(Policy.operator_id == int(provider_id))
        return query

    def get_active_or_404(self, claim_id: int):
        return self.base_query().filter(Claim.id == claim_id).first_or_404()

    def provider_choices(self):
        insurers = [
            (f"insurer:{x.id}", f"Seguradora • {x.name}")
            for x in scoped_query(Insurer).filter_by(is_deleted=False).order_by(Insurer.name).all()
        ]
        operators = [
            (f"operator:{x.id}", f"Saúde • {x.name}")
            for x in scoped_query(MedicalOperator).filter_by(is_deleted=False).order_by(MedicalOperator.name).all()
        ]
        return insurers + operators

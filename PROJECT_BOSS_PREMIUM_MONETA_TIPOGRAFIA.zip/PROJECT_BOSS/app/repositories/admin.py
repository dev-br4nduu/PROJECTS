from __future__ import annotations

from sqlalchemy import func

from app.models.core import (
    Organization,
    OrganizationSubscription,
    ProviderInteraction,
    SaaSPlan,
    SMTPSettings,
    Insurer,
    MedicalOperator,
    Claim,
    CRMOpportunity,
)
from app.models.insurance import NotificationLog, Policy, Renewal
from app.models.user import User
from app.repositories.base import SQLAlchemyRepository
from app.utils.tenancy import current_organization_id, scoped_query


class OrganizationRepository(SQLAlchemyRepository):
    model = Organization

    def list_filtered(self, *, q: str = ""):
        query = Organization.query.filter_by(is_deleted=False)
        if q:
            like = f"%{q}%"
            query = query.filter(
                (Organization.name.ilike(like))
                | (Organization.slug.ilike(like))
                | (Organization.legal_name.ilike(like))
            )
        return query.order_by(Organization.name.asc())

    def get_active_or_404(self, organization_id: int):
        return Organization.query.filter_by(id=organization_id, is_deleted=False).first_or_404()

    def list_choices(self):
        return Organization.query.filter_by(is_deleted=False).order_by(Organization.name.asc()).all()


class SMTPSettingsRepository(SQLAlchemyRepository):
    model = SMTPSettings

    def get_active_for_org(self):
        return scoped_query(SMTPSettings).order_by(SMTPSettings.id.desc()).first()


class UserRepository(SQLAlchemyRepository):
    model = User

    def list_filtered(self, *, q: str = "", platform_admin: bool = False):
        query = User.query if platform_admin else User.query.filter(User.organization_id == current_organization_id())
        if q:
            like = f"%{q}%"
            query = query.filter((User.name.ilike(like)) | (User.email.ilike(like)))
        return query.order_by(User.name.asc())

    def get_visible_or_404(self, user_id: int, *, platform_admin: bool = False):
        query = User.query if platform_admin else User.query.filter(User.organization_id == current_organization_id())
        return query.filter_by(id=user_id).first_or_404()


class ProviderRepository(SQLAlchemyRepository):
    def list_filtered(self, model, *, q: str = ""):
        query = scoped_query(model).filter(model.is_deleted.is_(False))
        if q:
            like = f"%{q}%"
            query = query.filter(
                (model.name.ilike(like))
                | (model.legal_name.ilike(like))
                | (model.document.ilike(like))
            )
        return query.order_by(model.name.asc())

    def get_active_or_404(self, model, provider_id: int):
        return scoped_query(model).filter_by(id=provider_id, is_deleted=False).first_or_404()

    def list_provider_choices(self):
        insurers = [
            (f"insurer:{item.id}", f"Seguradora • {item.name}")
            for item in scoped_query(Insurer).filter_by(is_deleted=False).order_by(Insurer.name.asc()).all()
        ]
        operators = [
            (f"operator:{item.id}", f"Saúde • {item.name}")
            for item in scoped_query(MedicalOperator).filter_by(is_deleted=False).order_by(MedicalOperator.name.asc()).all()
        ]
        return insurers + operators

    def list_interactions(self, *, provider_kind: str, provider_id: int):
        return (
            scoped_query(ProviderInteraction)
            .filter_by(provider_kind=provider_kind, provider_id=provider_id)
            .order_by(ProviderInteraction.interaction_date.desc(), ProviderInteraction.created_at.desc())
            .all()
        )

    def provider_metrics(self, *, provider_kind: str, provider_id: int):
        if provider_kind == "insurer":
            base = scoped_query(Policy).filter(Policy.is_deleted.is_(False), Policy.insurer_id == provider_id)
            renewals_q = scoped_query(Renewal).join(Policy, Renewal.policy_id == Policy.id).filter(Policy.insurer_id == provider_id)
            claims_q = scoped_query(Claim).join(Policy, Claim.policy_id == Policy.id).filter(Claim.is_deleted.is_(False), Policy.insurer_id == provider_id)
            opp_q = scoped_query(CRMOpportunity).filter(CRMOpportunity.is_deleted.is_(False), CRMOpportunity.insurer_id == provider_id)
        else:
            base = scoped_query(Policy).filter(Policy.is_deleted.is_(False), Policy.operator_id == provider_id)
            renewals_q = scoped_query(Renewal).join(Policy, Renewal.policy_id == Policy.id).filter(Policy.operator_id == provider_id)
            claims_q = scoped_query(Claim).join(Policy, Claim.policy_id == Policy.id).filter(Claim.is_deleted.is_(False), Policy.operator_id == provider_id)
            opp_q = scoped_query(CRMOpportunity).filter(CRMOpportunity.is_deleted.is_(False), CRMOpportunity.operator_id == provider_id)

        policies = base.order_by(Policy.ends_at.desc()).all()
        return {
            "policies_total": len(policies),
            "active_policies": sum(1 for item in policies if item.status == "ativa"),
            "premium_total": float(sum(float(item.premium_value or 0) for item in policies)),
            "commission_total": float(sum(float(item.commission_value or 0) for item in policies)),
            "renewals_open": renewals_q.filter(
                Renewal.stage.in_(["pendente", "em_contato", "cotando", "proposta_enviada", "aguardando_retorno", "negociacao", "urgente"])
            ).count(),
            "claims_open": claims_q.filter(
                Claim.status.in_(["aberto", "triagem", "documentacao", "em_regulacao", "em_analise", "aprovado"])
            ).count(),
            "opportunities_open": opp_q.filter(CRMOpportunity.stage.in_(["lead", "contato", "cotacao", "proposta"])).count(),
            "recent_policies": policies[:8],
            "recent_renewals": renewals_q.order_by(Renewal.updated_at.desc()).limit(8).all(),
            "recent_claims": claims_q.order_by(Claim.created_at.desc()).limit(8).all(),
            "recent_opportunities": opp_q.order_by(CRMOpportunity.created_at.desc()).limit(8).all(),
        }


class SaaSPlanRepository(SQLAlchemyRepository):
    model = SaaSPlan

    def list_all(self):
        return SaaSPlan.query.order_by(SaaSPlan.monthly_price.asc()).all()

    def list_active(self):
        return SaaSPlan.query.filter_by(is_active=True).order_by(SaaSPlan.name.asc()).all()

    def get(self, plan_id: int):
        return SaaSPlan.query.get(plan_id)


class SubscriptionRepository(SQLAlchemyRepository):
    model = OrganizationSubscription

    def get_latest_for_org(self, organization_id: int):
        return (
            OrganizationSubscription.query.filter_by(organization_id=organization_id)
            .order_by(OrganizationSubscription.id.desc())
            .first()
        )


class NotificationRepository(SQLAlchemyRepository):
    model = NotificationLog

    def recent_logs(self, limit: int = 100):
        return scoped_query(NotificationLog).order_by(NotificationLog.sent_at.desc()).limit(limit).all()

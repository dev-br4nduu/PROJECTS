from __future__ import annotations

from app.models.core import Client, CRMOpportunity, InsuranceType, Insurer, MedicalOperator
from app.repositories.base import SQLAlchemyRepository
from app.utils.tenancy import scoped_query


class CRMOpportunityRepository(SQLAlchemyRepository):
    model = CRMOpportunity

    def base_query(self):
        return scoped_query(CRMOpportunity).filter_by(is_deleted=False)

    def list_filtered(self, *, q: str = "", stage: str = "", provider: str = ""):
        query = self.base_query()
        if q:
            query = query.filter(CRMOpportunity.title.ilike(f"%{q}%"))
        if stage:
            query = query.filter(CRMOpportunity.stage == stage)
        if provider:
            provider_type, _, provider_id = provider.partition(":")
            if provider_type == "insurer" and provider_id.isdigit():
                query = query.filter(CRMOpportunity.insurer_id == int(provider_id))
            elif provider_type == "operator" and provider_id.isdigit():
                query = query.filter(CRMOpportunity.operator_id == int(provider_id))
        return query

    def get_active_or_404(self, opportunity_id: int):
        return self.base_query().filter_by(id=opportunity_id).first_or_404()

    def form_choices(self):
        return {
            "clients": [(0, "Sem cliente vinculado")] + [
                (item.id, item.full_name)
                for item in scoped_query(Client).filter_by(is_deleted=False).order_by(Client.full_name.asc()).all()
            ],
            "insurance_types": [(0, "Selecione")] + [
                (item.id, item.name)
                for item in InsuranceType.query.order_by(InsuranceType.name.asc()).all()
            ],
            "insurers": [(0, "Sem seguradora")] + [
                (item.id, item.name)
                for item in scoped_query(Insurer).filter_by(is_deleted=False).order_by(Insurer.name.asc()).all()
            ],
            "operators": [(0, "Sem operadora")] + [
                (item.id, item.name)
                for item in scoped_query(MedicalOperator).filter_by(is_deleted=False).order_by(MedicalOperator.name.asc()).all()
            ],
            "providers": [
                (f"insurer:{item.id}", f"Seguradora • {item.name}")
                for item in scoped_query(Insurer).filter_by(is_deleted=False).order_by(Insurer.name.asc()).all()
            ] + [
                (f"operator:{item.id}", f"Saúde • {item.name}")
                for item in scoped_query(MedicalOperator).filter_by(is_deleted=False).order_by(MedicalOperator.name.asc()).all()
            ],
        }

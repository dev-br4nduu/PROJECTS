import click
from datetime import date, timedelta
from werkzeug.security import generate_password_hash
from flask.cli import with_appcontext
from app import db
from app.models.user import User
from app.models.core import Organization, InsuranceType, Insurer, MedicalOperator, Client, Vehicle, Driver, Claim, CRMOpportunity, SaaSPlan, OrganizationSubscription
from app.models.insurance import Policy
from app.services.notification_service import process_due_notifications
from app.services.renewal_service import recalculate_renewals, ensure_renewal_record
from app.services.saas_service import ensure_default_plans, provision_organization_from_signup


def ensure_admin_and_lookups(org_slug="boss-default", org_name="Boss Workspace"):
    """Garante organização padrão, administrador e tabelas auxiliares (idempotente)."""
    org = Organization.query.filter_by(slug=org_slug).first()
    if not org:
        org = Organization(name=org_name, slug=org_slug, is_active=True)
        db.session.add(org)
        db.session.flush()

    if not User.query.filter_by(email="admin@bossseguros.com", organization_id=org.id).first():
        admin = User(
            organization_id=org.id,
            name="Administrador",
            email="admin@bossseguros.com",
            role="admin",
            is_active=True,
            password_hash=generate_password_hash("Admin@123"),
        )
        db.session.add(admin)

    for name in ["Seguro Auto", "Convênio Médico", "Seguro Residencial", "Eletro / Eletrodomésticos"]:
        if not InsuranceType.query.filter_by(name=name).first():
            db.session.add(InsuranceType(name=name))
    for name in ["Porto", "Azul", "HDI", "Allianz", "Tokio Marine", "Bradesco Seguros"]:
        if not Insurer.query.filter_by(name=name, organization_id=org.id).first():
            db.session.add(Insurer(name=name, organization_id=org.id))
    for name in ["Amil", "SulAmérica", "Bradesco Saúde", "Unimed"]:
        if not MedicalOperator.query.filter_by(name=name, organization_id=org.id).first():
            db.session.add(MedicalOperator(name=name, organization_id=org.id))

    db.session.commit()
    return org


def bootstrap_desktop(app):
    with app.app_context():
        db.create_all()
        if User.query.count() == 0:
            ensure_admin_and_lookups()


def register_cli(app):
    @app.cli.command("init-db")
    @with_appcontext
    def init_db():
        db.create_all()
        click.echo("Banco inicializado com sucesso.")

    @app.cli.command("sync-schema")
    @with_appcontext
    def sync_schema():
        db.create_all()
        click.echo("Schema sincronizado com sucesso.")

    @app.cli.command("seed-admin")
    @click.option('--org-slug', default='boss-default')
    @click.option('--org-name', default='Boss Workspace')
    @with_appcontext
    def seed_admin(org_slug, org_name):
        ensure_admin_and_lookups(org_slug=org_slug, org_name=org_name)
        click.echo("Admin e cadastros iniciais criados.")

    @app.cli.command("seed-platform-admin")
    @click.option('--email', default='owner@bosssaas.com')
    @click.option('--password', default='Owner@12345')
    @with_appcontext
    def seed_platform_admin(email, password):
        org = ensure_admin_and_lookups()
        user = User.query.filter_by(email=email.lower().strip(), organization_id=org.id).first()
        if not user:
            user = User(organization_id=org.id, name='Platform Owner', email=email.lower().strip(), role='platform_admin', is_active=True, password_hash=generate_password_hash(password))
            db.session.add(user)
            db.session.commit()
            click.echo(f'Platform admin criado: {email}')
        else:
            click.echo('Platform admin já existe.')

    @app.cli.command("seed-demo")
    @click.option('--org-slug', default='boss-default')
    @click.option('--org-name', default='Boss Workspace')
    @with_appcontext
    def seed_demo(org_slug, org_name):
        org = ensure_admin_and_lookups(org_slug=org_slug, org_name=org_name)
        if not User.query.filter_by(email="gestor@bossseguros.com", organization_id=org.id).first():
            db.session.add(User(organization_id=org.id, name="Gestor Comercial", email="gestor@bossseguros.com", role="manager", is_active=True, password_hash=generate_password_hash("Gestor@123")))
        if not User.query.filter_by(email="corretor@bossseguros.com", organization_id=org.id).first():
            db.session.add(User(organization_id=org.id, name="Corretor Demo", email="corretor@bossseguros.com", role="broker", is_active=True, password_hash=generate_password_hash("Corretor@123")))
        db.session.flush()

        insurance_types = {x.name: x for x in InsuranceType.query.all()}
        if not insurance_types:
            click.echo("Rode seed-admin antes do seed-demo.")
            return
        insurers = {x.name: x for x in Insurer.query.filter_by(organization_id=org.id).all()}
        operators = {x.name: x for x in MedicalOperator.query.filter_by(organization_id=org.id).all()}

        if Client.query.filter_by(organization_id=org.id).count() == 0:
            client = Client(organization_id=org.id, full_name="Danilo Exemplo", client_type="pf", document=f"12345678901-{org.id}", email="cliente@exemplo.com", whatsapp="11999999999", city="Guarulhos", state="SP", status="ativo", lead_source="Indicação")
            db.session.add(client)
            db.session.flush()
            vehicle = Vehicle(organization_id=org.id, client_id=client.id, brand="Toyota", model="Corolla", plate=f"ABC{org.id}D23", manufacture_year=2022, model_year=2023, usage_type="particular", garage=True)
            driver = Driver(organization_id=org.id, client_id=client.id, name="Danilo Exemplo", cnh_number="12345678900", cnh_category="B", main_driver=True)
            db.session.add_all([vehicle, driver])
            db.session.flush()
            policy = Policy(
                organization_id=org.id,
                client_id=client.id,
                vehicle_id=vehicle.id,
                insurance_type_id=insurance_types["Seguro Auto"].id,
                insurer_id=insurers["Porto"].id,
                title="Seguro Auto Corolla",
                policy_number=f"AUTO-DEMO-{org.id:03d}",
                status="ativa",
                starts_at=date.today() - timedelta(days=335),
                ends_at=date.today() + timedelta(days=30),
                premium_value=3250.00,
                deductible_value=1800.00,
                payment_method="boleto",
                installments=10,
                coverage_summary="Cobertura compreensiva, carro reserva e assistência 24h",
            )
            health = Policy(
                organization_id=org.id,
                client_id=client.id,
                insurance_type_id=insurance_types["Convênio Médico"].id,
                operator_id=operators["SulAmérica"].id,
                title="Plano de Saúde Familiar",
                policy_number=f"SAUDE-DEMO-{org.id:03d}",
                status="ativa",
                starts_at=date.today() - timedelta(days=100),
                ends_at=date.today() + timedelta(days=20),
                premium_value=890.00,
                contract_holder="Danilo Exemplo",
                dependents_count=2,
            )
            db.session.add_all([policy, health])
            db.session.flush()
            ensure_renewal_record(policy)
            ensure_renewal_record(health)
            db.session.add(Claim(organization_id=org.id, client_id=client.id, policy_id=policy.id, claim_number=f"SIN-DEMO-{org.id:03d}", status="em_analise", occurrence_type="Colisão leve"))
            db.session.add(CRMOpportunity(organization_id=org.id, client_id=client.id, insurance_type_id=insurance_types["Seguro Residencial"].id, title="Renovação Residencial Condomínio", stage="proposta", estimated_value=650.00, assigned_to="Corretor Demo", source="Base interna"))
        db.session.commit()
        recalculate_renewals()
        click.echo("Carga demo criada com sucesso.")

    @app.cli.command("create-organization")
    @click.argument("slug")
    @click.argument("name")
    @click.option('--admin-email', default=None)
    @click.option('--admin-password', default='Admin@123')
    @with_appcontext
    def create_organization(slug, name, admin_email, admin_password):
        slug = slug.strip().lower()
        existing = Organization.query.filter_by(slug=slug).first()
        if existing:
            click.echo(f"Organização já existe: {existing.slug}")
            return
        org = Organization(slug=slug, name=name.strip(), is_active=True)
        db.session.add(org)
        db.session.flush()
        if admin_email:
            db.session.add(User(organization_id=org.id, name=name.strip(), email=admin_email.strip().lower(), role='admin', is_active=True, password_hash=generate_password_hash(admin_password)))
        db.session.commit()
        click.echo(f"Organização criada: {org.name} ({org.slug})")

    @app.cli.command("seed-plans")
    @with_appcontext
    def seed_plans():
        ensure_default_plans()
        click.echo("Planos SaaS padrão garantidos.")

    @app.cli.command("provision-workspace")
    @click.option('--name', required=True)
    @click.option('--slug', required=True)
    @click.option('--admin-name', required=True)
    @click.option('--admin-email', required=True)
    @click.option('--admin-password', required=True)
    @click.option('--plan-code', default='pro')
    @with_appcontext
    def provision_workspace(name, slug, admin_name, admin_email, admin_password, plan_code):
        ensure_default_plans()
        org, admin, sub = provision_organization_from_signup(organization_name=name, organization_slug=slug, contact_name=admin_name, contact_email=admin_email, password=admin_password, plan_code=plan_code)
        click.echo(f"Workspace provisionado: {org.slug} | admin: {admin.email} | plano: {org.current_plan_code}")

    @app.cli.command("validate-env")
    @with_appcontext
    def validate_env():
        from flask import current_app
        from pathlib import Path

        warnings = []
        errors = []
        db_uri = current_app.config.get("SQLALCHEMY_DATABASE_URI", "")
        secret = current_app.config.get("SECRET_KEY", "")
        if not db_uri:
            errors.append("DATABASE_URL/POSTGRES_URL não configurado.")
        if db_uri.startswith("sqlite"):
            warnings.append("Aplicação está usando SQLite; em produção o recomendado é PostgreSQL compartilhado.")
        if secret == "change-this-secret-key":
            if current_app.config.get("ENV_NAME") == "production" and current_app.config.get("REQUIRE_STRONG_SECRET", True):
                errors.append("SECRET_KEY padrão detectada em produção. Gere uma chave exclusiva para produção.")
            else:
                warnings.append("SECRET_KEY padrão detectada. Gere uma chave exclusiva para produção.")
        upload_folder = current_app.config.get("UPLOAD_FOLDER")
        if upload_folder and not Path(upload_folder).exists():
            warnings.append(f"UPLOAD_FOLDER não existe ainda: {upload_folder}")
        if current_app.config.get("ENV_NAME") == "production":
            if db_uri.startswith("sqlite"):
                errors.append("Produção não deve usar SQLite; configure PostgreSQL central.")
            if not current_app.config.get("SESSION_COOKIE_SECURE"):
                warnings.append("SESSION_COOKIE_SECURE está desligado. Ative-o quando usar HTTPS.")
            if not current_app.config.get("REMEMBER_COOKIE_SECURE"):
                warnings.append("REMEMBER_COOKIE_SECURE está desligado. Ative-o quando usar HTTPS.")
            if current_app.config.get("MAIL_SERVER", "localhost") == "localhost":
                warnings.append("MAIL_SERVER ainda está em localhost; revise o SMTP de produção.")
            if current_app.config.get("MULTI_TENANT_MODE") and not current_app.config.get("ROOT_HOST") and current_app.config.get("TENANT_STRATEGY") == 'subdomain':
                warnings.append("ROOT_HOST não definido para estratégia de subdomínio.")

        if errors:
            for item in errors:
                click.echo(f"ERRO: {item}")
            raise SystemExit(1)

        if warnings:
            for item in warnings:
                click.echo(f"AVISO: {item}")
        else:
            click.echo("Ambiente validado sem avisos.")

    @app.cli.command("process-notifications")
    @with_appcontext
    def process_notifications():
        count = process_due_notifications()
        click.echo(f"Notificações processadas: {count}")

    @app.cli.command("recalculate-renewals")
    @with_appcontext
    def renewals():
        count = recalculate_renewals()
        click.echo(f"Renovações recalculadas: {count}")

    @app.cli.command("unlock-user")
    @click.argument("email")
    @click.option('--org-slug', default=None)
    @with_appcontext
    def unlock_user(email, org_slug):
        query = User.query.filter_by(email=email.strip().lower())
        if org_slug:
            query = query.join(User.organization).filter(Organization.slug == org_slug.strip().lower())
        user = query.first()
        if not user:
            click.echo("Usuário não encontrado.")
            raise SystemExit(1)
        user.failed_login_attempts = 0
        user.locked_until = None
        db.session.commit()
        click.echo(f"Usuário desbloqueado: {email}")

from flask_wtf import FlaskForm
from wtforms import (
    StringField, PasswordField, BooleanField, SubmitField, SelectField,
    DateField, DecimalField, IntegerField, TextAreaField, FileField
)
from wtforms.validators import DataRequired, Email, Length, Optional, NumberRange, ValidationError
import re
from app.models.core import Client, Vehicle, Driver, Claim, Insurer, MedicalOperator, Organization
from app.models.insurance import Policy
from app.models.user import User
from app.services.password_policy import validate_password_strength


def validate_document_number(form, field):
    value = re.sub(r"\D", "", field.data or "")
    if len(value) not in (11, 14):
        raise ValidationError("Informe um CPF ou CNPJ válido.")


class LoginForm(FlaskForm):
    organization_slug = StringField("Workspace", validators=[Optional(), Length(max=80)])
    email = StringField("E-mail", validators=[DataRequired(), Email()])
    password = PasswordField("Senha", validators=[DataRequired()])
    remember = BooleanField("Continuar conectado")
    submit = SubmitField("Entrar")


class ClientForm(FlaskForm):
    client_type = SelectField("Tipo", choices=[("pf", "Pessoa Física"), ("pj", "Pessoa Jurídica")], validators=[DataRequired()])
    full_name = StringField("Nome / Razão social", validators=[DataRequired(), Length(max=150)])
    document = StringField("CPF/CNPJ", validators=[DataRequired(), validate_document_number])
    birth_date = DateField("Nascimento", validators=[Optional()])
    email = StringField("E-mail", validators=[Optional(), Email()])
    secondary_email = StringField("E-mail secundário", validators=[Optional(), Email()])
    whatsapp = StringField("WhatsApp", validators=[Optional(), Length(max=20)])
    phone = StringField("Celular / Telefone", validators=[Optional(), Length(max=20)])
    cep = StringField("CEP", validators=[Optional(), Length(max=12)])
    address = StringField("Endereço", validators=[Optional(), Length(max=200)])
    number = StringField("Número", validators=[Optional(), Length(max=20)])
    complement = StringField("Complemento", validators=[Optional(), Length(max=100)])
    district = StringField("Bairro", validators=[Optional(), Length(max=100)])
    city = StringField("Cidade", validators=[Optional(), Length(max=100)])
    state = StringField("UF", validators=[Optional(), Length(max=2)])
    profession = StringField("Profissão", validators=[Optional(), Length(max=100)])
    marital_status = SelectField("Estado civil", choices=[("", "Selecione"), ("solteiro", "Solteiro(a)"), ("casado", "Casado(a)"), ("divorciado", "Divorciado(a)"), ("viuvo", "Viúvo(a)")], validators=[Optional()])
    lead_source = StringField("Origem", validators=[Optional(), Length(max=100)])
    status = SelectField("Status", choices=[("ativo", "Ativo"), ("inativo", "Inativo"), ("prospect", "Prospect")], validators=[DataRequired()])
    notes = TextAreaField("Observações", validators=[Optional()])
    submit = SubmitField("Salvar")

    def validate_document(self, field):
        existing = Client.query.filter_by(document=field.data).first()
        if existing and (not hasattr(self, "obj") or existing.id != self.obj.id):
            raise ValidationError("Já existe cliente com esse documento.")


class VehicleForm(FlaskForm):
    client_id = SelectField("Cliente", coerce=int, validators=[DataRequired()])
    brand = StringField("Marca", validators=[DataRequired(), Length(max=80)])
    model = StringField("Modelo", validators=[DataRequired(), Length(max=120)])
    version = StringField("Versão", validators=[Optional(), Length(max=120)])
    plate = StringField("Placa", validators=[Optional(), Length(max=12)])
    renavam = StringField("RENAVAM", validators=[Optional(), Length(max=30)])
    chassis = StringField("Chassi", validators=[Optional(), Length(max=30)])
    fuel = SelectField("Combustível", choices=[("", "Selecione"), ("flex", "Flex"), ("gasolina", "Gasolina"), ("diesel", "Diesel"), ("eletrico", "Elétrico")], validators=[Optional()])
    color = StringField("Cor", validators=[Optional(), Length(max=30)])
    manufacture_year = IntegerField("Ano fabricação", validators=[Optional(), NumberRange(min=1950, max=2100)])
    model_year = IntegerField("Ano modelo", validators=[Optional(), NumberRange(min=1950, max=2100)])
    usage_type = SelectField("Uso", choices=[("", "Selecione"), ("particular", "Particular"), ("comercial", "Comercial"), ("app", "Aplicativo")], validators=[Optional()])
    overnight_zipcode = StringField("CEP de pernoite", validators=[Optional(), Length(max=12)])
    garage = BooleanField("Garagem fechada")
    tracker = BooleanField("Rastreador")
    app_use = BooleanField("Uso por aplicativo")
    fipe_value = DecimalField("Valor FIPE", validators=[Optional(), NumberRange(min=0)], places=2)
    notes = TextAreaField("Observações", validators=[Optional()])
    submit = SubmitField("Salvar")

    def validate_plate(self, field):
        if not field.data:
            return
        existing = Vehicle.query.filter_by(plate=field.data.upper().strip()).first()
        if existing and (not hasattr(self, "obj") or existing.id != self.obj.id):
            raise ValidationError("Já existe veículo com essa placa.")


class DriverForm(FlaskForm):
    client_id = SelectField("Cliente", coerce=int, validators=[DataRequired()])
    name = StringField("Nome do condutor", validators=[DataRequired(), Length(max=120)])
    document = StringField("CPF", validators=[Optional(), Length(max=30)])
    birth_date = DateField("Nascimento", validators=[Optional()])
    cnh_number = StringField("Número da CNH", validators=[Optional(), Length(max=30)])
    cnh_category = StringField("Categoria", validators=[Optional(), Length(max=5)])
    cnh_expiration = DateField("Validade da CNH", validators=[Optional()])
    relationship = StringField("Parentesco / vínculo", validators=[Optional(), Length(max=60)])
    main_driver = BooleanField("Condutor principal")
    profession = StringField("Profissão", validators=[Optional(), Length(max=100)])
    notes = TextAreaField("Observações", validators=[Optional()])
    submit = SubmitField("Salvar")


class PolicyForm(FlaskForm):
    client_id = SelectField("Cliente", coerce=int, validators=[DataRequired()])
    vehicle_id = SelectField("Veículo", coerce=int, validators=[Optional()])
    insurance_type_id = SelectField("Tipo de seguro", coerce=int, validators=[DataRequired()])
    insurer_id = SelectField("Seguradora", coerce=int, validators=[Optional()])
    operator_id = SelectField("Operadora médica", coerce=int, validators=[Optional()])
    title = StringField("Título", validators=[Optional(), Length(max=150)])
    policy_number = StringField("Número da apólice", validators=[DataRequired(), Length(max=80)])
    proposal_number = StringField("Proposta", validators=[Optional(), Length(max=80)])
    status = SelectField("Status", choices=[("ativa", "Ativa"), ("pendente", "Pendente"), ("vencida", "Vencida"), ("cancelada", "Cancelada")], validators=[DataRequired()])
    starts_at = DateField("Início da vigência", validators=[DataRequired()])
    ends_at = DateField("Fim da vigência", validators=[DataRequired()])
    premium_value = DecimalField("Prêmio", validators=[Optional(), NumberRange(min=0)], places=2)
    deductible_value = DecimalField("Franquia", validators=[Optional(), NumberRange(min=0)], places=2)
    commission_rate = DecimalField("Comissão %", validators=[Optional(), NumberRange(min=0, max=100)], places=2)
    commission_value = DecimalField("Comissão R$", validators=[Optional(), NumberRange(min=0)], places=2)
    auto_renew = BooleanField("Renovação automática habilitada")
    payment_method = SelectField("Pagamento", choices=[("", "Selecione"), ("pix", "PIX"), ("boleto", "Boleto"), ("cartao", "Cartão"), ("debito", "Débito")], validators=[Optional()])
    installments = IntegerField("Parcelas", validators=[Optional(), NumberRange(min=1, max=24)])
    contract_holder = StringField("Titular do contrato", validators=[Optional(), Length(max=150)])
    dependents_count = IntegerField("Dependentes", validators=[Optional(), NumberRange(min=0, max=99)])
    property_type = StringField("Tipo do imóvel", validators=[Optional(), Length(max=50)])
    property_address = StringField("Endereço do risco", validators=[Optional(), Length(max=200)])
    insured_item = StringField("Item segurado", validators=[Optional(), Length(max=150)])
    serial_number = StringField("Número de série", validators=[Optional(), Length(max=100)])
    invoice_number = StringField("Nota fiscal", validators=[Optional(), Length(max=100)])
    coverage_summary = TextAreaField("Resumo de cobertura", validators=[Optional()])
    notes = TextAreaField("Observações", validators=[Optional()])
    submit = SubmitField("Salvar")

    def validate_policy_number(self, field):
        number = (field.data or "").strip()
        insurer_pk = self.insurer_id.data if self.insurer_id.data not in (0, None) else None
        operator_pk = self.operator_id.data if self.operator_id.data not in (0, None) else None
        q = Policy.query.filter(Policy.policy_number == number)
        if insurer_pk:
            q = q.filter(Policy.insurer_id == insurer_pk)
        elif operator_pk:
            q = q.filter(Policy.operator_id == operator_pk)
        else:
            q = q.filter(Policy.insurer_id.is_(None), Policy.operator_id.is_(None))
        existing = q.first()
        if existing and (not hasattr(self, "obj") or existing.id != self.obj.id):
            raise ValidationError("Já existe apólice com esse número para esta seguradora ou operadora.")

    def validate(self, extra_validators=None):
        initial = super().validate(extra_validators=extra_validators)
        if not initial:
            return False
        from app.models.core import InsuranceType, Vehicle
        insurance_type = InsuranceType.query.get(self.insurance_type_id.data) if self.insurance_type_id.data else None
        type_name = (insurance_type.name.lower() if insurance_type else '')
        vehicle_id = None if self.vehicle_id.data in (None, 0) else self.vehicle_id.data
        insurer_id = None if self.insurer_id.data in (None, 0) else self.insurer_id.data
        operator_id = None if self.operator_id.data in (None, 0) else self.operator_id.data

        if 'auto' in type_name:
            if not vehicle_id:
                self.vehicle_id.errors.append('Seguro Auto exige um veículo vinculado.')
            if not insurer_id:
                self.insurer_id.errors.append('Seguro Auto exige uma seguradora selecionada.')
            if operator_id:
                self.operator_id.errors.append('Seguro Auto não usa operadora médica.')
        if 'convênio médico' in type_name or 'saúde' in type_name:
            if not operator_id:
                self.operator_id.errors.append('Convênio Médico exige uma operadora médica selecionada.')
            if insurer_id:
                self.insurer_id.errors.append('Convênio Médico não deve usar seguradora tradicional.')
        if 'residencial' in type_name and not (self.property_address.data or '').strip():
            self.property_address.errors.append('Seguro Residencial exige o endereço do risco.')
        if ('eletro' in type_name or 'eletr' in type_name) and not (self.insured_item.data or '').strip():
            self.insured_item.errors.append('Seguro de eletrônicos exige o item segurado.')

        if vehicle_id:
            vehicle = Vehicle.query.get(vehicle_id)
            if vehicle and vehicle.client_id != self.client_id.data:
                self.vehicle_id.errors.append('O veículo selecionado não pertence ao cliente informado.')

        return not any([
            self.vehicle_id.errors, self.insurer_id.errors, self.operator_id.errors,
            self.property_address.errors, self.insured_item.errors
        ])


class ClaimForm(FlaskForm):
    client_id = SelectField("Cliente", coerce=int, validators=[DataRequired()])
    policy_id = SelectField("Apólice", coerce=int, validators=[Optional()])
    claim_number = StringField("Número do sinistro", validators=[DataRequired(), Length(max=80)])
    event_date = DateField("Data do evento", validators=[Optional()])
    opened_at = DateField("Data de abertura", validators=[Optional()])
    status = SelectField("Status", choices=[("aberto", "Aberto"), ("triagem", "Triagem"), ("documentacao", "Documentação"), ("em_regulacao", "Em regulação"), ("em_analise", "Em análise"), ("aprovado", "Aprovado"), ("indenizado", "Indenizado"), ("negado", "Negado"), ("encerrado", "Encerrado")], validators=[DataRequired()])
    stage = SelectField("Fase operacional", choices=[("aviso", "Aviso inicial"), ("coleta", "Coleta documental"), ("seguradora", "Análise da seguradora"), ("pagamento", "Pagamento"), ("finalizado", "Finalizado")], validators=[Optional()])
    occurrence_type = StringField("Tipo de ocorrência", validators=[Optional(), Length(max=100)])
    insurer_protocol = StringField("Protocolo da seguradora", validators=[Optional(), Length(max=80)])
    analyst_name = StringField("Analista / regulador", validators=[Optional(), Length(max=120)])
    expected_completion = DateField("Previsão de conclusão", validators=[Optional()])
    reserve_value = DecimalField("Reserva / prejuízo estimado", validators=[Optional(), NumberRange(min=0)], places=2)
    indemnity_value = DecimalField("Valor da indenização", validators=[Optional(), NumberRange(min=0)], places=2)
    deductible_applied = DecimalField("Franquia aplicada", validators=[Optional(), NumberRange(min=0)], places=2)
    closed_at = DateField("Data de encerramento", validators=[Optional()])
    description = TextAreaField("Descrição", validators=[Optional()])
    submit = SubmitField("Salvar")

    def validate_claim_number(self, field):
        existing = Claim.query.filter_by(claim_number=field.data).first()
        if existing and (not hasattr(self, "obj") or existing.id != self.obj.id):
            raise ValidationError("Já existe sinistro com esse número.")


class OpportunityForm(FlaskForm):
    client_id = SelectField("Cliente", coerce=int, validators=[Optional()])
    insurance_type_id = SelectField("Tipo de seguro", coerce=int, validators=[Optional()])
    insurer_id = SelectField("Seguradora de veículos", coerce=int, validators=[Optional()])
    operator_id = SelectField("Operadora de saúde", coerce=int, validators=[Optional()])
    title = StringField("Título da oportunidade", validators=[DataRequired(), Length(max=150)])
    stage = SelectField("Etapa", choices=[("lead", "Lead"), ("contato", "Em contato"), ("cotacao", "Cotação"), ("proposta", "Proposta enviada"), ("fechado", "Fechado"), ("perdido", "Perdido")], validators=[DataRequired()])
    estimated_value = DecimalField("Valor estimado", validators=[Optional(), NumberRange(min=0)], places=2)
    expected_close_date = DateField("Previsão de fechamento", validators=[Optional()])
    assigned_to = StringField("Responsável", validators=[Optional(), Length(max=120)])
    source = StringField("Origem", validators=[Optional(), Length(max=100)])
    notes = TextAreaField("Observações", validators=[Optional()])
    submit = SubmitField("Salvar")




class RenewalForm(FlaskForm):
    stage = SelectField(
        "Etapa",
        choices=[
            ("pendente", "Pendente"),
            ("em_contato", "Em contato"),
            ("cotando", "Cotando"),
            ("proposta_enviada", "Proposta enviada"),
            ("aguardando_retorno", "Aguardando retorno"),
            ("negociacao", "Negociação"),
            ("renovado", "Renovado"),
            ("perdido", "Perdido"),
            ("vencido", "Vencido"),
            ("urgente", "Urgente"),
        ],
        validators=[DataRequired()],
    )
    priority = SelectField("Prioridade", choices=[("normal", "Normal"), ("media", "Média"), ("alta", "Alta")], validators=[DataRequired()])
    current_premium = DecimalField("Prêmio atual", validators=[Optional(), NumberRange(min=0)], places=2)
    target_premium = DecimalField("Meta de prêmio", validators=[Optional(), NumberRange(min=0)], places=2)
    quote_count = IntegerField("Qtd. de cotações", validators=[Optional(), NumberRange(min=0, max=50)])
    last_contact_at = DateField("Último contato", validators=[Optional()])
    next_action_at = DateField("Próxima ação", validators=[Optional()])
    customer_response = StringField("Retorno do cliente", validators=[Optional(), Length(max=255)])
    lost_reason = StringField("Motivo de perda", validators=[Optional(), Length(max=255)])
    notes = TextAreaField("Observações", validators=[Optional()])
    submit = SubmitField("Salvar renovação")


class SMTPForm(FlaskForm):
    mail_server = StringField("Servidor SMTP", validators=[DataRequired()])
    mail_port = IntegerField("Porta", validators=[DataRequired(), NumberRange(min=1, max=65535)])
    username = StringField("Usuário", validators=[Optional()])
    password = PasswordField("Senha", validators=[Optional()])
    default_sender = StringField("Remetente padrão", validators=[Optional(), Email()])
    use_tls = BooleanField("Usa TLS")
    use_ssl = BooleanField("Usa SSL")
    submit = SubmitField("Salvar SMTP")


class ProviderBaseForm(FlaskForm):
    name = StringField("Nome fantasia", validators=[DataRequired(), Length(max=120)])
    legal_name = StringField("Razão social", validators=[Optional(), Length(max=150)])
    document = StringField("CNPJ", validators=[Optional(), Length(max=30)])
    contact_name = StringField("Contato", validators=[Optional(), Length(max=120)])
    email = StringField("E-mail", validators=[Optional(), Email(), Length(max=150)])
    phone = StringField("Telefone", validators=[Optional(), Length(max=20)])
    whatsapp = StringField("WhatsApp", validators=[Optional(), Length(max=20)])
    website = StringField("Website", validators=[Optional(), Length(max=150)])
    relationship_status = SelectField("Status do relacionamento", choices=[('ativo', 'Ativo'), ('homologacao', 'Homologação'), ('pausado', 'Pausado'), ('estrategico', 'Estratégico')])
    commercial_owner = StringField("Responsável comercial", validators=[Optional(), Length(max=120)])
    service_level = SelectField("Nível de parceria", choices=[('padrao', 'Padrão'), ('preferencial', 'Preferencial'), ('premium', 'Premium')])
    is_active = BooleanField("Empresa ativa")
    notes = TextAreaField("Observações", validators=[Optional()])
    submit = SubmitField("Salvar")


class InsurerCompanyForm(ProviderBaseForm):
    def validate_name(self, field):
        q = Insurer.query.filter(Insurer.name == (field.data or '').strip())
        existing = q.first()
        if existing and (not hasattr(self, 'obj') or existing.id != self.obj.id):
            raise ValidationError('Já existe seguradora cadastrada com esse nome.')

    def validate_document(self, field):
        doc = (field.data or '').strip()
        if not doc:
            return
        q = Insurer.query.filter(Insurer.document == doc)
        existing = q.first()
        if existing and (not hasattr(self, 'obj') or existing.id != self.obj.id):
            raise ValidationError('Já existe seguradora cadastrada com esse CNPJ.')


class MedicalOperatorCompanyForm(ProviderBaseForm):
    def validate_name(self, field):
        q = MedicalOperator.query.filter(MedicalOperator.name == (field.data or '').strip())
        existing = q.first()
        if existing and (not hasattr(self, 'obj') or existing.id != self.obj.id):
            raise ValidationError('Já existe operadora cadastrada com esse nome.')

    def validate_document(self, field):
        doc = (field.data or '').strip()
        if not doc:
            return
        q = MedicalOperator.query.filter(MedicalOperator.document == doc)
        existing = q.first()
        if existing and (not hasattr(self, 'obj') or existing.id != self.obj.id):
            raise ValidationError('Já existe operadora cadastrada com esse CNPJ.')


class ProviderInteractionForm(FlaskForm):
    interaction_date = DateField("Data da interação", validators=[DataRequired()])
    interaction_type = SelectField("Tipo", choices=[('contato', 'Contato'), ('reuniao', 'Reunião'), ('negociacao', 'Negociação'), ('follow_up', 'Follow-up'), ('suporte', 'Suporte'), ('homologacao', 'Homologação')], validators=[DataRequired()])
    subject = StringField("Assunto", validators=[DataRequired(), Length(max=150)])
    status = SelectField("Status", choices=[('aberto', 'Aberto'), ('em_andamento', 'Em andamento'), ('concluido', 'Concluído')], validators=[DataRequired()])
    owner_name = StringField("Responsável", validators=[Optional(), Length(max=120)])
    next_follow_up = DateField("Próximo follow-up", validators=[Optional()])
    notes = TextAreaField("Observações", validators=[Optional()])
    submit = SubmitField("Salvar interação")

class UploadImportForm(FlaskForm):
    import_type = SelectField("Tipo de importação", choices=[("clients", "Clientes"), ("policies", "Apólices")], validators=[DataRequired()])
    spreadsheet = FileField("Planilha Excel", validators=[DataRequired()])
    submit = SubmitField("Importar")


class DocumentUploadForm(FlaskForm):
    client_id = SelectField("Cliente", coerce=int, validators=[DataRequired()])
    policy_id = SelectField("Apólice vinculada", coerce=int, validators=[Optional()])
    claim_id = SelectField("Sinistro vinculado", coerce=int, validators=[Optional()])
    category = SelectField(
        "Categoria",
        choices=[
            ("apolice", "Apólice"),
            ("cnh", "CNH"),
            ("comprovante", "Comprovante"),
            ("documento_veiculo", "Documento do veículo"),
            ("proposta", "Proposta"),
            ("sinistro", "Sinistro"),
            ("outros", "Outros"),
        ],
        validators=[DataRequired()],
    )
    description = StringField("Descrição", validators=[Optional(), Length(max=255)])
    file = FileField("Arquivo", validators=[DataRequired()])
    submit = SubmitField("Enviar documento")


def _validate_strong_password(value: str | None):
    for error in validate_password_strength(value):
        raise ValidationError(error)


class UserForm(FlaskForm):
    organization_id = SelectField("Workspace", coerce=int, validators=[Optional()])
    name = StringField("Nome", validators=[DataRequired(), Length(max=120)])
    email = StringField("E-mail", validators=[DataRequired(), Email(), Length(max=150)])
    role = SelectField(
        "Perfil",
        choices=[
            ("platform_admin", "Platform Admin"),
            ("admin", "Administrador"),
            ("manager", "Gestor"),
            ("broker", "Corretor"),
            ("assistant", "Assistente"),
            ("viewer", "Somente leitura"),
        ],
        validators=[DataRequired()],
    )
    is_active = BooleanField("Usuário ativo")
    password = PasswordField("Senha", validators=[Optional(), Length(min=8, max=128)])
    submit = SubmitField("Salvar usuário")

    def validate_password(self, field):
        if field.data:
            _validate_strong_password(field.data)

    def validate_email(self, field):
        org_id = self.organization_id.data if self.organization_id.data else None
        existing = User.query.filter_by(email=field.data.lower().strip())
        if org_id:
            existing = existing.filter_by(organization_id=org_id)
        existing = existing.first()
        if existing and (not hasattr(self, 'obj') or existing.id != self.obj.id):
            raise ValidationError("Já existe usuário com esse e-mail neste workspace.")


class OrganizationForm(FlaskForm):
    name = StringField("Nome do workspace", validators=[DataRequired(), Length(max=150)])
    slug = StringField("Slug / identificador", validators=[DataRequired(), Length(max=80)])
    legal_name = StringField("Razão social", validators=[Optional(), Length(max=180)])
    document = StringField("CNPJ", validators=[Optional(), Length(max=30)])
    contact_email = StringField("E-mail de contato", validators=[Optional(), Email(), Length(max=150)])
    is_active = BooleanField("Workspace ativo")
    submit = SubmitField("Salvar workspace")

    def validate_slug(self, field):
        slug = (field.data or "").strip().lower()
        existing = Organization.query.filter_by(slug=slug).first()
        if existing and (not hasattr(self, "obj") or existing.id != self.obj.id):
            raise ValidationError("Já existe workspace com esse slug.")


class SaaSPlanForm(FlaskForm):
    code = StringField("Código do plano", validators=[DataRequired(), Length(max=30)])
    name = StringField("Nome do plano", validators=[DataRequired(), Length(max=80)])
    description = StringField("Descrição", validators=[Optional(), Length(max=255)])
    monthly_price = DecimalField("Mensalidade", validators=[Optional(), NumberRange(min=0)], places=2)
    annual_price = DecimalField("Anual", validators=[Optional(), NumberRange(min=0)], places=2)
    max_users = IntegerField("Limite de usuários", validators=[Optional(), NumberRange(min=1, max=10000)])
    max_storage_gb = IntegerField("Storage (GB)", validators=[Optional(), NumberRange(min=1, max=100000)])
    is_active = BooleanField("Plano ativo")
    submit = SubmitField("Salvar plano")


class SaaSSubscriptionForm(FlaskForm):
    plan_id = SelectField("Plano", coerce=int, validators=[DataRequired()])
    status = SelectField("Status", choices=[('trialing', 'Trial'), ('active', 'Ativo'), ('past_due', 'Em atraso'), ('canceled', 'Cancelado')], validators=[DataRequired()])
    started_at = DateField("Início", validators=[Optional()])
    trial_ends_at = DateField("Fim do trial", validators=[Optional()])
    current_period_end = DateField("Fim do ciclo", validators=[Optional()])
    seats_purchased = IntegerField("Assentos", validators=[Optional(), NumberRange(min=1, max=10000)])
    notes = TextAreaField("Observações", validators=[Optional()])
    submit = SubmitField("Salvar assinatura")


class OnboardingSignupForm(FlaskForm):
    organization_name = StringField("Nome da empresa", validators=[DataRequired(), Length(max=150)])
    organization_slug = StringField("Workspace desejado", validators=[DataRequired(), Length(max=80)])
    contact_name = StringField("Nome do administrador", validators=[DataRequired(), Length(max=120)])
    contact_email = StringField("E-mail do administrador", validators=[DataRequired(), Email(), Length(max=150)])
    contact_phone = StringField("Telefone / WhatsApp", validators=[Optional(), Length(max=30)])
    password = PasswordField("Senha inicial", validators=[DataRequired(), Length(min=8, max=128)])
    plan_code = SelectField("Plano inicial", choices=[('start', 'Start'), ('pro', 'Pro'), ('premium', 'Premium')], validators=[DataRequired()])
    accept_terms = BooleanField("Aceito os termos de uso", validators=[DataRequired()])
    submit = SubmitField("Criar workspace")

    def validate_password(self, field):
        _validate_strong_password(field.data)

    def validate_organization_slug(self, field):
        slug = (field.data or '').strip().lower()
        existing_org = Organization.query.filter_by(slug=slug).first()
        if existing_org:
            raise ValidationError('Esse workspace já está em uso.')



class ForgotPasswordForm(FlaskForm):
    organization_slug = StringField("Workspace", validators=[Optional(), Length(max=80)])
    email = StringField("E-mail", validators=[DataRequired(), Email()])
    submit = SubmitField("Enviar link de redefinição")


class ResetPasswordForm(FlaskForm):
    password = PasswordField("Nova senha", validators=[DataRequired(), Length(min=8, max=128)])
    confirm_password = PasswordField("Confirmar nova senha", validators=[DataRequired(), Length(min=8, max=128)])
    submit = SubmitField("Atualizar senha")

    def validate_password(self, field):
        _validate_strong_password(field.data)

    def validate_confirm_password(self, field):
        if field.data != self.password.data:
            raise ValidationError("As senhas não conferem.")


class ProposalSendForm(FlaskForm):
    recipient_email = StringField("E-mail do cliente", validators=[Optional(), Email()])
    recipient_whatsapp = StringField("WhatsApp do cliente", validators=[Optional(), Length(max=20)])
    message = TextAreaField("Mensagem", validators=[Optional()])
    submit_email = SubmitField("Enviar por e-mail")
    submit_whatsapp = SubmitField("Abrir no WhatsApp")

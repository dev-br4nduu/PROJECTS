from __future__ import annotations

import os
import sys

from flask import Flask
from werkzeug.middleware.proxy_fix import ProxyFix

from config import DevelopmentConfig
from app.core.blueprints import register_blueprints
from app.core.errors import register_error_handlers
from app.core.hooks import register_context_processors, register_request_hooks
from app.core.logging import configure_logging
from app.extensions import db, login_manager, mail, migrate, scheduler


def _flask_folders():
    pkg_dir = os.path.dirname(os.path.abspath(__file__))
    if getattr(sys, "frozen", False):
        base = getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
        return os.path.join(base, "app", "templates"), os.path.join(base, "app", "static")
    return os.path.join(pkg_dir, "templates"), os.path.join(pkg_dir, "static")


def create_app(config_object=DevelopmentConfig):
    if getattr(sys, "frozen", False):
        tpl, static = _flask_folders()
        app = Flask(
            __name__,
            instance_relative_config=False,
            template_folder=tpl,
            static_folder=static,
        )
    else:
        app = Flask(__name__, instance_relative_config=False)

    app.config.from_object(config_object)

    configure_logging(app)

    if app.config.get("BEHIND_PROXY"):
        app.wsgi_app = ProxyFix(
            app.wsgi_app,
            x_for=app.config.get("PROXY_FIX_X_FOR", 1),
            x_proto=app.config.get("PROXY_FIX_X_PROTO", 1),
            x_host=app.config.get("PROXY_FIX_X_HOST", 1),
            x_port=app.config.get("PROXY_FIX_X_PORT", 1),
            x_prefix=app.config.get("PROXY_FIX_X_PREFIX", 1),
        )

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)
    mail.init_app(app)

    login_manager.login_view = "auth.login"
    login_manager.login_message = "Faça login para continuar."
    login_manager.session_protection = None

    from app.models import core, insurance, user  # noqa: F401

    register_blueprints(app)
    register_request_hooks(app)
    register_context_processors(app)
    register_error_handlers(app)

    from app.cli import register_cli
    from app.services.scheduler_service import configure_scheduler

    configure_scheduler(app)
    register_cli(app)

    return app

__all__ = ["create_app", "db", "login_manager", "mail", "migrate", "scheduler"]

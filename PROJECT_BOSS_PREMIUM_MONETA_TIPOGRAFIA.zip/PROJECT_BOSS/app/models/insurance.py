from datetime import date, datetime
from app import db
from app.models.mixins import SoftDeleteMixin, TenantMixin


class Policy(SoftDeleteMixin, TenantMixin, db.Model):
    __tablename__ = "policies"
    __table_args__ = (
        db.UniqueConstraint("organization_id", "insurer_id", "policy_number", name="uq_policies_org_insurer_policy_number"),
        db.UniqueConstraint("organization_id", "operator_id", "policy_number", name="uq_policies_org_operator_policy_number"),
    )

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    vehicle_id = db.Column(db.Integer, db.ForeignKey("vehicles.id"))
    insurance_type_id = db.Column(db.Integer, db.ForeignKey("insurance_types.id"), nullable=False)
    insurer_id = db.Column(db.Integer, db.ForeignKey("insurers.id"))
    operator_id = db.Column(db.Integer, db.ForeignKey("medical_operators.id"))
    assigned_user_id = db.Column(db.Integer, db.ForeignKey("users.id"))

    title = db.Column(db.String(150), nullable=False)
    policy_number = db.Column(db.String(80), nullable=False, index=True)
    proposal_number = db.Column(db.String(80))
    status = db.Column(db.String(30), default="ativa")
    starts_at = db.Column(db.Date, nullable=False)
    ends_at = db.Column(db.Date, nullable=False)
    premium_value = db.Column(db.Numeric(12, 2))
    deductible_value = db.Column(db.Numeric(12, 2))
    commission_rate = db.Column(db.Numeric(5, 2))
    commission_value = db.Column(db.Numeric(12, 2))
    auto_renew = db.Column(db.Boolean, default=True)
    payment_method = db.Column(db.String(50))
    installments = db.Column(db.Integer)
    coverage_summary = db.Column(db.Text)
    notes = db.Column(db.Text)
    contract_holder = db.Column(db.String(150))
    dependents_count = db.Column(db.Integer, default=0)
    property_type = db.Column(db.String(50))
    property_address = db.Column(db.String(200))
    insured_item = db.Column(db.String(150))
    serial_number = db.Column(db.String(100))
    invoice_number = db.Column(db.String(100))

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    organization = db.relationship("Organization")
    client = db.relationship("Client", back_populates="policies")
    vehicle = db.relationship("Vehicle", back_populates="policies")
    insurance_type = db.relationship("InsuranceType")
    insurer = db.relationship("Insurer")
    operator = db.relationship("MedicalOperator")
    notifications = db.relationship("NotificationLog", back_populates="policy", cascade="all, delete-orphan")
    renewal = db.relationship("Renewal", back_populates="policy", uselist=False, cascade="all, delete-orphan")
    claims = db.relationship("Claim", back_populates="policy")
    assigned_user = db.relationship("User", foreign_keys=[assigned_user_id])

    @property
    def days_to_expire(self):
        if not self.ends_at:
            return None
        return (self.ends_at - date.today()).days


class Renewal(TenantMixin, db.Model):
    __tablename__ = "renewals"
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    policy_id = db.Column(db.Integer, db.ForeignKey("policies.id"), nullable=False, unique=True)
    stage = db.Column(db.String(30), default="pendente")
    priority = db.Column(db.String(20), default="normal")
    last_contact_at = db.Column(db.Date)
    next_action_at = db.Column(db.Date)
    result = db.Column(db.String(30))
    current_premium = db.Column(db.Numeric(12, 2))
    target_premium = db.Column(db.Numeric(12, 2))
    quote_count = db.Column(db.Integer, default=0)
    lost_reason = db.Column(db.String(255))
    customer_response = db.Column(db.String(255))
    notes = db.Column(db.Text)
    owner_email = db.Column(db.String(150))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    organization = db.relationship("Organization")
    client = db.relationship("Client", back_populates="renewals")
    policy = db.relationship("Policy", back_populates="renewal")


class NotificationLog(TenantMixin, db.Model):
    __tablename__ = "notification_logs"
    id = db.Column(db.Integer, primary_key=True)
    policy_id = db.Column(db.Integer, db.ForeignKey("policies.id"), nullable=False)
    notification_type = db.Column(db.String(40), nullable=False)
    target_email = db.Column(db.String(150), nullable=False)
    days_before = db.Column(db.Integer, nullable=False)
    sent_at = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default="sent")
    error_message = db.Column(db.Text)

    organization = db.relationship("Organization")
    policy = db.relationship("Policy", back_populates="notifications")

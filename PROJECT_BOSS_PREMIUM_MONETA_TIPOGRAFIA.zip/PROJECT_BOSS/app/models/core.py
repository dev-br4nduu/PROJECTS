from datetime import datetime
from app import db
from app.models.mixins import TimestampMixin, SoftDeleteMixin, TenantMixin


class Organization(TimestampMixin, SoftDeleteMixin, db.Model):
    __tablename__ = "organizations"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    slug = db.Column(db.String(80), nullable=False, unique=True, index=True)
    legal_name = db.Column(db.String(180))
    document = db.Column(db.String(30))
    contact_email = db.Column(db.String(150))
    onboarding_status = db.Column(db.String(30), default='onboarded')
    current_plan_code = db.Column(db.String(30), default='pro')
    trial_ends_at = db.Column(db.Date)
    onboarded_at = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)


class Client(TimestampMixin, SoftDeleteMixin, TenantMixin, db.Model):
    __tablename__ = "clients"

    id = db.Column(db.Integer, primary_key=True)
    client_type = db.Column(db.String(20), nullable=False, default="pf")
    full_name = db.Column(db.String(150), nullable=False)
    document = db.Column(db.String(30), nullable=False, index=True)
    birth_date = db.Column(db.Date)
    email = db.Column(db.String(150))
    secondary_email = db.Column(db.String(150))
    whatsapp = db.Column(db.String(20))
    phone = db.Column(db.String(20))
    cep = db.Column(db.String(12))
    address = db.Column(db.String(200))
    number = db.Column(db.String(20))
    complement = db.Column(db.String(100))
    district = db.Column(db.String(100))
    city = db.Column(db.String(100))
    state = db.Column(db.String(2))
    profession = db.Column(db.String(100))
    marital_status = db.Column(db.String(50))
    notes = db.Column(db.Text)
    lead_source = db.Column(db.String(100))
    assigned_user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    status = db.Column(db.String(30), default="ativo")

    organization = db.relationship("Organization")
    vehicles = db.relationship("Vehicle", back_populates="client", cascade="all, delete-orphan")
    drivers = db.relationship("Driver", back_populates="client", cascade="all, delete-orphan")
    policies = db.relationship("Policy", back_populates="client", cascade="all, delete-orphan")
    documents = db.relationship("DocumentFile", back_populates="client", cascade="all, delete-orphan")
    renewals = db.relationship("Renewal", back_populates="client", cascade="all, delete-orphan")
    claims = db.relationship("Claim", back_populates="client", cascade="all, delete-orphan")
    opportunities = db.relationship("CRMOpportunity", back_populates="client", cascade="all, delete-orphan")


class Vehicle(TimestampMixin, SoftDeleteMixin, TenantMixin, db.Model):
    __tablename__ = "vehicles"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    brand = db.Column(db.String(80), nullable=False)
    model = db.Column(db.String(120), nullable=False)
    version = db.Column(db.String(120))
    plate = db.Column(db.String(12), index=True)
    renavam = db.Column(db.String(30))
    chassis = db.Column(db.String(30))
    fuel = db.Column(db.String(30))
    color = db.Column(db.String(30))
    manufacture_year = db.Column(db.Integer)
    model_year = db.Column(db.Integer)
    usage_type = db.Column(db.String(50))
    overnight_zipcode = db.Column(db.String(12))
    garage = db.Column(db.Boolean, default=False)
    tracker = db.Column(db.Boolean, default=False)
    app_use = db.Column(db.Boolean, default=False)
    fipe_value = db.Column(db.Numeric(12, 2))
    notes = db.Column(db.Text)

    organization = db.relationship("Organization")
    client = db.relationship("Client", back_populates="vehicles")
    policies = db.relationship("Policy", back_populates="vehicle")


class Driver(TimestampMixin, SoftDeleteMixin, TenantMixin, db.Model):
    __tablename__ = "drivers"

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    name = db.Column(db.String(120), nullable=False)
    document = db.Column(db.String(30))
    birth_date = db.Column(db.Date)
    cnh_number = db.Column(db.String(30))
    cnh_category = db.Column(db.String(5))
    cnh_expiration = db.Column(db.Date)
    relationship = db.Column(db.String(60))
    main_driver = db.Column(db.Boolean, default=False)
    profession = db.Column(db.String(100))
    notes = db.Column(db.Text)

    organization = db.relationship("Organization")
    client = db.relationship("Client", back_populates="drivers")


class InsuranceType(db.Model):
    __tablename__ = "insurance_types"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False)


class Insurer(TimestampMixin, SoftDeleteMixin, TenantMixin, db.Model):
    __tablename__ = "insurers"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False, index=True)
    legal_name = db.Column(db.String(150))
    document = db.Column(db.String(30))
    contact_name = db.Column(db.String(120))
    email = db.Column(db.String(150))
    phone = db.Column(db.String(20))
    whatsapp = db.Column(db.String(20))
    website = db.Column(db.String(150))
    relationship_status = db.Column(db.String(30), default='ativo')
    commercial_owner = db.Column(db.String(120))
    service_level = db.Column(db.String(30), default='padrao')
    is_active = db.Column(db.Boolean, default=True)
    notes = db.Column(db.Text)

    organization = db.relationship("Organization")


class MedicalOperator(TimestampMixin, SoftDeleteMixin, TenantMixin, db.Model):
    __tablename__ = "medical_operators"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False, index=True)
    legal_name = db.Column(db.String(150))
    document = db.Column(db.String(30))
    contact_name = db.Column(db.String(120))
    email = db.Column(db.String(150))
    phone = db.Column(db.String(20))
    whatsapp = db.Column(db.String(20))
    website = db.Column(db.String(150))
    relationship_status = db.Column(db.String(30), default='ativo')
    commercial_owner = db.Column(db.String(120))
    service_level = db.Column(db.String(30), default='padrao')
    is_active = db.Column(db.Boolean, default=True)
    notes = db.Column(db.Text)

    organization = db.relationship("Organization")


class ProviderInteraction(TimestampMixin, TenantMixin, db.Model):
    __tablename__ = "provider_interactions"
    id = db.Column(db.Integer, primary_key=True)
    provider_kind = db.Column(db.String(20), nullable=False, index=True)
    provider_id = db.Column(db.Integer, nullable=False, index=True)
    interaction_date = db.Column(db.Date, nullable=False, default=datetime.utcnow)
    interaction_type = db.Column(db.String(40), nullable=False, default='contato')
    subject = db.Column(db.String(150), nullable=False)
    status = db.Column(db.String(30), default='aberto')
    owner_name = db.Column(db.String(120))
    notes = db.Column(db.Text)
    next_follow_up = db.Column(db.Date)
    created_by = db.Column(db.Integer, db.ForeignKey("users.id"))

    organization = db.relationship("Organization")
    user = db.relationship("User")


class SMTPSettings(TimestampMixin, TenantMixin, db.Model):
    __tablename__ = "smtp_settings"
    id = db.Column(db.Integer, primary_key=True)
    mail_server = db.Column(db.String(120), nullable=False)
    mail_port = db.Column(db.Integer, nullable=False)
    use_tls = db.Column(db.Boolean, default=True)
    use_ssl = db.Column(db.Boolean, default=False)
    username = db.Column(db.String(150))
    password_encrypted = db.Column(db.String(512))
    default_sender = db.Column(db.String(150))
    active = db.Column(db.Boolean, default=True)

    organization = db.relationship("Organization")

    @property
    def password(self):
        from app.services.crypto_service import decrypt_text
        return decrypt_text(self.password_encrypted)

    @password.setter
    def password(self, value):
        from app.services.crypto_service import encrypt_text
        self.password_encrypted = encrypt_text(value)


class AuditLog(TimestampMixin, TenantMixin, db.Model):
    __tablename__ = "audit_logs"
    id = db.Column(db.Integer, primary_key=True)
    action = db.Column(db.String(120), nullable=False)
    entity = db.Column(db.String(120), nullable=False)
    entity_id = db.Column(db.String(60))
    detail = db.Column(db.Text)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))

    organization = db.relationship("Organization")
    user = db.relationship("User", back_populates="logs")


class DocumentFile(TimestampMixin, SoftDeleteMixin, TenantMixin, db.Model):
    __tablename__ = "document_files"
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    policy_id = db.Column(db.Integer, db.ForeignKey("policies.id"))
    claim_id = db.Column(db.Integer, db.ForeignKey("claims.id"))
    file_name = db.Column(db.String(255), nullable=False)
    file_path = db.Column(db.String(255), nullable=False)
    category = db.Column(db.String(80))
    description = db.Column(db.String(255))

    organization = db.relationship("Organization")
    client = db.relationship("Client", back_populates="documents")
    policy = db.relationship("Policy")
    claim = db.relationship("Claim")


class Claim(TimestampMixin, SoftDeleteMixin, TenantMixin, db.Model):
    __tablename__ = "claims"
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"), nullable=False)
    policy_id = db.Column(db.Integer, db.ForeignKey("policies.id"))
    claim_number = db.Column(db.String(80), index=True)
    event_date = db.Column(db.Date)
    opened_at = db.Column(db.Date)
    status = db.Column(db.String(30), default="aberto")
    stage = db.Column(db.String(30), default="aviso")
    occurrence_type = db.Column(db.String(100))
    insurer_protocol = db.Column(db.String(80))
    analyst_name = db.Column(db.String(120))
    description = db.Column(db.Text)
    reserve_value = db.Column(db.Numeric(12, 2))
    indemnity_value = db.Column(db.Numeric(12, 2))
    deductible_applied = db.Column(db.Numeric(12, 2))
    expected_completion = db.Column(db.Date)
    closed_at = db.Column(db.Date)

    organization = db.relationship("Organization")
    client = db.relationship("Client", back_populates="claims")
    policy = db.relationship("Policy", back_populates="claims")


class CRMOpportunity(TimestampMixin, SoftDeleteMixin, TenantMixin, db.Model):
    __tablename__ = "crm_opportunities"
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("clients.id"))
    insurance_type_id = db.Column(db.Integer, db.ForeignKey("insurance_types.id"))
    insurer_id = db.Column(db.Integer, db.ForeignKey("insurers.id"))
    operator_id = db.Column(db.Integer, db.ForeignKey("medical_operators.id"))
    title = db.Column(db.String(150), nullable=False)
    stage = db.Column(db.String(30), default="lead")
    estimated_value = db.Column(db.Numeric(12, 2))
    expected_close_date = db.Column(db.Date)
    assigned_to = db.Column(db.String(120))
    source = db.Column(db.String(100))
    notes = db.Column(db.Text)

    organization = db.relationship("Organization")
    client = db.relationship("Client", back_populates="opportunities")
    insurance_type = db.relationship("InsuranceType")
    insurer = db.relationship("Insurer")
    operator = db.relationship("MedicalOperator")


class ImportBatch(TimestampMixin, TenantMixin, db.Model):
    __tablename__ = "import_batches"
    id = db.Column(db.Integer, primary_key=True)
    import_type = db.Column(db.String(30), nullable=False)
    file_name = db.Column(db.String(255), nullable=False)
    rows_created = db.Column(db.Integer, default=0)
    rows_updated = db.Column(db.Integer, default=0)
    rows_error = db.Column(db.Integer, default=0)
    note = db.Column(db.Text)
    imported_by = db.Column(db.Integer, db.ForeignKey("users.id"))

    organization = db.relationship("Organization")


class SaaSPlan(TimestampMixin, db.Model):
    __tablename__ = "saas_plans"

    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(30), nullable=False, unique=True, index=True)
    name = db.Column(db.String(80), nullable=False)
    description = db.Column(db.String(255))
    monthly_price = db.Column(db.Numeric(12, 2), default=0)
    annual_price = db.Column(db.Numeric(12, 2), default=0)
    max_users = db.Column(db.Integer)
    max_storage_gb = db.Column(db.Integer)
    features_json = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)


class OrganizationSubscription(TimestampMixin, db.Model):
    __tablename__ = "organization_subscriptions"

    id = db.Column(db.Integer, primary_key=True)
    organization_id = db.Column(db.Integer, db.ForeignKey("organizations.id"), nullable=False, index=True)
    plan_id = db.Column(db.Integer, db.ForeignKey("saas_plans.id"), nullable=False)
    status = db.Column(db.String(30), default='trialing', index=True)
    started_at = db.Column(db.Date)
    trial_ends_at = db.Column(db.Date)
    current_period_end = db.Column(db.Date)
    seats_purchased = db.Column(db.Integer, default=1)
    notes = db.Column(db.Text)

    organization = db.relationship("Organization")
    plan = db.relationship("SaaSPlan")


class OnboardingRequest(TimestampMixin, db.Model):
    __tablename__ = "onboarding_requests"

    id = db.Column(db.Integer, primary_key=True)
    organization_name = db.Column(db.String(150), nullable=False)
    organization_slug = db.Column(db.String(80), nullable=False, index=True)
    contact_name = db.Column(db.String(120), nullable=False)
    contact_email = db.Column(db.String(150), nullable=False, index=True)
    contact_phone = db.Column(db.String(30))
    selected_plan_code = db.Column(db.String(30), nullable=False, default='pro')
    status = db.Column(db.String(30), nullable=False, default='pending')
    notes = db.Column(db.Text)
    provisioned_organization_id = db.Column(db.Integer, db.ForeignKey("organizations.id"))

    provisioned_organization = db.relationship("Organization")

from __future__ import annotations

from urllib.parse import quote
from flask import current_app
from app.services.email_service import send_email


def build_whatsapp_link(phone: str, message: str) -> str:
    digits = ''.join(ch for ch in (phone or '') if ch.isdigit())
    ddi = current_app.config.get("WHATSAPP_DEFAULT_DDI", "55")
    if digits and not digits.startswith(ddi):
        digits = f"{ddi}{digits}"
    return f"https://wa.me/{digits}?text={quote(message)}"


def send_proposal_email(recipient: str, subject: str, message_html: str, message_text: str, attachment_path: str | None = None):
    attachments = []
    if attachment_path:
        attachments.append({"path": attachment_path, "filename": attachment_path.split('/')[-1], "maintype": "application", "subtype": "pdf"})
    send_email(subject=subject, recipients=[recipient], html_body=message_html, text_body=message_text, attachments=attachments)

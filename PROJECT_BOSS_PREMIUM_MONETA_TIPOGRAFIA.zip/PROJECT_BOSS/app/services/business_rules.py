from __future__ import annotations

from decimal import Decimal
from typing import List

from app.models.core import Client, InsuranceType, Vehicle
from app.models.insurance import Policy

AUTO_NAMES = {"seguro auto"}
HEALTH_NAMES = {"convênio médico", "seguro saúde", "saúde", "plano de saúde"}
RESIDENTIAL_NAMES = {"seguro residencial"}
ELECTRO_NAMES = {"eletro / eletrodomésticos", "seguro de eletrônicos", "eletro", "eletrônicos"}
CONSORTIUM_NAMES = {"consórcio"}


def _normalize(value: str | None) -> str:
    return (value or '').strip().lower()


def line_kind(policy_or_type: Policy | InsuranceType | str | None) -> str:
    if isinstance(policy_or_type, Policy):
        name = policy_or_type.insurance_type.name if policy_or_type.insurance_type else ''
        if not name and policy_or_type.insurance_type_id:
            insurance_type = InsuranceType.query.session.get(InsuranceType, policy_or_type.insurance_type_id)
            name = insurance_type.name if insurance_type else ''
    elif isinstance(policy_or_type, InsuranceType):
        name = policy_or_type.name
    else:
        name = str(policy_or_type or '')
    norm = _normalize(name)
    if norm in AUTO_NAMES:
        return 'auto'
    if norm in HEALTH_NAMES:
        return 'health'
    if norm in RESIDENTIAL_NAMES:
        return 'residential'
    if norm in ELECTRO_NAMES:
        return 'electro'
    if norm in CONSORTIUM_NAMES:
        return 'consortium'
    return 'generic'


def recommendation_status(client: Client | None) -> str:
    if not client:
        return 'sem_cadastro'
    active_policies = [p for p in client.policies if not p.is_deleted and p.status == 'ativa']
    if active_policies:
        return 'ativo'
    return 'reconquistar' if client.status in {'inativo', 'prospect'} else 'sem_apolice'


def compute_commission_value(premium_value, commission_rate):
    if premium_value is None or commission_rate is None:
        return None
    return (Decimal(premium_value) * Decimal(commission_rate)) / Decimal('100')


def validate_policy_business_rules(policy: Policy) -> List[str]:
    errors: List[str] = []
    kind = line_kind(policy)

    if not policy.client_id:
        errors.append('Selecione um cliente para a apólice.')
        return errors

    if policy.starts_at and policy.ends_at and policy.ends_at < policy.starts_at:
        errors.append('A vigência final não pode ser menor que a inicial.')

    if kind == 'auto':
        if not policy.vehicle_id:
            errors.append('Seguro Auto exige um veículo vinculado.')
        if not policy.insurer_id:
            errors.append('Seguro Auto exige uma seguradora selecionada.')
        if policy.operator_id:
            errors.append('Seguro Auto não pode usar operadora médica.')
    elif kind == 'health':
        if not policy.operator_id:
            errors.append('Convênio Médico exige uma operadora médica selecionada.')
        if policy.insurer_id:
            errors.append('Convênio Médico não deve usar seguradora tradicional.')
        if policy.dependents_count is None:
            errors.append('Convênio Médico deve informar o número de dependentes, mesmo que zero.')
    elif kind == 'residential':
        if not policy.insurer_id:
            errors.append('Seguro Residencial exige uma seguradora selecionada.')
        if not policy.property_address:
            errors.append('Seguro Residencial exige o endereço do risco.')
    elif kind == 'electro':
        if not policy.insurer_id:
            errors.append('Seguro de eletrônicos exige uma seguradora selecionada.')
        if not policy.insured_item:
            errors.append('Seguro de eletrônicos exige o item segurado.')
    elif kind == 'consortium':
        if not policy.contract_holder:
            errors.append('Consórcio exige a identificação do titular do contrato.')

    if policy.vehicle_id:
        vehicle = Vehicle.query.filter_by(id=policy.vehicle_id, is_deleted=False).first()
        if not vehicle:
            errors.append('O veículo selecionado não foi encontrado.')
        elif vehicle.client_id != policy.client_id:
            errors.append('O veículo selecionado não pertence ao cliente informado.')

    if not policy.title:
        errors.append('Informe um título para a apólice.')

    return errors


def infer_policy_title(policy: Policy) -> str:
    if not policy.client:
        return policy.title or ''
    base = policy.insurance_type.name if policy.insurance_type else 'Seguro'
    suffix = policy.vehicle.plate if policy.vehicle else policy.policy_number
    return f"{base} - {policy.client.full_name} - {suffix}"

import math
from datetime import date, datetime
from io import BytesIO
from openpyxl import load_workbook
from app import db
from app.models.core import Client, InsuranceType, Insurer, MedicalOperator
from app.models.insurance import Policy
from app.services.renewal_service import ensure_renewal_record


def _normalize_value(value):
    if value is None:
        return None
    if isinstance(value, float) and math.isnan(value):
        return None
    s = str(value).strip()
    return s if s else None


def _to_date(val):
    if val is None:
        return None
    if isinstance(val, datetime):
        return val.date()
    if isinstance(val, date):
        return val
    s = str(val).strip()[:10]
    for fmt in ("%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    raise ValueError(f"Data inválida: {val!r}")


def _to_float(val):
    if val is None or (isinstance(val, float) and math.isnan(val)):
        return None
    try:
        return float(val)
    except (TypeError, ValueError):
        return None


def _to_int(val):
    if val is None or (isinstance(val, float) and math.isnan(val)):
        return None
    try:
        return int(float(val))
    except (TypeError, ValueError):
        return None


def _read_excel_dicts(file_storage):
    raw = file_storage.read()
    wb = load_workbook(BytesIO(raw), read_only=True, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    if not rows:
        return []
    headers = []
    for h in rows[0]:
        headers.append(_normalize_value(h) or "")
    out = []
    for r in rows[1:]:
        row = {}
        for i, key in enumerate(headers):
            if not key:
                continue
            val = r[i] if i < len(r) else None
            row[key.lower()] = val
        out.append(row)
    return out


def import_clients_from_excel(file_storage):
    result = {"created": 0, "updated": 0, "errors": []}
    for index, row in enumerate(_read_excel_dicts(file_storage)):
        try:
            document = _normalize_value(row.get("document"))
            if not document:
                raise ValueError("document vazio")
            client = Client.query.filter_by(document=document).first()
            created = client is None
            if created:
                client = Client(document=document)
                db.session.add(client)
            client.client_type = _normalize_value(row.get("client_type")) or "pf"
            client.full_name = _normalize_value(row.get("full_name"))
            client.email = _normalize_value(row.get("email"))
            client.secondary_email = _normalize_value(row.get("secondary_email"))
            client.whatsapp = _normalize_value(row.get("whatsapp"))
            client.phone = _normalize_value(row.get("phone"))
            client.cep = _normalize_value(row.get("cep"))
            client.address = _normalize_value(row.get("address"))
            client.number = _normalize_value(row.get("number"))
            client.complement = _normalize_value(row.get("complement"))
            client.district = _normalize_value(row.get("district"))
            client.city = _normalize_value(row.get("city"))
            client.state = _normalize_value(row.get("state"))
            client.profession = _normalize_value(row.get("profession"))
            client.marital_status = _normalize_value(row.get("marital_status"))
            client.lead_source = _normalize_value(row.get("lead_source"))
            client.status = _normalize_value(row.get("status")) or "ativo"
            client.notes = _normalize_value(row.get("notes"))
            result["created" if created else "updated"] += 1
        except Exception as exc:
            result["errors"].append({"row": index + 2, "error": str(exc)})
    db.session.commit()
    return result


def import_policies_from_excel(file_storage):
    result = {"created": 0, "updated": 0, "errors": []}
    for index, row in enumerate(_read_excel_dicts(file_storage)):
        try:
            policy_number = _normalize_value(row.get("policy_number"))
            client_document = _normalize_value(row.get("client_document"))
            insurance_type_name = _normalize_value(row.get("insurance_type"))
            if not all([policy_number, client_document, insurance_type_name]):
                raise ValueError("policy_number, client_document e insurance_type são obrigatórios")
            client = Client.query.filter_by(document=client_document).first()
            if not client:
                raise ValueError(f"cliente não encontrado: {client_document}")
            insurance_type = InsuranceType.query.filter_by(name=insurance_type_name).first()
            if not insurance_type:
                insurance_type = InsuranceType(name=insurance_type_name)
                db.session.add(insurance_type)
                db.session.flush()
            insurer = None
            insurer_name = _normalize_value(row.get("insurer"))
            if insurer_name:
                insurer = Insurer.query.filter_by(name=insurer_name).first()
                if not insurer:
                    insurer = Insurer(name=insurer_name)
                    db.session.add(insurer)
                    db.session.flush()
            operator = None
            operator_name = _normalize_value(row.get("operator"))
            if operator_name:
                operator = MedicalOperator.query.filter_by(name=operator_name).first()
                if not operator:
                    operator = MedicalOperator(name=operator_name)
                    db.session.add(operator)
                    db.session.flush()
            q = Policy.query.filter(Policy.policy_number == policy_number)
            if insurer:
                q = q.filter(Policy.insurer_id == insurer.id)
            elif operator:
                q = q.filter(Policy.operator_id == operator.id)
            else:
                q = q.filter(Policy.insurer_id.is_(None), Policy.operator_id.is_(None))
            policy = q.first()
            created = policy is None
            if created:
                policy = Policy(policy_number=policy_number)
                db.session.add(policy)
            policy.client_id = client.id
            policy.insurance_type_id = insurance_type.id
            policy.insurer_id = insurer.id if insurer else None
            policy.operator_id = operator.id if operator else None
            policy.title = _normalize_value(row.get("title")) or policy_number
            policy.proposal_number = _normalize_value(row.get("proposal_number"))
            policy.status = _normalize_value(row.get("status")) or "ativa"
            policy.starts_at = _to_date(row.get("starts_at"))
            policy.ends_at = _to_date(row.get("ends_at"))
            if not policy.starts_at or not policy.ends_at:
                raise ValueError("starts_at e ends_at obrigatórios")
            policy.premium_value = _to_float(row.get("premium_value"))
            policy.deductible_value = _to_float(row.get("deductible_value"))
            policy.payment_method = _normalize_value(row.get("payment_method"))
            policy.installments = _to_int(row.get("installments"))
            policy.contract_holder = _normalize_value(row.get("contract_holder"))
            policy.dependents_count = _to_int(row.get("dependents_count")) or 0
            policy.property_type = _normalize_value(row.get("property_type"))
            policy.property_address = _normalize_value(row.get("property_address"))
            policy.insured_item = _normalize_value(row.get("insured_item"))
            policy.serial_number = _normalize_value(row.get("serial_number"))
            policy.invoice_number = _normalize_value(row.get("invoice_number"))
            policy.coverage_summary = _normalize_value(row.get("coverage_summary"))
            policy.notes = _normalize_value(row.get("notes"))
            db.session.flush()
            ensure_renewal_record(policy)
            result["created" if created else "updated"] += 1
        except Exception as exc:
            result["errors"].append({"row": index + 2, "error": str(exc)})
    db.session.commit()
    return result

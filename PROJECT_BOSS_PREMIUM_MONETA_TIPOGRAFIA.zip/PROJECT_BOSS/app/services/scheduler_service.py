from app import scheduler
from app.services.notification_service import process_due_notifications
from app.services.renewal_service import recalculate_renewals

def configure_scheduler(app):
    if not app.config.get("ENABLE_SCHEDULER"):
        return
    if scheduler.running:
        return
    scheduler.add_job(func=lambda: _run_with_app(app, process_due_notifications), trigger="cron", hour=8, minute=0, id="notifications_daily", replace_existing=True)
    scheduler.add_job(func=lambda: _run_with_app(app, recalculate_renewals), trigger="cron", hour=7, minute=30, id="renewals_daily", replace_existing=True)
    scheduler.start()

def _run_with_app(app, fn):
    with app.app_context():
        fn()

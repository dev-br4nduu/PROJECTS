from __future__ import annotations
from app.models.core import Client, Insurer, MedicalOperator, Claim, CRMOpportunity
from app.models.insurance import Policy, Renewal
from app.utils.tenancy import scoped_query


def run_global_search(term: str) -> dict:
    q = (term or "").strip()
    if not q:
        return {"clients": [], "policies": [], "renewals": [], "claims": [], "partners": [], "opportunities": []}
    like = f"%{q}%"
    clients = scoped_query(Client).filter(Client.is_deleted.is_(False)).filter(
        (Client.full_name.ilike(like)) | (Client.document.ilike(like)) | (Client.email.ilike(like))
    ).order_by(Client.full_name.asc()).limit(8).all()
    policies = scoped_query(Policy).filter(Policy.is_deleted.is_(False)).filter(
        (Policy.policy_number.ilike(like)) | (Policy.proposal_number.ilike(like)) | (Policy.title.ilike(like))
    ).order_by(Policy.ends_at.asc()).limit(8).all()
    renewals = scoped_query(Renewal).join(Policy).filter(
        (Renewal.stage.ilike(like)) | (Policy.policy_number.ilike(like)) | (Policy.title.ilike(like))
    ).order_by(Renewal.next_action_at.asc().nullslast()).limit(8).all()
    claims = scoped_query(Claim).filter(Claim.is_deleted.is_(False)).filter(
        (Claim.claim_number.ilike(like)) | (Claim.insurer_protocol.ilike(like)) | (Claim.analyst_name.ilike(like))
    ).order_by(Claim.created_at.desc()).limit(8).all()
    insurers = scoped_query(Insurer).filter(Insurer.is_deleted.is_(False), Insurer.name.ilike(like)).limit(5).all()
    operators = scoped_query(MedicalOperator).filter(MedicalOperator.is_deleted.is_(False), MedicalOperator.name.ilike(like)).limit(5).all()
    opportunities = scoped_query(CRMOpportunity).filter(CRMOpportunity.is_deleted.is_(False)).filter(
        (CRMOpportunity.title.ilike(like)) | (CRMOpportunity.stage.ilike(like))
    ).order_by(CRMOpportunity.created_at.desc()).limit(8).all()
    return {
        "clients": clients,
        "policies": policies,
        "renewals": renewals,
        "claims": claims,
        "partners": insurers + operators,
        "opportunities": opportunities,
    }

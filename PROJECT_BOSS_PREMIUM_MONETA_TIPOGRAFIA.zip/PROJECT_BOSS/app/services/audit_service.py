from __future__ import annotations
from flask import request
from flask_login import current_user
from app import db
from app.models.core import AuditLog
from app.utils.tenancy import current_organization_id


def log_event(action: str, entity: str, entity_id: str | int | None = None, detail: str | None = None, commit: bool = False):
    user_id = getattr(current_user, "id", None) if getattr(current_user, "is_authenticated", False) else None
    ip = request.headers.get("X-Forwarded-For", request.remote_addr)
    route = request.path if request else ""
    composed = detail or ""
    meta = f"IP: {ip} | rota: {route}"
    detail_text = f"{composed} | {meta}" if composed else meta
    row = AuditLog(
        organization_id=current_organization_id() or getattr(current_user, "organization_id", None) or 1,
        action=action,
        entity=entity,
        entity_id=str(entity_id) if entity_id is not None else None,
        detail=detail_text,
        user_id=user_id,
    )
    db.session.add(row)
    if commit:
        db.session.commit()
    return row

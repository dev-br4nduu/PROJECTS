"""Regras de negócio do módulo de documentos."""
from __future__ import annotations

import os
from uuid import uuid4

from flask import current_app
from werkzeug.utils import secure_filename

from app.models.core import Client, DocumentFile
from app.repositories.documents import DocumentRepository
from app.services.audit_service import log_event
from app.services.upload_security import validate_upload
from app.utils.tenancy import assign_organization, assert_same_org


class DocumentValidationError(ValueError):
    pass


class DocumentService:
    def __init__(self, repository: DocumentRepository | None = None):
        self.repository = repository or DocumentRepository()

    def apply_form_choices(self, form):
        choices = self.repository.get_form_choices()
        form.client_id.choices = choices["client_id"]
        form.policy_id.choices = choices["policy_id"]
        form.claim_id.choices = choices["claim_id"]

    def paginate(self, *, q: str = "", category: str = "", page: int = 1, per_page: int = 20):
        query = self.repository.list_filtered(q=q, category=category)
        return query.order_by(DocumentFile.created_at.desc()).paginate(
            page=page,
            per_page=per_page,
            error_out=False,
        )

    def create_from_form(self, form):
        file = form.file.data
        ok, message = validate_upload(file)
        if not ok:
            raise DocumentValidationError(message)

        client = Client.query.get_or_404(form.client_id.data)
        safe_name = secure_filename(file.filename)
        ext = safe_name.rsplit(".", 1)[1].lower()
        token_name = f"{uuid4().hex}.{ext}"
        folder = os.path.join(current_app.config["UPLOAD_FOLDER"], "documents", str(client.id))
        os.makedirs(folder, exist_ok=True)
        absolute_path = os.path.join(folder, token_name)
        file.save(absolute_path)
        rel_path = os.path.relpath(absolute_path, start=current_app.root_path)

        document = DocumentFile(
            client_id=form.client_id.data,
            policy_id=None if form.policy_id.data == 0 else form.policy_id.data,
            claim_id=None if form.claim_id.data == 0 else form.claim_id.data,
            file_name=safe_name,
            file_path=rel_path,
            category=form.category.data,
            description=form.description.data,
        )
        assign_organization(document)
        self.repository.save(document, flush=True)
        log_event("create", "document", document.id, f"Documento {document.file_name}")
        self.repository.commit()
        return document

    def archive(self, document_id: int):
        document = self.repository.get_active_or_404(document_id)
        assert_same_org(document)
        document.soft_delete()
        log_event("archive", "document", document.id, f"Documento {document.file_name}")
        self.repository.commit()
        return document

    def get_for_download(self, document_id: int):
        document = self.repository.get_active_or_404(document_id)
        assert_same_org(document)
        return document

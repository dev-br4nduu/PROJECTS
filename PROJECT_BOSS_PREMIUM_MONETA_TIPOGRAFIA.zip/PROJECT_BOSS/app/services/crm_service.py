"""Regras de negócio do pipeline comercial."""
from __future__ import annotations

from app.models.core import CRMOpportunity
from app.repositories.crm import CRMOpportunityRepository
from app.services.audit_service import log_event
from app.utils.tenancy import assign_organization, assert_same_org


class CRMService:
    def __init__(self, repository: CRMOpportunityRepository | None = None):
        self.repository = repository or CRMOpportunityRepository()

    def apply_form_choices(self, form):
        choices = self.repository.form_choices()
        form.client_id.choices = choices["clients"]
        form.insurance_type_id.choices = choices["insurance_types"]
        form.insurer_id.choices = choices["insurers"]
        form.operator_id.choices = choices["operators"]
        return choices

    def paginate(self, *, q: str = "", stage: str = "", provider: str = "", page: int = 1, per_page: int = 20):
        pagination = (
            self.repository.list_filtered(q=q, stage=stage, provider=provider)
            .order_by(CRMOpportunity.created_at.desc())
            .paginate(page=page, per_page=per_page, error_out=False)
        )
        return {"pagination": pagination, "providers": self.repository.form_choices()["providers"]}

    def create_from_form(self, form):
        opportunity = CRMOpportunity()
        form.populate_obj(opportunity)
        self._normalize_optional_foreign_keys(opportunity, form)
        assign_organization(opportunity)
        self.repository.save(opportunity, flush=True)
        log_event("create", "crm_opportunity", opportunity.id, f"Oportunidade {opportunity.title}")
        self.repository.commit()
        return opportunity

    def update_from_form(self, opportunity_id: int, form):
        opportunity = self.repository.get_active_or_404(opportunity_id)
        assert_same_org(opportunity)
        form.populate_obj(opportunity)
        self._normalize_optional_foreign_keys(opportunity, form)
        log_event("update", "crm_opportunity", opportunity.id, f"Oportunidade {opportunity.title}")
        self.repository.commit()
        return opportunity

    def archive(self, opportunity_id: int):
        opportunity = self.repository.get_active_or_404(opportunity_id)
        assert_same_org(opportunity)
        opportunity.soft_delete()
        log_event("archive", "crm_opportunity", opportunity.id, f"Oportunidade {opportunity.title}")
        self.repository.commit()
        return opportunity

    def get_for_view(self, opportunity_id: int):
        opportunity = self.repository.get_active_or_404(opportunity_id)
        assert_same_org(opportunity)
        return opportunity

    @staticmethod
    def _normalize_optional_foreign_keys(opportunity, form):
        opportunity.client_id = None if form.client_id.data == 0 else form.client_id.data
        opportunity.insurance_type_id = None if form.insurance_type_id.data == 0 else form.insurance_type_id.data
        opportunity.insurer_id = None if form.insurer_id.data == 0 else form.insurer_id.data
        opportunity.operator_id = None if form.operator_id.data == 0 else form.operator_id.data

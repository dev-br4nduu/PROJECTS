from __future__ import annotations

import smtplib
from email.message import EmailMessage
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from flask import current_app, render_template, url_for
from app.models.core import SMTPSettings
from app.models.user import User


def current_smtp_settings():
    return SMTPSettings.query.filter_by(active=True).order_by(SMTPSettings.id.desc()).first()


def _smtp_config() -> dict:
    cfg = current_smtp_settings()
    return {
        "server": cfg.mail_server if cfg else current_app.config.get("MAIL_SERVER"),
        "port": cfg.mail_port if cfg else current_app.config.get("MAIL_PORT"),
        "use_tls": cfg.use_tls if cfg else current_app.config.get("MAIL_USE_TLS"),
        "use_ssl": cfg.use_ssl if cfg else current_app.config.get("MAIL_USE_SSL"),
        "username": cfg.username if cfg else current_app.config.get("MAIL_USERNAME"),
        "password": cfg.password if cfg else current_app.config.get("MAIL_PASSWORD"),
        "default_sender": (cfg.default_sender if cfg and cfg.default_sender else current_app.config.get("MAIL_DEFAULT_SENDER")),
    }


def send_email(subject, recipients, html_body, text_body=None, attachments=None):
    cfg = _smtp_config()
    sender = cfg["default_sender"]
    if not sender:
        raise RuntimeError("Remetente SMTP não configurado.")

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = ", ".join(recipients)
    msg.set_content(text_body or "")
    if html_body:
        msg.add_alternative(html_body, subtype="html")

    for item in attachments or []:
        with open(item["path"], "rb") as fh:
            msg.add_attachment(
                fh.read(),
                maintype=item.get("maintype", "application"),
                subtype=item.get("subtype", "octet-stream"),
                filename=item.get("filename") or item["path"].split("/")[-1],
            )

    server_cls = smtplib.SMTP_SSL if cfg["use_ssl"] else smtplib.SMTP
    with server_cls(cfg["server"], cfg["port"], timeout=20) as smtp:
        smtp.ehlo()
        if cfg["use_tls"] and not cfg["use_ssl"]:
            smtp.starttls()
            smtp.ehlo()
        if cfg["username"]:
            smtp.login(cfg["username"], cfg["password"] or "")
        smtp.send_message(msg)


def test_smtp_configuration():
    try:
        sender = _smtp_config()["default_sender"]
        send_email(
            subject="Teste SMTP - Boss Seguros CRM",
            recipients=[sender],
            html_body="<p>SMTP validado com sucesso.</p>",
            text_body="SMTP validado com sucesso.",
        )
        return True, "Teste de SMTP enviado com sucesso."
    except Exception as exc:
        return False, f"Falha no SMTP: {exc}"


def _serializer():
    return URLSafeTimedSerializer(current_app.config["SECRET_KEY"], salt="boss-reset-password")


def generate_password_reset_token(user: User) -> str:
    return _serializer().dumps({"user_id": user.id, "email": user.email})


def verify_password_reset_token(token: str):
    try:
        data = _serializer().loads(token, max_age=current_app.config.get("PASSWORD_RESET_EXPIRES_HOURS", 6) * 3600)
    except (BadSignature, SignatureExpired):
        return None
    return User.query.filter_by(id=data.get("user_id"), email=data.get("email"), is_active=True).first()


def send_password_reset_email(user: User):
    try:
        token = generate_password_reset_token(user)
        reset_url = url_for("auth.reset_password", token=token, _external=True)
        html = render_template("emails/reset_password.html", user=user, reset_url=reset_url)
        send_email(
            subject="Redefinição de senha - Boss Seguros CRM",
            recipients=[user.email],
            html_body=html,
            text_body=f"Use este link para redefinir sua senha: {reset_url}",
        )
        return True, "Link de redefinição enviado com sucesso."
    except Exception as exc:
        return False, f"Falha ao enviar o link de redefinição: {exc}"

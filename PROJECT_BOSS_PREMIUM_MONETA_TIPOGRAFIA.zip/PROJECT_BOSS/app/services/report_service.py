"""Serviço de consolidação de indicadores gerenciais."""
from __future__ import annotations

import csv
from datetime import date, timedelta
from io import StringIO

from sqlalchemy import func

from app.models.core import Client, Claim, CRMOpportunity, ImportBatch, Insurer, InsuranceType, MedicalOperator
from app.models.insurance import NotificationLog, Policy, Renewal
from app.models.user import User
from app.utils.tenancy import scoped_query


class ReportService:
    def resolve_days(self, period: str | int | None) -> int:
        try:
            return int(period or 30)
        except (TypeError, ValueError):
            return 30

    def base_policy_query(self, *, status: str = "", insurance_type: str = "", provider: str = ""):
        query = scoped_query(Policy).filter(Policy.is_deleted.is_(False))
        if status:
            query = query.filter(Policy.status == status)
        if insurance_type:
            query = query.join(InsuranceType, Policy.insurance_type_id == InsuranceType.id).filter(InsuranceType.name == insurance_type)
        if provider:
            provider_type, _, provider_id = provider.partition(":")
            if provider_type == "insurer" and provider_id.isdigit():
                query = query.filter(Policy.insurer_id == int(provider_id))
            elif provider_type == "operator" and provider_id.isdigit():
                query = query.filter(Policy.operator_id == int(provider_id))
        return query

    def dashboard_payload(self, *, period: str = "30", status: str = "", insurance_type: str = "", provider: str = ""):
        today = date.today()
        days = self.resolve_days(period)
        end_date = today + timedelta(days=days)
        base_policy = self.base_policy_query(status=status, insurance_type=insurance_type, provider=provider)

        expiring = base_policy.filter(Policy.ends_at.between(today, end_date)).order_by(Policy.ends_at.asc()).all()
        overdue = base_policy.filter(Policy.ends_at < today, Policy.status == "ativa").order_by(Policy.ends_at.asc()).all()
        notifications = scoped_query(NotificationLog).filter(NotificationLog.sent_at >= today - timedelta(days=days)).count()
        claims_open = scoped_query(Claim).filter(
            Claim.is_deleted.is_(False),
            Claim.status.in_(["aberto", "em_analise", "documentacao"]),
        ).count()
        pipeline = (
            scoped_query(CRMOpportunity)
            .filter(CRMOpportunity.is_deleted.is_(False))
            .with_entities(CRMOpportunity.stage, func.count(CRMOpportunity.id))
            .group_by(CRMOpportunity.stage)
            .all()
        )
        insurer_mix = (
            scoped_query(Policy)
            .filter(Policy.is_deleted.is_(False))
            .join(Insurer, Policy.insurer_id == Insurer.id, isouter=True)
            .with_entities(Insurer.name, func.count(Policy.id))
            .group_by(Insurer.name)
            .order_by(func.count(Policy.id).desc())
            .all()
        )
        operator_mix = (
            scoped_query(Policy)
            .filter(Policy.is_deleted.is_(False))
            .join(MedicalOperator, Policy.operator_id == MedicalOperator.id, isouter=True)
            .with_entities(MedicalOperator.name, func.count(Policy.id))
            .group_by(MedicalOperator.name)
            .order_by(func.count(Policy.id).desc())
            .all()
        )
        production_by_user = (
            scoped_query(Policy)
            .filter(Policy.is_deleted.is_(False))
            .join(User, Policy.assigned_user_id == User.id, isouter=True)
            .with_entities(
                User.name,
                func.count(Policy.id),
                func.coalesce(func.sum(Policy.premium_value), 0),
                func.coalesce(func.sum(Policy.commission_value), 0),
            )
            .group_by(User.name)
            .order_by(func.coalesce(func.sum(Policy.premium_value), 0).desc())
            .all()
        )
        claim_funnel = (
            scoped_query(Claim)
            .filter(Claim.is_deleted.is_(False))
            .with_entities(Claim.stage, func.count(Claim.id))
            .group_by(Claim.stage)
            .order_by(func.count(Claim.id).desc())
            .all()
        )
        summary = {
            "clients": scoped_query(Client).filter_by(is_deleted=False).count(),
            "policies": scoped_query(Policy).filter_by(is_deleted=False).count(),
            "renewals_open": scoped_query(Renewal).filter(
                Renewal.stage.in_(["pendente", "em_contato", "cotando", "proposta_enviada", "aguardando_retorno", "negociacao", "urgente"])
            ).count(),
            "imports": scoped_query(ImportBatch).count(),
            "notifications": notifications,
            "claims_open": claims_open,
            "premium_total": float(base_policy.with_entities(func.coalesce(func.sum(Policy.premium_value), 0)).scalar() or 0),
            "commission_total": float(base_policy.with_entities(func.coalesce(func.sum(Policy.commission_value), 0)).scalar() or 0),
        }
        insurance_types = [item.name for item in InsuranceType.query.order_by(InsuranceType.name.asc()).all()]
        providers = [
            (f"insurer:{item.id}", f"Seguradora • {item.name}")
            for item in scoped_query(Insurer).filter_by(is_deleted=False).order_by(Insurer.name.asc()).all()
        ] + [
            (f"operator:{item.id}", f"Saúde • {item.name}")
            for item in scoped_query(MedicalOperator).filter_by(is_deleted=False).order_by(MedicalOperator.name.asc()).all()
        ]

        partner_performance = self.partner_performance()
        return {
            "summary": summary,
            "expiring": expiring,
            "overdue": overdue,
            "pipeline": pipeline,
            "insurer_mix": insurer_mix,
            "operator_mix": operator_mix,
            "partner_performance": partner_performance,
            "production_by_user": production_by_user,
            "claim_funnel": claim_funnel,
            "period": days,
            "status": status,
            "insurance_type": insurance_type,
            "insurance_types": insurance_types,
            "provider": provider,
            "providers": providers,
        }

    def partner_performance(self):
        rows = []
        for provider_obj in scoped_query(Insurer).filter_by(is_deleted=False).all():
            qty, premium, commission = self._provider_policy_aggregates(provider_kind="insurer", provider_id=provider_obj.id)
            if qty:
                rows.append((provider_obj.name, "Seguradora", qty, premium, commission, provider_obj.relationship_status or "ativo"))
        for provider_obj in scoped_query(MedicalOperator).filter_by(is_deleted=False).all():
            qty, premium, commission = self._provider_policy_aggregates(provider_kind="operator", provider_id=provider_obj.id)
            if qty:
                rows.append((provider_obj.name, "Operadora saúde", qty, premium, commission, provider_obj.relationship_status or "ativo"))
        return sorted(rows, key=lambda item: (-item[2], item[0]))

    def _provider_policy_aggregates(self, *, provider_kind: str, provider_id: int):
        query = scoped_query(Policy).filter(Policy.is_deleted.is_(False))
        if provider_kind == "insurer":
            query = query.filter(Policy.insurer_id == provider_id)
        else:
            query = query.filter(Policy.operator_id == provider_id)

        values = query.with_entities(
            func.count(Policy.id),
            func.coalesce(func.sum(Policy.premium_value), 0),
            func.coalesce(func.sum(Policy.commission_value), 0),
        ).first()
        qty, premium, commission = values
        return int(qty or 0), float(premium or 0), float(commission or 0)

    def expiring_csv_content(self, *, days: int = 30) -> str:
        today = date.today()
        end_date = today + timedelta(days=days)
        rows = (
            scoped_query(Policy)
            .filter(Policy.is_deleted.is_(False), Policy.ends_at.between(today, end_date))
            .order_by(Policy.ends_at.asc())
            .all()
        )
        output = StringIO()
        writer = csv.writer(output, delimiter=";")
        writer.writerow(["Cliente", "Apólice", "Tipo", "Status", "Vigência final", "Dias restantes"])
        for row in rows:
            writer.writerow([
                row.client.full_name if row.client else "",
                row.policy_number,
                row.insurance_type.name if row.insurance_type else "",
                row.status,
                row.ends_at.strftime("%d/%m/%Y") if row.ends_at else "",
                row.days_to_expire,
            ])
        return output.getvalue()

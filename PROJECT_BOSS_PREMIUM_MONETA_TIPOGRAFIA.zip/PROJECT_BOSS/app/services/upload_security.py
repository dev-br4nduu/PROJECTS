from __future__ import annotations
import os
from flask import current_app
from werkzeug.datastructures import FileStorage

DEFAULT_ALLOWED = {"pdf", "png", "jpg", "jpeg", "webp", "xlsx", "xls", "doc", "docx"}
DANGEROUS_EXTENSIONS = {"exe", "bat", "cmd", "ps1", "js", "vbs", "msi", "scr", "com", "dll", "jar", "sh"}


def allowed_extensions() -> set[str]:
    raw = current_app.config.get("ALLOWED_UPLOAD_EXTENSIONS")
    if not raw:
        return DEFAULT_ALLOWED
    if isinstance(raw, (list, tuple, set)):
        return {str(x).lower().strip() for x in raw if str(x).strip()}
    return {item.strip().lower() for item in str(raw).split(",") if item.strip()}


def validate_upload(file: FileStorage | None) -> tuple[bool, str | None]:
    if not file or not getattr(file, "filename", ""):
        return False, "Selecione um arquivo para envio."
    filename = file.filename.strip()
    if "." not in filename:
        return False, "O arquivo precisa ter uma extensão válida."
    ext = filename.rsplit(".", 1)[1].lower()
    if ext in DANGEROUS_EXTENSIONS:
        return False, "Esse tipo de arquivo não é permitido por segurança."
    if ext not in allowed_extensions():
        return False, "Formato de arquivo não permitido."
    content_type = (getattr(file, "mimetype", "") or "").lower()
    if ext == "pdf" and content_type and "pdf" not in content_type:
        return False, "O arquivo informado não parece ser um PDF válido."
    return True, None


def safe_storage_path(*parts: str) -> str:
    base = current_app.config.get("UPLOAD_FOLDER", "uploads")
    return os.path.join(base, *parts)

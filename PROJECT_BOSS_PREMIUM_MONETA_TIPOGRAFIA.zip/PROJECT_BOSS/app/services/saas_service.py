import json
from datetime import date, timedelta, datetime
from werkzeug.security import generate_password_hash
from app import db
from app.models.user import User
from app.models.core import Organization, SaaSPlan, OrganizationSubscription, OnboardingRequest, AuditLog

DEFAULT_PLANS = [
    {"code": "start", "name": "Start", "monthly_price": 149, "annual_price": 1490, "max_users": 3, "max_storage_gb": 5, "features": ["clientes", "apolices", "renovacoes"]},
    {"code": "pro", "name": "Pro", "monthly_price": 299, "annual_price": 2990, "max_users": 10, "max_storage_gb": 25, "features": ["clientes", "apolices", "renovacoes", "crm", "parceiros", "relatorios"]},
    {"code": "premium", "name": "Premium", "monthly_price": 599, "annual_price": 5990, "max_users": 999, "max_storage_gb": 100, "features": ["clientes", "apolices", "renovacoes", "crm", "parceiros", "relatorios", "notificacoes", "analytics"]},
]


def ensure_default_plans():
    changed = False
    for plan in DEFAULT_PLANS:
        row = SaaSPlan.query.filter_by(code=plan["code"]).first()
        if not row:
            row = SaaSPlan(code=plan["code"], name=plan["name"])
        row.description = f"Plano {plan['name']} da plataforma SaaS"
        row.monthly_price = plan["monthly_price"]
        row.annual_price = plan["annual_price"]
        row.max_users = plan["max_users"]
        row.max_storage_gb = plan["max_storage_gb"]
        row.features_json = json.dumps(plan["features"])
        row.is_active = True
        db.session.add(row)
        changed = True
    if changed:
        db.session.commit()


def get_plan_by_code(code: str):
    ensure_default_plans()
    return SaaSPlan.query.filter_by(code=(code or 'pro').strip().lower(), is_active=True).first()


def get_plan_features_for_org(org):
    if not org:
        return []
    sub = OrganizationSubscription.query.filter_by(organization_id=org.id).order_by(OrganizationSubscription.id.desc()).first()
    if sub and sub.plan and sub.plan.features_json:
        try:
            return json.loads(sub.plan.features_json)
        except Exception:
            return []
    return []


def provision_organization_from_signup(*, organization_name, organization_slug, contact_name, contact_email, password, plan_code='pro', contact_phone=None, actor_user_id=None):
    slug = organization_slug.strip().lower()
    if Organization.query.filter_by(slug=slug).first():
        raise ValueError('Workspace já existe.')
    plan = get_plan_by_code(plan_code)
    if not plan:
        raise ValueError('Plano inválido.')

    org = Organization(
        name=organization_name.strip(),
        slug=slug,
        contact_email=contact_email.strip().lower(),
        current_plan_code=plan.code,
        onboarding_status='onboarded',
        trial_ends_at=date.today() + timedelta(days=14),
        onboarded_at=datetime.utcnow(),
        is_active=True,
    )
    db.session.add(org)
    db.session.flush()

    admin = User(
        organization_id=org.id,
        name=contact_name.strip(),
        email=contact_email.strip().lower(),
        role='admin',
        is_active=True,
        password_hash=generate_password_hash(password),
    )
    db.session.add(admin)
    db.session.flush()

    sub = OrganizationSubscription(
        organization_id=org.id,
        plan_id=plan.id,
        status='trialing',
        started_at=date.today(),
        trial_ends_at=date.today() + timedelta(days=14),
        current_period_end=date.today() + timedelta(days=30),
        seats_purchased=max(1, plan.max_users or 1),
        notes=f'Provisionado automaticamente para {contact_phone or "n/a"}',
    )
    db.session.add(sub)
    db.session.flush()

    req = OnboardingRequest(
        organization_name=organization_name.strip(),
        organization_slug=slug,
        contact_name=contact_name.strip(),
        contact_email=contact_email.strip().lower(),
        contact_phone=contact_phone or '',
        selected_plan_code=plan.code,
        status='provisioned',
        provisioned_organization_id=org.id,
        notes='Onboarding self-service concluído',
    )
    db.session.add(req)
    db.session.add(AuditLog(action='create', entity='organization_signup', entity_id=str(org.id), detail=f'Workspace provisionado automaticamente no plano {plan.code}', user_id=actor_user_id, organization_id=org.id))
    db.session.commit()
    return org, admin, sub

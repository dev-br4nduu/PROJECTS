"""Casos de uso de importação e trilha operacional."""
from __future__ import annotations

from flask_login import current_user

from app.models.core import ImportBatch
from app.repositories.import_batches import ImportBatchRepository
from app.services.audit_service import log_event
from app.services.import_service import import_clients_from_excel, import_policies_from_excel
from app.utils.tenancy import assign_organization


class ImportAppService:
    def __init__(self, repository: ImportBatchRepository | None = None):
        self.repository = repository or ImportBatchRepository()

    def recent_batches(self, *, limit: int = 20):
        return self.repository.recent(limit=limit)

    def process_upload(self, form):
        file = form.spreadsheet.data
        filename = getattr(file, "filename", "importacao.xlsx")
        result = import_clients_from_excel(file) if form.import_type.data == "clients" else import_policies_from_excel(file)

        batch = ImportBatch(
            import_type=form.import_type.data,
            file_name=filename,
            rows_created=result["created"],
            rows_updated=result["updated"],
            rows_error=len(result["errors"]),
            note="Carga via Excel / histórico legado",
            imported_by=current_user.id,
        )
        assign_organization(batch)
        self.repository.save(batch)
        log_event("import", form.import_type.data, detail=str(result))
        self.repository.commit()
        return result

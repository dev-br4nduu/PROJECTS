"""Regras de negócio do módulo de clientes."""
from __future__ import annotations

from app.models.core import Client
from app.repositories.clients import ClientRepository
from app.services.audit_service import log_event
from app.utils.tenancy import assign_organization, assert_same_org


class ClientService:
    def __init__(self, repository: ClientRepository | None = None):
        self.repository = repository or ClientRepository()

    def paginate(self, *, q: str = "", status: str = "", page: int = 1, per_page: int = 20):
        query = self.repository.list_filtered(q=q, status=status)
        return query.order_by(Client.full_name.asc()).paginate(
            page=page,
            per_page=per_page,
            error_out=False,
        )

    def create_from_form(self, form):
        client = Client()
        form.populate_obj(client)
        assign_organization(client)
        self.repository.save(client, flush=True)
        log_event("create", "client", client.id, f"Cliente {client.full_name}")
        self.repository.commit()
        return client

    def update_from_form(self, client_id: int, form):
        client = self.repository.get_active_or_404(client_id)
        assert_same_org(client)
        form.populate_obj(client)
        log_event("update", "client", client.id, f"Cliente {client.full_name}")
        self.repository.commit()
        return client

    def archive(self, client_id: int):
        client = self.repository.get_active_or_404(client_id)
        assert_same_org(client)
        client.soft_delete()
        log_event("archive", "client", client.id, f"Cliente {client.full_name}")
        self.repository.commit()
        return client

    def get_for_view(self, client_id: int):
        client = self.repository.get_active_or_404(client_id)
        assert_same_org(client)
        return client

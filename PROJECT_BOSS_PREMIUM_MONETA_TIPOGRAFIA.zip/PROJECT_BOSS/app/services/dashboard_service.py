from __future__ import annotations

from collections import OrderedDict
from datetime import date, timedelta
from sqlalchemy import func

from app.models.core import Client, Vehicle, Driver, Claim, CRMOpportunity, ImportBatch, DocumentFile, Insurer, MedicalOperator
from app.models.insurance import Policy, Renewal, NotificationLog
from app.services.business_rules import recommendation_status, line_kind
from app.utils.tenancy import scoped_query


def build_dashboard_snapshot():
    today = date.today()
    in_30 = today + timedelta(days=30)
    month_start = today.replace(day=1)

    active_clients = scoped_query(Client).filter_by(is_deleted=False, status='ativo').count()
    inactive_clients = scoped_query(Client).filter_by(is_deleted=False, status='inativo').count()
    prospects = scoped_query(Client).filter_by(is_deleted=False, status='prospect').count()
    expiring = scoped_query(Policy).filter(Policy.is_deleted.is_(False), Policy.ends_at.between(today, in_30)).count()
    renewed = scoped_query(Renewal).filter(Renewal.stage == 'renovado').count()

    clients = scoped_query(Client).filter_by(is_deleted=False).all()
    recovery_clients = sum(1 for client in clients if recommendation_status(client) == 'reconquistar')

    open_stages = ['lead', 'contato', 'cotacao', 'proposta']
    proposals_pending = scoped_query(CRMOpportunity).filter(CRMOpportunity.is_deleted.is_(False), CRMOpportunity.stage == 'proposta').count()
    proposals_to_send = scoped_query(CRMOpportunity).filter(CRMOpportunity.is_deleted.is_(False), CRMOpportunity.stage == 'cotacao').count()
    proposals_waiting = scoped_query(CRMOpportunity).filter(CRMOpportunity.is_deleted.is_(False), CRMOpportunity.stage.in_(['contato', 'proposta'])).count()
    opportunities_open = scoped_query(CRMOpportunity).filter(CRMOpportunity.is_deleted.is_(False), CRMOpportunity.stage.in_(open_stages)).count()

    active_policies_q = scoped_query(Policy).filter(Policy.is_deleted.is_(False), Policy.status == 'ativa')
    active_policies = active_policies_q.all()
    new_policies = scoped_query(Policy).filter(Policy.is_deleted.is_(False), Policy.created_at >= month_start).count()
    overdue = scoped_query(Policy).filter(Policy.is_deleted.is_(False), Policy.ends_at < today, Policy.status == 'ativa').count()
    due_today = scoped_query(Policy).filter(Policy.is_deleted.is_(False), Policy.ends_at == today).count()
    renewals_today = scoped_query(Renewal).filter(Renewal.next_action_at == today).count()
    notifications_today = scoped_query(NotificationLog).filter(func.date(NotificationLog.sent_at) == today).count()
    claims_open = scoped_query(Claim).filter(Claim.is_deleted.is_(False), Claim.status.in_(['aberto', 'em_analise', 'documentacao'])).count()

    commissions_month = sum(float(p.commission_value or 0) for p in scoped_query(Policy).filter(Policy.is_deleted.is_(False), Policy.created_at >= month_start).all())

    line_stats = OrderedDict([
        ('Seguro Auto', 0), ('Convênio Médico', 0), ('Seguro Residencial', 0), ('Eletro / Eletrodomésticos', 0), ('Consórcio', 0), ('Outros produtos', 0),
    ])
    for policy in active_policies:
        kind = line_kind(policy)
        if kind == 'auto': line_stats['Seguro Auto'] += 1
        elif kind == 'health': line_stats['Convênio Médico'] += 1
        elif kind == 'residential': line_stats['Seguro Residencial'] += 1
        elif kind == 'electro': line_stats['Eletro / Eletrodomésticos'] += 1
        elif kind == 'consortium': line_stats['Consórcio'] += 1
        else: line_stats['Outros produtos'] += 1

    partner_rows = []
    for policy in active_policies:
        if policy.insurer:
            partner_rows.append((f'insurer:{policy.insurer_id}', policy.insurer.name, 'Seguradora'))
        elif policy.operator:
            partner_rows.append((f'operator:{policy.operator_id}', policy.operator.name, 'Operadora saúde'))
    grouped = OrderedDict()
    for key, name, kind in partner_rows:
        if key not in grouped:
            grouped[key] = {'name': name, 'kind': kind, 'qty': 0}
        grouped[key]['qty'] += 1
    top_partners = sorted(grouped.values(), key=lambda x: (-x['qty'], x['name']))[:6]
    strategic_insurers = scoped_query(Insurer).filter_by(is_deleted=False, is_active=True, relationship_status='estrategico').count()
    strategic_operators = scoped_query(MedicalOperator).filter_by(is_deleted=False, is_active=True, relationship_status='estrategico').count()

    total_clients = len(clients)
    active_pct = round((active_clients / total_clients) * 100, 1) if total_clients else 0
    inactive_pct = round((inactive_clients / total_clients) * 100, 1) if total_clients else 0
    recovery_pct = round((recovery_clients / total_clients) * 100, 1) if total_clients else 0
    renewable_base = max(len(active_policies), 1)
    renewal_pct = round((renewed / renewable_base) * 100, 1)

    stats = {
        'clients': total_clients,
        'active_clients': active_clients,
        'inactive_clients': inactive_clients,
        'prospects': prospects,
        'recovery_clients': recovery_clients,
        'active_clients_pct': active_pct,
        'inactive_clients_pct': inactive_pct,
        'recovery_clients_pct': recovery_pct,
        'new_clients': scoped_query(Client).filter(Client.is_deleted.is_(False), Client.created_at >= month_start).count(),
        'vehicles': scoped_query(Vehicle).filter_by(is_deleted=False).count(),
        'drivers': scoped_query(Driver).filter_by(is_deleted=False).count(),
        'documents': scoped_query(DocumentFile).filter_by(is_deleted=False).count(),
        'active_policies': len(active_policies),
        'new_policies': new_policies,
        'renewed_policies': renewed,
        'renewal_success_pct': renewal_pct,
        'expiring_30': expiring,
        'due_today': due_today,
        'renewals_today': renewals_today,
        'overdue': overdue,
        'notifications_today': notifications_today,
        'claims_open': claims_open,
        'opportunities_open': opportunities_open,
        'proposals_pending': proposals_pending,
        'proposals_to_send': proposals_to_send,
        'proposals_waiting': proposals_waiting,
        'imports': scoped_query(ImportBatch).count(),
        'commissions_month': float(commissions_month),
        'line_stats': line_stats,
        'providers_total': scoped_query(Insurer).filter_by(is_deleted=False).count() + scoped_query(MedicalOperator).filter_by(is_deleted=False).count(),
        'strategic_partners': strategic_insurers + strategic_operators,
        'top_partners': top_partners,
    }
    expiring_rows = scoped_query(Policy).filter(Policy.is_deleted.is_(False), Policy.ends_at.between(today, in_30)).order_by(Policy.ends_at.asc()).limit(8).all()
    renewals = scoped_query(Renewal).order_by(Renewal.next_action_at.asc().nullslast()).limit(8).all()
    claims = scoped_query(Claim).filter(Claim.is_deleted.is_(False)).order_by(Claim.created_at.desc()).limit(6).all()
    opportunities = scoped_query(CRMOpportunity).filter(CRMOpportunity.is_deleted.is_(False)).order_by(CRMOpportunity.expected_close_date.asc().nullslast()).limit(6).all()
    return stats, expiring_rows, renewals, claims, opportunities

from __future__ import annotations

from datetime import date
from flask import render_template
from app import db
from app.models.insurance import Policy, NotificationLog
from app.models.user import User
from app.services.email_service import send_email

CLIENT_NOTIFICATION_STEPS = [20, 15, 10, 5, 0]
INTERNAL_NOTIFICATION_STEPS = [30, 20, 15, 10, 5, 0]


def _already_sent(policy_id, target_email, notification_type, days_before=None):
    query = NotificationLog.query.filter_by(policy_id=policy_id, target_email=target_email, notification_type=notification_type)
    if days_before is not None:
        query = query.filter_by(days_before=days_before)
    return query.first() is not None


def _send(policy, target, notification_type, days, subject, template_name, text_body):
    html_body = render_template(template_name, policy=policy, days=days)
    send_email(subject=subject, recipients=[target], html_body=html_body, text_body=text_body)
    db.session.add(NotificationLog(
        policy_id=policy.id,
        notification_type=notification_type,
        target_email=target,
        days_before=days,
        status="sent",
    ))


def process_due_notifications():
    today = date.today()
    created = 0
    policies = Policy.query.filter(Policy.status == "ativa").all()
    for policy in policies:
        if not policy.client or not policy.ends_at:
            continue

        renewal = policy.renewal
        days = (policy.ends_at - today).days
        client_emails = {e.strip() for e in [policy.client.email, policy.client.secondary_email] if e and str(e).strip()}
        internal_emails = set()
        if policy.assigned_user_id:
            broker = db.session.get(User, policy.assigned_user_id)
            if broker and broker.email:
                internal_emails.add(broker.email.strip())

        # success email when renewal was concluded
        if renewal and renewal.stage == "renovado":
            for target in client_emails:
                if _already_sent(policy.id, target, "renewal_success"):
                    continue
                try:
                    _send(
                        policy,
                        target,
                        "renewal_success",
                        max(days, 0),
                        f"Renovação concluída - {policy.policy_number}",
                        "emails/renewal_success.html",
                        f"Sua renovação da apólice {policy.policy_number} foi concluída com sucesso.",
                    )
                    created += 1
                except Exception as exc:
                    db.session.add(NotificationLog(policy_id=policy.id, notification_type="renewal_success", target_email=target, days_before=max(days, 0), status="error", error_message=str(exc)))
            db.session.commit()
            continue

        if days in INTERNAL_NOTIFICATION_STEPS:
            for target in internal_emails:
                if _already_sent(policy.id, target, "internal_due_policy", days):
                    continue
                try:
                    _send(
                        policy,
                        target,
                        "internal_due_policy",
                        days,
                        f"Acompanhar renovação - {policy.policy_number}",
                        "emails/internal_policy_due.html",
                        f"A apólice {policy.policy_number} do cliente {policy.client.full_name} vence em {days} dia(s).",
                    )
                    created += 1
                except Exception as exc:
                    db.session.add(NotificationLog(policy_id=policy.id, notification_type="internal_due_policy", target_email=target, days_before=days, status="error", error_message=str(exc)))

        # Only notify client when not renewed yet.
        if days in CLIENT_NOTIFICATION_STEPS and (not renewal or renewal.stage != "renovado"):
            for target in client_emails:
                if _already_sent(policy.id, target, "due_policy", days):
                    continue
                try:
                    _send(
                        policy,
                        target,
                        "due_policy",
                        days,
                        f"Sua apólice vence em breve - {policy.policy_number}",
                        "emails/policy_due.html",
                        f"Sua apólice {policy.policy_number} vence em {days} dia(s).",
                    )
                    created += 1
                except Exception as exc:
                    db.session.add(NotificationLog(policy_id=policy.id, notification_type="due_policy", target_email=target, days_before=days, status="error", error_message=str(exc)))
        db.session.commit()
    return created

from __future__ import annotations
import re
from flask import current_app


def password_policy_rules() -> dict:
    return {
        "min_length": int(current_app.config.get("PASSWORD_MIN_LENGTH", 10)),
        "require_upper": bool(current_app.config.get("PASSWORD_REQUIRE_UPPER", True)),
        "require_lower": bool(current_app.config.get("PASSWORD_REQUIRE_LOWER", True)),
        "require_digit": bool(current_app.config.get("PASSWORD_REQUIRE_DIGIT", True)),
        "require_symbol": bool(current_app.config.get("PASSWORD_REQUIRE_SYMBOL", True)),
    }


def validate_password_strength(password: str | None) -> list[str]:
    password = password or ""
    rules = password_policy_rules()
    errors: list[str] = []
    if len(password) < rules["min_length"]:
        errors.append(f"A senha deve ter pelo menos {rules['min_length']} caracteres.")
    if rules["require_upper"] and not re.search(r"[A-Z]", password):
        errors.append("A senha deve conter ao menos uma letra maiúscula.")
    if rules["require_lower"] and not re.search(r"[a-z]", password):
        errors.append("A senha deve conter ao menos uma letra minúscula.")
    if rules["require_digit"] and not re.search(r"\d", password):
        errors.append("A senha deve conter ao menos um número.")
    if rules["require_symbol"] and not re.search(r"[^A-Za-z0-9]", password):
        errors.append("A senha deve conter ao menos um símbolo.")
    return errors

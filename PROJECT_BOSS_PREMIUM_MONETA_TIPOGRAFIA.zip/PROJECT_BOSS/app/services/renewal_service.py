from datetime import date, timedelta
from app import db
from app.models.insurance import Renewal, Policy


def ensure_renewal_record(policy):
    renewal = policy.renewal
    if not renewal:
        renewal = Renewal(client_id=policy.client_id, policy_id=policy.id)
        db.session.add(renewal)
    days = policy.days_to_expire
    renewal.client_id = policy.client_id
    renewal.current_premium = policy.premium_value
    if policy.premium_value and not renewal.target_premium:
        renewal.target_premium = policy.premium_value
    if policy.assigned_user and policy.assigned_user.email and not renewal.owner_email:
        renewal.owner_email = policy.assigned_user.email
    if policy.status == 'cancelada':
        renewal.stage = 'perdido'
        renewal.priority = 'alta'
        renewal.next_action_at = None
        return renewal
    if days is None:
        renewal.stage = 'pendente'
        renewal.priority = 'normal'
        return renewal
    if renewal.stage == 'renovado':
        renewal.priority = 'normal'
        renewal.next_action_at = None
        return renewal
    if days <= 0:
        renewal.stage = 'vencido'
        renewal.priority = 'alta'
        renewal.next_action_at = date.today()
    elif days <= 5:
        renewal.stage = 'aguardando_retorno'
        renewal.priority = 'alta'
        renewal.next_action_at = date.today()
    elif days <= 10:
        renewal.stage = 'proposta_enviada'
        renewal.priority = 'alta'
        renewal.next_action_at = date.today() + timedelta(days=1)
    elif days <= 20:
        renewal.stage = 'cotando'
        renewal.priority = 'media'
        renewal.next_action_at = date.today() + timedelta(days=2)
    elif days <= 30:
        renewal.stage = 'em_contato'
        renewal.priority = 'normal'
        renewal.next_action_at = date.today() + timedelta(days=3)
    else:
        renewal.stage = 'pendente'
        renewal.priority = 'normal'
        renewal.next_action_at = policy.ends_at - timedelta(days=30)
    return renewal


def recalculate_renewals():
    count = 0
    for policy in Policy.query.all():
        ensure_renewal_record(policy)
        count += 1
    db.session.commit()
    return count

"""Regras de negócio do módulo de renovações."""
from __future__ import annotations

from app.repositories.renewals import RenewalRepository
from app.services.audit_service import log_event
from app.utils.tenancy import assert_same_org


class RenewalAppService:
    def __init__(self, repository: RenewalRepository | None = None):
        self.repository = repository or RenewalRepository()

    def list(self, *, provider: str = ""):
        renewals = self.repository.list_filtered(provider=provider).order_by(
            self.repository.model.next_action_at.asc().nullslast()
        ).all()
        return {"renewals": renewals, "providers": self.repository.provider_choices()}

    def get_for_edit(self, renewal_id: int):
        renewal = self.repository.get_or_404(renewal_id)
        assert_same_org(renewal)
        return renewal

    def update_from_form(self, renewal_id: int, form):
        renewal = self.repository.get_or_404(renewal_id)
        assert_same_org(renewal)
        form.populate_obj(renewal)
        log_event("update", "renewal", renewal.id, f"Renovação {renewal.policy.policy_number}")
        self.repository.commit()
        return renewal

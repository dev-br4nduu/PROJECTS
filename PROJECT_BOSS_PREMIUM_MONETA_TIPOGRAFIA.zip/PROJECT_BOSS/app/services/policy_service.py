"""Regras de negócio do módulo de apólices."""
from __future__ import annotations

from flask_login import current_user

from app.constants import INSURANCE_LINE_SLUGS
from app.models.core import AuditLog, Client, InsuranceType, Insurer, MedicalOperator, Vehicle
from app.models.insurance import Policy
from app.repositories.policies import PolicyRepository
from app.services.audit_service import log_event
from app.services.business_rules import (
    compute_commission_value,
    infer_policy_title,
    validate_policy_business_rules,
)
from app.services.proposal_service import build_whatsapp_link, send_proposal_email
from app.services.renewal_service import ensure_renewal_record
from app.extensions import db


class PolicyValidationError(ValueError):
    def __init__(self, errors: list[str]):
        super().__init__("Falha de validação da apólice.")
        self.errors = errors


class PolicyService:
    def __init__(self, repository: PolicyRepository | None = None):
        self.repository = repository or PolicyRepository()

    def get_form_choices(self):
        return {
            "client_id": [(c.id, c.full_name) for c in Client.query.filter_by(is_deleted=False).order_by(Client.full_name).all()],
            "vehicle_id": [(0, "Sem veículo")] + [(v.id, f"{v.plate or '-'} - {v.brand} {v.model}") for v in Vehicle.query.filter_by(is_deleted=False).order_by(Vehicle.plate.asc().nullslast()).all()],
            "insurance_type_id": [(i.id, i.name) for i in InsuranceType.query.order_by(InsuranceType.name).all()],
            "insurer_id": [(0, "Selecione")] + [(i.id, i.name) for i in Insurer.query.order_by(Insurer.name).all()],
            "operator_id": [(0, "Selecione")] + [(o.id, o.name) for o in MedicalOperator.query.order_by(MedicalOperator.name).all()],
        }

    def apply_form_choices(self, form):
        choices = self.get_form_choices()
        form.client_id.choices = choices["client_id"]
        form.vehicle_id.choices = choices["vehicle_id"]
        form.insurance_type_id.choices = choices["insurance_type_id"]
        form.insurer_id.choices = choices["insurer_id"]
        form.operator_id.choices = choices["operator_id"]

    def paginate(self, *, q="", status="", insurer="", provider="", line="", page=1, per_page=20):
        query, line_title = self.repository.list_filtered(
            q=q,
            status=status,
            insurer=insurer,
            provider=provider,
            line=line,
        )
        pagination = query.order_by(Policy.ends_at.asc()).paginate(
            page=page,
            per_page=per_page,
            error_out=False,
        )
        return {
            "pagination": pagination,
            "insurers": [x.name for x in Insurer.query.order_by(Insurer.name).all()],
            "providers": self.repository.provider_options(),
            "line_title": line_title,
            "insurance_lines": INSURANCE_LINE_SLUGS,
        }

    def _prepare_policy(self, policy: Policy, form):
        form.populate_obj(policy)
        policy.vehicle_id = None if form.vehicle_id.data == 0 else form.vehicle_id.data
        policy.insurer_id = None if form.insurer_id.data == 0 else form.insurer_id.data
        policy.operator_id = None if form.operator_id.data == 0 else form.operator_id.data
        if not policy.assigned_user_id and current_user.role in ["broker", "manager", "admin"]:
            policy.assigned_user_id = current_user.id
        if policy.premium_value and policy.commission_rate and not policy.commission_value:
            policy.commission_value = compute_commission_value(policy.premium_value, policy.commission_rate)
        if not (policy.title or "").strip():
            policy.title = infer_policy_title(policy)
        errors = validate_policy_business_rules(policy)
        if errors:
            raise PolicyValidationError(errors)
        return policy

    def create_from_form(self, form):
        policy = self._prepare_policy(Policy(), form)
        self.repository.save(policy, flush=True)
        ensure_renewal_record(policy)
        db.session.add(
            AuditLog(
                action="create",
                entity="policy",
                entity_id=str(policy.id),
                detail=f"Apólice {policy.policy_number}",
                user_id=current_user.id,
            )
        )
        self.repository.commit()
        return policy

    def update_from_form(self, policy_id: int, form):
        policy = self.repository.get_active_or_404(policy_id)
        self._prepare_policy(policy, form)
        ensure_renewal_record(policy)
        log_event("update", "policy", policy.id, f"Apólice {policy.policy_number}")
        self.repository.commit()
        return policy

    def archive(self, policy_id: int):
        policy = self.repository.get_active_or_404(policy_id)
        policy.soft_delete()
        log_event("archive", "policy", policy.id, f"Apólice {policy.policy_number}")
        self.repository.commit()
        return policy

    def get_for_view(self, policy_id: int):
        return self.repository.get_active_or_404(policy_id)

    def build_default_message(self, policy: Policy):
        return (
            f"Olá, {policy.client.full_name}. Segue sua proposta/apólice {policy.policy_number} "
            f"da {policy.insurer.name if policy.insurer else (policy.operator.name if policy.operator else 'Boss Corretora')}."
        )

    def send_policy_email(self, *, policy: Policy, recipient: str, message: str):
        proposal_doc = self.repository.latest_proposal_document(policy.id)
        send_proposal_email(
            recipient=recipient,
            subject=f"Proposta / Apólice {policy.policy_number} - Boss Corretora",
            message_html=f"<p>{message.replace(chr(10), '<br>')}</p>",
            message_text=message,
            attachment_path=proposal_doc.file_path if proposal_doc else None,
        )
        db.session.add(
            AuditLog(
                action="proposal_email",
                entity="policy",
                entity_id=str(policy.id),
                detail=f"Proposta enviada por e-mail para {recipient}",
                user_id=current_user.id,
            )
        )
        self.repository.commit()

    def build_whatsapp_redirect(self, *, phone: str, message: str):
        return build_whatsapp_link(phone, message)

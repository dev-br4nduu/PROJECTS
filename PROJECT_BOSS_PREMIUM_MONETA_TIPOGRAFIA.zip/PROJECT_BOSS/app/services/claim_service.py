"""Regras de negócio do módulo de sinistros."""
from __future__ import annotations

from datetime import date

from app.models.core import Claim, Client
from app.models.insurance import Policy
from app.repositories.claims import ClaimRepository
from app.services.audit_service import log_event
from app.utils.tenancy import assign_organization, assert_same_org, scoped_query


class ClaimService:
    def __init__(self, repository: ClaimRepository | None = None):
        self.repository = repository or ClaimRepository()

    def get_form_choices(self):
        clients = [
            (c.id, c.full_name)
            for c in scoped_query(Client).filter_by(is_deleted=False).order_by(Client.full_name).all()
        ]
        policies = [
            (0, "Sem vínculo")
        ] + [
            (p.id, f"{p.policy_number} - {p.client.full_name}")
            for p in scoped_query(Policy).filter_by(is_deleted=False).order_by(Policy.policy_number).all()
        ]
        return {"client_id": clients, "policy_id": policies}

    def apply_form_choices(self, form):
        choices = self.get_form_choices()
        form.client_id.choices = choices["client_id"]
        form.policy_id.choices = choices["policy_id"]

    def paginate(self, *, q: str = "", status: str = "", provider: str = "", page: int = 1, per_page: int = 20):
        query = self.repository.list_filtered(q=q, status=status, provider=provider)
        return {
            "pagination": query.order_by(Claim.created_at.desc()).paginate(
                page=page,
                per_page=per_page,
                error_out=False,
            ),
            "providers": self.repository.provider_choices(),
        }

    def create_from_form(self, form):
        claim = Claim()
        form.populate_obj(claim)
        assign_organization(claim)
        claim.policy_id = None if form.policy_id.data == 0 else form.policy_id.data
        if claim.status in {"indenizado", "negado", "encerrado"} and not claim.closed_at:
            claim.closed_at = date.today()
        self.repository.save(claim, flush=True)
        log_event("create", "claim", claim.id, f"Sinistro {claim.claim_number or claim.id}")
        self.repository.commit()
        return claim

    def update_from_form(self, claim_id: int, form):
        claim = self.repository.get_active_or_404(claim_id)
        assert_same_org(claim)
        form.populate_obj(claim)
        claim.policy_id = None if form.policy_id.data == 0 else form.policy_id.data
        if claim.status in {"indenizado", "negado", "encerrado"} and not claim.closed_at:
            claim.closed_at = date.today()
        log_event("update", "claim", claim.id, f"Sinistro {claim.claim_number or claim.id}")
        self.repository.commit()
        return claim

    def archive(self, claim_id: int):
        claim = self.repository.get_active_or_404(claim_id)
        assert_same_org(claim)
        claim.soft_delete()
        log_event("archive", "claim", claim.id, f"Sinistro {claim.claim_number or claim.id}")
        self.repository.commit()
        return claim

    def get_for_view(self, claim_id: int):
        claim = self.repository.get_active_or_404(claim_id)
        assert_same_org(claim)
        return claim

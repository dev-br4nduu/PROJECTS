"""Casos de uso administrativos e de gestão da plataforma."""
from __future__ import annotations

from werkzeug.security import generate_password_hash
from flask_login import current_user

from app.models.core import Organization, SMTPSettings, Insurer, MedicalOperator, ProviderInteraction, SaaSPlan, OrganizationSubscription
from app.models.user import User
from app.repositories.admin import (
    NotificationRepository,
    OrganizationRepository,
    ProviderRepository,
    SaaSPlanRepository,
    SMTPSettingsRepository,
    SubscriptionRepository,
    UserRepository,
)
from app.services.audit_service import log_event
from app.services.email_service import test_smtp_configuration
from app.services.notification_service import process_due_notifications
from app.utils.tenancy import assign_organization, assert_same_org, current_organization_id


class AdminService:
    def __init__(
        self,
        organizations: OrganizationRepository | None = None,
        smtp_settings: SMTPSettingsRepository | None = None,
        users: UserRepository | None = None,
        providers: ProviderRepository | None = None,
        plans: SaaSPlanRepository | None = None,
        subscriptions: SubscriptionRepository | None = None,
        notifications: NotificationRepository | None = None,
    ):
        self.organizations = organizations or OrganizationRepository()
        self.smtp_settings = smtp_settings or SMTPSettingsRepository()
        self.users = users or UserRepository()
        self.providers = providers or ProviderRepository()
        self.plans = plans or SaaSPlanRepository()
        self.subscriptions = subscriptions or SubscriptionRepository()
        self.notifications = notifications or NotificationRepository()

    @staticmethod
    def is_platform_admin() -> bool:
        return getattr(current_user, "role", "") == "platform_admin"

    def organization_choices(self):
        return [(item.id, f"{item.name} ({item.slug})") for item in self.organizations.list_choices()]

    def list_organizations(self, *, q: str = ""):
        return self.organizations.list_filtered(q=q).all()

    def create_organization(self, form):
        organization = Organization()
        form.populate_obj(organization)
        organization.slug = (organization.slug or "").strip().lower()
        self.organizations.save(organization, flush=True)
        log_event("create", "organization", organization.id, f"Workspace {organization.slug}")
        self.organizations.commit()
        return organization

    def update_organization(self, organization_id: int, form):
        organization = self.organizations.get_active_or_404(organization_id)
        form.populate_obj(organization)
        organization.slug = (organization.slug or "").strip().lower()
        log_event("update", "organization", organization.id, f"Workspace {organization.slug}")
        self.organizations.commit()
        return organization

    def get_organization(self, organization_id: int):
        return self.organizations.get_active_or_404(organization_id)

    def get_smtp(self):
        return self.smtp_settings.get_active_for_org()

    def save_smtp_from_form(self, form):
        config = self.smtp_settings.get_active_for_org()
        existing_password = config.password_encrypted if config else None
        if not config:
            config = SMTPSettings()
            assign_organization(config)
        form.populate_obj(config)
        if not (form.password.data or "").strip():
            config.password_encrypted = existing_password
        config.active = True
        self.smtp_settings.save(config)
        log_event("update", "smtp", config.id or "new", "Configuração SMTP atualizada")
        self.smtp_settings.commit()
        return config

    def test_smtp_configuration(self):
        return test_smtp_configuration()

    def notifications_log(self, *, limit: int = 100):
        return self.notifications.recent_logs(limit=limit)

    def process_notifications_now(self):
        return process_due_notifications()

    def list_users(self, *, q: str = ""):
        return self.users.list_filtered(q=q, platform_admin=self.is_platform_admin()).all()

    def get_user(self, user_id: int):
        return self.users.get_visible_or_404(user_id, platform_admin=self.is_platform_admin())

    def create_user_from_form(self, form):
        organization_id = form.organization_id.data if self.is_platform_admin() and form.organization_id.data else current_organization_id()
        user = User(
            organization_id=organization_id,
            name=form.name.data.strip(),
            email=form.email.data.lower().strip(),
            role=form.role.data,
            is_active=form.is_active.data,
            password_hash=generate_password_hash(form.password.data or "Boss@12345"),
        )
        if not self.is_platform_admin() and user.role == "platform_admin":
            raise PermissionError("Somente platform admin pode criar outro platform admin.")
        self.users.save(user, flush=True)
        log_event("create", "user", user.id, f"Usuário {user.email}")
        self.users.commit()
        return user

    def update_user_from_form(self, user_id: int, form):
        user = self.get_user(user_id)
        user.name = form.name.data.strip()
        user.email = form.email.data.lower().strip()
        if self.is_platform_admin() or form.role.data != "platform_admin":
            user.role = form.role.data
        if self.is_platform_admin() and form.organization_id.data:
            user.organization_id = form.organization_id.data
        user.is_active = form.is_active.data
        if form.password.data:
            user.password_hash = generate_password_hash(form.password.data)
        log_event("update", "user", user.id, f"Usuário {user.email}")
        self.users.commit()
        return user

    def list_providers(self, *, q: str = ""):
        return {
            "insurers": self.providers.list_filtered(Insurer, q=q).all(),
            "operators": self.providers.list_filtered(MedicalOperator, q=q).all(),
        }

    @staticmethod
    def provider_form_context(kind: str):
        if kind == "insurer":
            return {
                "label": "Seguradora de veículos",
                "label_plural": "Seguradoras de veículos",
                "entity": "insurer",
            }
        return {
            "label": "Seguradora / operadora de saúde",
            "label_plural": "Seguradoras / operadoras de saúde",
            "entity": "medical_operator",
        }

    def create_provider(self, kind: str, form):
        model = Insurer if kind == "insurer" else MedicalOperator
        provider = model()
        form.populate_obj(provider)
        provider.name = (provider.name or "").strip()
        assign_organization(provider)
        self.providers.save(provider, flush=True)
        log_event("create", "insurer" if kind == "insurer" else "medical_operator", provider.id, f"{provider.name}")
        self.providers.commit()
        return provider

    def update_provider(self, kind: str, provider_id: int, form):
        model = Insurer if kind == "insurer" else MedicalOperator
        provider = self.providers.get_active_or_404(model, provider_id)
        assert_same_org(provider)
        form.populate_obj(provider)
        provider.name = (provider.name or "").strip()
        log_event("update", "insurer" if kind == "insurer" else "medical_operator", provider.id, f"{provider.name}")
        self.providers.commit()
        return provider

    def get_provider(self, kind: str, provider_id: int):
        if kind == "insurer":
            provider = self.providers.get_active_or_404(Insurer, provider_id)
            return provider, "insurer", "Seguradora de veículos"
        provider = self.providers.get_active_or_404(MedicalOperator, provider_id)
        return provider, "operator", "Operadora de saúde"

    def provider_detail_payload(self, kind: str, provider_id: int):
        company, provider_kind, provider_label = self.get_provider(kind, provider_id)
        return {
            "company": company,
            "provider_kind": provider_kind,
            "provider_label": provider_label,
            "metrics": self.providers.provider_metrics(provider_kind=provider_kind, provider_id=company.id),
            "interactions": self.providers.list_interactions(provider_kind=provider_kind, provider_id=company.id),
        }

    def create_provider_interaction(self, kind: str, provider_id: int, form):
        company, provider_kind, _provider_label = self.get_provider(kind, provider_id)
        interaction = ProviderInteraction(provider_kind=provider_kind, provider_id=company.id, created_by=current_user.id)
        form.populate_obj(interaction)
        assign_organization(interaction, company.organization_id)
        self.providers.save(interaction)
        log_event("create", "provider_interaction", company.id, f"Interação registrada para {company.name}")
        self.providers.commit()
        return interaction

    def list_plans(self):
        return self.plans.list_all()

    def create_plan(self, form):
        plan = SaaSPlan()
        form.populate_obj(plan)
        plan.code = (plan.code or "").strip().lower()
        self.plans.save(plan)
        log_event("create", "saas_plan", plan.code, f"Plano {plan.name}")
        self.plans.commit()
        return plan

    def get_subscription_context(self, organization_id: int):
        organization = self.get_organization(organization_id)
        subscription = self.subscriptions.get_latest_for_org(organization.id)
        return organization, subscription

    def subscription_choices(self):
        return [(item.id, f"{item.name} ({item.code})") for item in self.plans.list_active()]

    def save_subscription_from_form(self, organization_id: int, form):
        organization = self.get_organization(organization_id)
        subscription = self.subscriptions.get_latest_for_org(organization.id)
        if not subscription:
            subscription = OrganizationSubscription(organization_id=organization.id)
        form.populate_obj(subscription)
        plan = self.plans.get(subscription.plan_id)
        if plan:
            organization.current_plan_code = plan.code
        self.subscriptions.save(subscription)
        log_event("update", "organization_subscription", subscription.organization_id, f"Plano {organization.current_plan_code}")
        self.subscriptions.commit()
        return subscription

from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app import db
from app.forms import VehicleForm
from app.models.core import Client, Vehicle, AuditLog
from app.utils.security import role_required
from app.utils.query import get_page, get_per_page

vehicles_bp = Blueprint("vehicles", __name__, url_prefix="/vehicles")

def _fill_choices(form):
    form.client_id.choices = [(c.id, c.full_name) for c in Client.query.filter_by(is_deleted=False).order_by(Client.full_name).all()]

@vehicles_bp.route("/")
@login_required
@role_required("viewer")
def list_vehicles():
    q = request.args.get("q", "").strip()
    usage_type = request.args.get("usage_type", "")
    query = Vehicle.query.join(Client).filter(Vehicle.is_deleted.is_(False), Client.is_deleted.is_(False))
    if q:
        query = query.filter((Vehicle.plate.ilike(f"%{q}%")) | (Client.full_name.ilike(f"%{q}%")) | (Vehicle.model.ilike(f"%{q}%")) | (Vehicle.brand.ilike(f"%{q}%")))
    if usage_type:
        query = query.filter(Vehicle.usage_type == usage_type)
    pagination = query.order_by(Vehicle.created_at.desc()).paginate(page=get_page(), per_page=get_per_page(), error_out=False)
    return render_template("vehicles/list.html", vehicles=pagination.items, pagination=pagination, q=q, usage_type=usage_type)

@vehicles_bp.route("/new", methods=["GET", "POST"])
@login_required
@role_required("assistant")
def create_vehicle():
    form = VehicleForm()
    _fill_choices(form)
    if form.validate_on_submit():
        vehicle = Vehicle()
        form.populate_obj(vehicle)
        vehicle.plate = vehicle.plate.upper().strip() if vehicle.plate else None
        db.session.add(vehicle)
        db.session.flush()
        db.session.add(AuditLog(action="create", entity="vehicle", entity_id=str(vehicle.id), detail=f"Veículo {vehicle.plate or vehicle.model}", user_id=current_user.id))
        db.session.commit()
        flash("Veículo cadastrado com sucesso.", "success")
        return redirect(url_for("vehicles.list_vehicles"))
    return render_template("vehicles/form.html", form=form, mode="new")

@vehicles_bp.route("/<int:vehicle_id>/edit", methods=["GET", "POST"])
@login_required
@role_required("assistant")
def edit_vehicle(vehicle_id):
    vehicle = Vehicle.query.filter_by(id=vehicle_id, is_deleted=False).first_or_404()
    form = VehicleForm(obj=vehicle)
    form.obj = vehicle
    _fill_choices(form)
    if form.validate_on_submit():
        form.populate_obj(vehicle)
        vehicle.plate = vehicle.plate.upper().strip() if vehicle.plate else None
        db.session.add(AuditLog(action="update", entity="vehicle", entity_id=str(vehicle.id), detail=f"Veículo {vehicle.plate or vehicle.model}", user_id=current_user.id))
        db.session.commit()
        flash("Veículo atualizado com sucesso.", "success")
        return redirect(url_for("vehicles.list_vehicles"))
    return render_template("vehicles/form.html", form=form, mode="edit", vehicle=vehicle)

@vehicles_bp.route("/<int:vehicle_id>/archive", methods=["POST"])
@login_required
@role_required("manager")
def archive_vehicle(vehicle_id):
    vehicle = Vehicle.query.filter_by(id=vehicle_id, is_deleted=False).first_or_404()
    vehicle.soft_delete()
    db.session.add(AuditLog(action="archive", entity="vehicle", entity_id=str(vehicle.id), detail=f"Veículo {vehicle.plate or vehicle.model}", user_id=current_user.id))
    db.session.commit()
    flash("Veículo arquivado com sucesso.", "success")
    return redirect(url_for("vehicles.list_vehicles"))

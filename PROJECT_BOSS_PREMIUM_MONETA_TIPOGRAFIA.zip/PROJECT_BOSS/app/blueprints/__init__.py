# Pacote de blueprints (evita namespace implícito; PyInstaller inclui melhor).

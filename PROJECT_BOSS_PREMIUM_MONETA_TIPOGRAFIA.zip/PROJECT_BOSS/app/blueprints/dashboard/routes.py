from flask import Blueprint, render_template
from flask_login import login_required
from app.services.dashboard_service import build_dashboard_snapshot
from app.utils.security import role_required

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/")
@login_required
@role_required("viewer")
def index():
    stats, expiring_rows, renewals, claims, opportunities = build_dashboard_snapshot()
    return render_template("dashboard/index.html", stats=stats, expiring=expiring_rows, renewals=renewals, claims=claims, opportunities=opportunities)

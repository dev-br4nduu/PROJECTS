from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import login_required

from app.forms import OpportunityForm
from app.services.crm_service import CRMService
from app.utils.query import get_page, get_per_page
from app.utils.security import role_required

crm_bp = Blueprint("crm", __name__, url_prefix="/crm")
crm_service = CRMService()


@crm_bp.route("/")
@login_required
@role_required("viewer")
def list_opportunities():
    q = request.args.get("q", "").strip()
    stage = request.args.get("stage", "")
    provider = request.args.get("provider", "")
    payload = crm_service.paginate(
        q=q,
        stage=stage,
        provider=provider,
        page=get_page(),
        per_page=get_per_page(),
    )
    pagination = payload["pagination"]
    return render_template(
        "crm/list.html",
        opportunities=pagination.items,
        pagination=pagination,
        q=q,
        stage=stage,
        provider=provider,
        providers=payload["providers"],
    )


@crm_bp.route("/new", methods=["GET", "POST"])
@login_required
@role_required("assistant")
def create_opportunity():
    form = OpportunityForm()
    crm_service.apply_form_choices(form)
    if form.validate_on_submit():
        crm_service.create_from_form(form)
        flash("Oportunidade registrada com sucesso.", "success")
        return redirect(url_for("crm.list_opportunities"))
    return render_template("crm/form.html", form=form, mode="new")


@crm_bp.route("/<int:opp_id>/edit", methods=["GET", "POST"])
@login_required
@role_required("assistant")
def edit_opportunity(opp_id):
    opportunity = crm_service.get_for_view(opp_id)
    form = OpportunityForm(obj=opportunity)
    form.obj = opportunity
    crm_service.apply_form_choices(form)
    if request.method == "GET":
        form.client_id.data = opportunity.client_id or 0
        form.insurance_type_id.data = opportunity.insurance_type_id or 0
        form.insurer_id.data = opportunity.insurer_id or 0
        form.operator_id.data = opportunity.operator_id or 0
    if form.validate_on_submit():
        crm_service.update_from_form(opp_id, form)
        flash("Oportunidade atualizada com sucesso.", "success")
        return redirect(url_for("crm.list_opportunities"))
    return render_template("crm/form.html", form=form, mode="edit", opportunity=opportunity)


@crm_bp.route("/<int:opp_id>/archive", methods=["POST"])
@login_required
@role_required("manager")
def archive_opportunity(opp_id):
    crm_service.archive(opp_id)
    flash("Oportunidade arquivada com sucesso.", "success")
    return redirect(url_for("crm.list_opportunities"))

from flask import Blueprint, flash, redirect, render_template, url_for
from flask_login import login_required

from app.forms import RenewalForm
from app.services.renewal_app_service import RenewalAppService
from app.utils.filter_state import bind_filter_state
from app.utils.security import role_required

renewals_bp = Blueprint("renewals", __name__, url_prefix="/renewals")
renewal_service = RenewalAppService()


@renewals_bp.route("/")
@login_required
@role_required("viewer")
def list_renewals():
    filters = bind_filter_state("renewals", ["provider"])
    provider = filters.get("provider", "")
    payload = renewal_service.list(provider=provider)
    return render_template(
        "renewals/list.html",
        renewals=payload["renewals"],
        provider=provider,
        providers=payload["providers"],
    )


@renewals_bp.route("/<int:renewal_id>/edit", methods=["GET", "POST"])
@login_required
@role_required("broker")
def edit_renewal(renewal_id):
    renewal = renewal_service.get_for_edit(renewal_id)
    form = RenewalForm(obj=renewal)
    if form.validate_on_submit():
        renewal_service.update_from_form(renewal_id, form)
        flash("Renovação atualizada com sucesso.", "success")
        return redirect(url_for("renewals.list_renewals"))
    return render_template("renewals/form.html", form=form, renewal=renewal)

from datetime import date, timedelta
from flask import Blueprint, render_template
from flask_login import login_required
from app.models.core import Client, CRMOpportunity
from app.models.insurance import Renewal, Policy
from app.utils.security import permission_required

agenda_bp = Blueprint("agenda", __name__, url_prefix="/agenda")


@agenda_bp.route("/")
@login_required
@permission_required("agenda.view")
def index():
    """Agenda operacional: retornos de renovação, oportunidades e aniversários (escopo PDF)."""
    today = date.today()
    horizon = today + timedelta(days=30)
    renewals = (
        Renewal.query.join(Policy, Renewal.policy_id == Policy.id)
        .filter(
            Renewal.next_action_at.isnot(None),
            Renewal.next_action_at >= today,
            Renewal.next_action_at <= horizon,
        )
        .order_by(Renewal.next_action_at.asc())
        .limit(80)
        .all()
    )
    opportunities = (
        CRMOpportunity.query.filter(
            CRMOpportunity.is_deleted.is_(False),
            CRMOpportunity.expected_close_date.isnot(None),
            CRMOpportunity.expected_close_date >= today,
            CRMOpportunity.expected_close_date <= horizon,
        )
        .order_by(CRMOpportunity.expected_close_date.asc())
        .limit(80)
        .all()
    )
    clients = Client.query.filter(Client.is_deleted.is_(False), Client.birth_date.isnot(None)).all()
    birthdays = []
    for c in clients:
        bd = c.birth_date
        if not bd:
            continue
        try:
            next_bd = bd.replace(year=today.year)
        except ValueError:
            next_bd = date(today.year, bd.month, 28)
        if next_bd < today:
            try:
                next_bd = bd.replace(year=today.year + 1)
            except ValueError:
                next_bd = date(today.year + 1, bd.month, 28)
        if today <= next_bd <= horizon:
            birthdays.append((c, next_bd))
    birthdays.sort(key=lambda x: x[1])
    return render_template(
        "agenda/index.html",
        renewals=renewals,
        opportunities=opportunities,
        birthdays=birthdays[:50],
        today=today,
        horizon=horizon,
    )

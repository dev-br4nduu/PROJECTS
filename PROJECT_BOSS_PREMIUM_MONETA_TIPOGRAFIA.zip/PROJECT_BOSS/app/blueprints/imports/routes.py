from flask import Blueprint, flash, render_template
from flask_login import login_required

from app.forms import UploadImportForm
from app.services.import_app_service import ImportAppService
from app.utils.security import role_required

imports_bp = Blueprint("imports", __name__, url_prefix="/imports")
import_app_service = ImportAppService()


@imports_bp.route("/", methods=["GET", "POST"])
@login_required
@role_required("manager")
def import_center():
    form = UploadImportForm()
    result = None
    batches = import_app_service.recent_batches()
    if form.validate_on_submit():
        result = import_app_service.process_upload(form)
        flash(
            f"Importação concluída. Inseridos: {result['created']} | Atualizados: {result['updated']} | Erros: {len(result['errors'])}",
            "success",
        )
        batches = import_app_service.recent_batches()
    return render_template("imports/index.html", form=form, result=result, batches=batches)

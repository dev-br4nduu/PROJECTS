from datetime import datetime, timedelta
from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_user, logout_user, current_user, login_required
from werkzeug.security import check_password_hash, generate_password_hash
from app.forms import LoginForm, ForgotPasswordForm, ResetPasswordForm
from app.models.user import User
from app import db
from app.services.email_service import send_password_reset_email, verify_password_reset_token
from app.services.audit_service import log_event
from app.utils.tenancy import get_request_organization_slug, get_request_organization

auth_bp = Blueprint("auth", __name__, url_prefix="/auth")


def _resolve_login_org_slug(form):
    return (form.organization_slug.data or get_request_organization_slug() or "").strip().lower() or None


def _base_login_form(form_cls):
    form = form_cls()
    resolved = get_request_organization_slug()
    if request.method == "GET" and resolved and hasattr(form, "organization_slug"):
        form.organization_slug.data = resolved
    return form


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.index"))
    form = _base_login_form(LoginForm)
    if form.validate_on_submit():
        org_slug = _resolve_login_org_slug(form)
        user_query = User.query.filter(User.email == form.email.data.lower().strip())
        if org_slug:
            user_query = user_query.join(User.organization).filter_by(slug=org_slug, is_active=True)
        user = user_query.first()
        max_attempts = current_app.config.get("MAX_LOGIN_ATTEMPTS", 5)
        lock_minutes = current_app.config.get("LOGIN_LOCK_MINUTES", 15)
        now = datetime.utcnow()

        if current_app.config.get("REQUIRE_ORG_ON_LOGIN") and not org_slug:
            flash("Informe o workspace para entrar no ambiente SaaS.", "warning")
            return render_template("auth/login.html", form=form, resolved_org=get_request_organization())

        if user and user.locked_until and user.locked_until > now:
            remaining = int((user.locked_until - now).total_seconds() // 60) + 1
            flash(f"Usuário temporariamente bloqueado. Tente novamente em {remaining} minuto(s).", "warning")
            return render_template("auth/login.html", form=form, resolved_org=get_request_organization())

        if user and check_password_hash(user.password_hash, form.password.data) and user.is_active and user.organization and user.organization.is_active:
            login_user(user, remember=bool(form.remember.data))
            user.last_login_at = now
            user.failed_login_attempts = 0
            user.locked_until = None
            log_event("login", "user", user.id, f"Login efetuado no workspace {user.organization.slug}")
            db.session.commit()
            return redirect(url_for("dashboard.index"))

        if user:
            user.failed_login_attempts = (user.failed_login_attempts or 0) + 1
            if user.failed_login_attempts >= max_attempts:
                user.locked_until = now + timedelta(minutes=lock_minutes)
                user.failed_login_attempts = 0
                flash("Muitas tentativas inválidas. Usuário bloqueado temporariamente.", "danger")
            else:
                flash("Credenciais inválidas.", "danger")
            log_event("login_failed", "user", user.id, f"Tentativa inválida no workspace {org_slug or 'n/a'}")
            db.session.commit()
        else:
            ambiguous_count = User.query.filter(User.email == form.email.data.lower().strip()).count()
            if ambiguous_count > 1 and not org_slug:
                flash("Este e-mail existe em mais de um workspace. Informe o workspace para continuar.", "warning")
            else:
                flash("Credenciais inválidas.", "danger")
    return render_template("auth/login.html", form=form, resolved_org=get_request_organization())


@auth_bp.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.index"))
    form = _base_login_form(ForgotPasswordForm)
    if form.validate_on_submit():
        org_slug = _resolve_login_org_slug(form)
        query = User.query.filter(User.email == form.email.data.lower().strip())
        if org_slug:
            query = query.join(User.organization).filter_by(slug=org_slug, is_active=True)
        user = query.first()
        if user and user.is_active:
            ok, message = send_password_reset_email(user)
            flash(message, "success" if ok else "danger")
        else:
            flash("Se o e-mail existir e estiver ativo, enviaremos um link para redefinição.", "info")
        return redirect(url_for("auth.login", org=org_slug or None))
    return render_template("auth/forgot_password.html", form=form, resolved_org=get_request_organization())


@auth_bp.route("/reset-password/<token>", methods=["GET", "POST"])
def reset_password(token):
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.index"))
    user = verify_password_reset_token(token)
    if not user:
        flash("Token de redefinição inválido ou expirado.", "danger")
        return redirect(url_for("auth.forgot_password"))
    form = ResetPasswordForm()
    if form.validate_on_submit():
        user.password_hash = generate_password_hash(form.password.data)
        log_event("password_reset", "user", user.id, "Senha redefinida via token")
        db.session.commit()
        flash("Senha atualizada com sucesso. Faça login para continuar.", "success")
        return redirect(url_for("auth.login", org=user.organization.slug if user.organization else None))
    return render_template("auth/reset_password.html", form=form, resolved_org=user.organization)


@auth_bp.route("/logout", methods=["GET", "POST"])
@login_required
def logout():
    log_event("logout", "user", current_user.id, "Logoff manual")
    db.session.commit()
    logout_user()
    flash("Sessão encerrada com sucesso.", "success")
    return redirect(url_for("auth.login"))

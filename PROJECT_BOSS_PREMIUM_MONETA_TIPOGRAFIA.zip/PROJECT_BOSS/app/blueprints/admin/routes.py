from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from app.forms import (
    InsurerCompanyForm,
    MedicalOperatorCompanyForm,
    OrganizationForm,
    ProviderInteractionForm,
    SaaSPlanForm,
    SaaSSubscriptionForm,
    SMTPForm,
    UserForm,
)
from app.services.admin_service import AdminService
from app.utils.security import role_required
from app.utils.tenancy import current_organization_id

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")
admin_service = AdminService()


@admin_bp.route("/organizations")
@login_required
@role_required("platform_admin")
def organizations():
    q = request.args.get("q", "").strip()
    organizations = admin_service.list_organizations(q=q)
    return render_template("admin/organizations_list.html", organizations=organizations, q=q)


@admin_bp.route("/organizations/new", methods=["GET", "POST"])
@login_required
@role_required("platform_admin")
def create_organization():
    form = OrganizationForm()
    if form.validate_on_submit():
        admin_service.create_organization(form)
        flash("Workspace criado com sucesso.", "success")
        return redirect(url_for("admin.organizations"))
    return render_template("admin/organization_form.html", form=form, mode="new")


@admin_bp.route("/organizations/<int:org_id>/edit", methods=["GET", "POST"])
@login_required
@role_required("platform_admin")
def edit_organization(org_id):
    organization = admin_service.get_organization(org_id)
    form = OrganizationForm(obj=organization)
    form.obj = organization
    if form.validate_on_submit():
        admin_service.update_organization(org_id, form)
        flash("Workspace atualizado com sucesso.", "success")
        return redirect(url_for("admin.organizations"))
    return render_template("admin/organization_form.html", form=form, mode="edit", organization=organization)


@admin_bp.route("/smtp", methods=["GET", "POST"])
@login_required
@role_required("manager")
def smtp_settings():
    cfg = admin_service.get_smtp()
    form = SMTPForm(obj=cfg)
    if form.validate_on_submit():
        admin_service.save_smtp_from_form(form)
        flash("Configuração SMTP salva.", "success")
        return redirect(url_for("admin.smtp_settings"))
    return render_template("admin/smtp.html", form=form, cfg=cfg)


@admin_bp.route("/smtp/test", methods=["POST"])
@login_required
@role_required("manager")
def smtp_test():
    ok, message = admin_service.test_smtp_configuration()
    flash(message, "success" if ok else "danger")
    return redirect(url_for("admin.smtp_settings"))


@admin_bp.route("/notifications")
@login_required
@role_required("assistant")
def notifications():
    logs = admin_service.notifications_log()
    return render_template("admin/notifications.html", logs=logs)


@admin_bp.route("/notifications/process", methods=["POST"])
@login_required
@role_required("manager")
def process_notifications_now():
    count = admin_service.process_notifications_now()
    flash(f"Processamento manual concluído. Notificações registradas: {count}", "success")
    return redirect(url_for("admin.notifications"))


@admin_bp.route("/users")
@login_required
@role_required("admin")
def users():
    q = request.args.get("q", "").strip()
    users = admin_service.list_users(q=q)
    return render_template("admin/users.html", users=users, q=q)


@admin_bp.route("/users/new", methods=["GET", "POST"])
@login_required
@role_required("admin")
def create_user():
    form = UserForm()
    form.organization_id.choices = admin_service.organization_choices()
    if not admin_service.is_platform_admin():
        form.organization_id.data = current_organization_id()
    if form.validate_on_submit():
        try:
            admin_service.create_user_from_form(form)
            flash("Usuário criado com sucesso.", "success")
            return redirect(url_for("admin.users"))
        except PermissionError as exc:
            flash(str(exc), "danger")
    return render_template("admin/user_form.html", form=form, mode="new")


@admin_bp.route("/users/<int:user_id>/edit", methods=["GET", "POST"])
@login_required
@role_required("admin")
def edit_user(user_id):
    user = admin_service.get_user(user_id)
    form = UserForm(obj=user)
    form.obj = user
    form.organization_id.choices = admin_service.organization_choices()
    if request.method == "GET":
        form.password.data = ""
        form.organization_id.data = user.organization_id
    if form.validate_on_submit():
        admin_service.update_user_from_form(user_id, form)
        flash("Usuário atualizado com sucesso.", "success")
        return redirect(url_for("admin.users"))
    return render_template("admin/user_form.html", form=form, mode="edit", user=user)


@admin_bp.route("/providers")
@login_required
@role_required("manager")
def providers():
    q = request.args.get("q", "").strip()
    payload = admin_service.list_providers(q=q)
    return render_template("admin/providers_list.html", insurers=payload["insurers"], operators=payload["operators"], q=q)


@admin_bp.route("/providers/insurers/new", methods=["GET", "POST"])
@login_required
@role_required("manager")
def create_insurer():
    form = InsurerCompanyForm()
    if form.validate_on_submit():
        admin_service.create_provider("insurer", form)
        flash("Seguradora cadastrada com sucesso.", "success")
        return redirect(url_for("admin.providers"))
    return render_template("admin/provider_form.html", form=form, mode="new", kind="insurer", **admin_service.provider_form_context("insurer"))


@admin_bp.route("/providers/insurers/<int:company_id>/edit", methods=["GET", "POST"])
@login_required
@role_required("manager")
def edit_insurer(company_id):
    company, _provider_kind, _provider_label = admin_service.get_provider("insurer", company_id)
    form = InsurerCompanyForm(obj=company)
    form.obj = company
    if form.validate_on_submit():
        admin_service.update_provider("insurer", company_id, form)
        flash("Seguradora atualizada com sucesso.", "success")
        return redirect(url_for("admin.providers"))
    return render_template("admin/provider_form.html", form=form, mode="edit", company=company, kind="insurer", **admin_service.provider_form_context("insurer"))


@admin_bp.route("/providers/operators/new", methods=["GET", "POST"])
@login_required
@role_required("manager")
def create_medical_operator():
    form = MedicalOperatorCompanyForm()
    if form.validate_on_submit():
        admin_service.create_provider("operator", form)
        flash("Operadora de saúde cadastrada com sucesso.", "success")
        return redirect(url_for("admin.providers"))
    return render_template("admin/provider_form.html", form=form, mode="new", kind="operator", **admin_service.provider_form_context("operator"))


@admin_bp.route("/providers/operators/<int:company_id>/edit", methods=["GET", "POST"])
@login_required
@role_required("manager")
def edit_medical_operator(company_id):
    company, _provider_kind, _provider_label = admin_service.get_provider("operator", company_id)
    form = MedicalOperatorCompanyForm(obj=company)
    form.obj = company
    if form.validate_on_submit():
        admin_service.update_provider("operator", company_id, form)
        flash("Operadora de saúde atualizada com sucesso.", "success")
        return redirect(url_for("admin.providers"))
    return render_template("admin/provider_form.html", form=form, mode="edit", company=company, kind="operator", **admin_service.provider_form_context("operator"))


@admin_bp.route("/providers/<kind>/<int:company_id>")
@login_required
@role_required("manager")
def view_provider(kind, company_id):
    payload = admin_service.provider_detail_payload(kind, company_id)
    return render_template("admin/provider_detail.html", **payload)


@admin_bp.route("/providers/<kind>/<int:company_id>/interactions/new", methods=["GET", "POST"])
@login_required
@role_required("manager")
def create_provider_interaction(kind, company_id):
    company, provider_kind, provider_label = admin_service.get_provider(kind, company_id)
    form = ProviderInteractionForm()
    if form.validate_on_submit():
        admin_service.create_provider_interaction(kind, company_id, form)
        flash("Interação comercial registrada com sucesso.", "success")
        return redirect(url_for("admin.view_provider", kind=kind, company_id=company.id))
    return render_template(
        "admin/provider_interaction_form.html",
        form=form,
        company=company,
        provider_label=provider_label,
        provider_kind=provider_kind,
    )


@admin_bp.route("/plans")
@login_required
@role_required("platform_admin")
def plans():
    return render_template("admin/plans_list.html", plans=admin_service.list_plans())


@admin_bp.route("/plans/new", methods=["GET", "POST"])
@login_required
@role_required("platform_admin")
def create_plan():
    form = SaaSPlanForm()
    if form.validate_on_submit():
        admin_service.create_plan(form)
        flash("Plano criado com sucesso.", "success")
        return redirect(url_for("admin.plans"))
    return render_template("admin/plan_form.html", form=form, mode="new")


@admin_bp.route("/organizations/<int:org_id>/subscription", methods=["GET", "POST"])
@login_required
@role_required("platform_admin")
def organization_subscription(org_id):
    organization, subscription = admin_service.get_subscription_context(org_id)
    form = SaaSSubscriptionForm(obj=subscription)
    form.plan_id.choices = admin_service.subscription_choices()
    if form.validate_on_submit():
        admin_service.save_subscription_from_form(org_id, form)
        flash("Assinatura atualizada com sucesso.", "success")
        return redirect(url_for("admin.organizations"))
    return render_template("admin/subscription_form.html", form=form, organization=organization, subscription=subscription)

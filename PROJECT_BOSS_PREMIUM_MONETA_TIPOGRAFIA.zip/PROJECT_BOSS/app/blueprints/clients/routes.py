from flask import Blueprint, flash, redirect, render_template, url_for
from flask_login import login_required

from app.forms import ClientForm
from app.services.client_service import ClientService
from app.utils.filter_state import bind_filter_state
from app.utils.query import get_page, get_per_page
from app.utils.security import role_required

clients_bp = Blueprint("clients", __name__, url_prefix="/clients")
client_service = ClientService()


@clients_bp.route("/")
@login_required
@role_required("viewer")
def list_clients():
    filters = bind_filter_state("clients", ["q", "status"])
    q = filters.get("q", "").strip()
    status = filters.get("status", "")
    pagination = client_service.paginate(
        q=q,
        status=status,
        page=get_page(),
        per_page=get_per_page(),
    )
    return render_template(
        "clients/list.html",
        clients=pagination.items,
        pagination=pagination,
        q=q,
        status=status,
    )


@clients_bp.route("/new", methods=["GET", "POST"])
@login_required
@role_required("assistant")
def create_client():
    form = ClientForm()
    if form.validate_on_submit():
        client_service.create_from_form(form)
        flash("Cliente cadastrado com sucesso.", "success")
        return redirect(url_for("clients.list_clients"))
    return render_template("clients/form.html", form=form, mode="new")


@clients_bp.route("/<int:client_id>/edit", methods=["GET", "POST"])
@login_required
@role_required("assistant")
def edit_client(client_id):
    client = client_service.get_for_view(client_id)
    form = ClientForm(obj=client)
    form.obj = client
    if form.validate_on_submit():
        client_service.update_from_form(client_id, form)
        flash("Cliente atualizado com sucesso.", "success")
        return redirect(url_for("clients.list_clients"))
    return render_template("clients/form.html", form=form, mode="edit", client=client)


@clients_bp.route("/<int:client_id>/archive", methods=["POST"])
@login_required
@role_required("manager")
def archive_client(client_id):
    client_service.archive(client_id)
    flash("Cliente arquivado com sucesso.", "success")
    return redirect(url_for("clients.list_clients"))


@clients_bp.route("/<int:client_id>")
@login_required
@role_required("viewer")
def view_client(client_id):
    client = client_service.get_for_view(client_id)
    return render_template("clients/view.html", client=client)

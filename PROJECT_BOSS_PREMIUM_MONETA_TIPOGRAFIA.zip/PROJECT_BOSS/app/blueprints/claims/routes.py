from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import login_required

from app.forms import ClaimForm
from app.services.claim_service import ClaimService
from app.utils.query import get_page, get_per_page
from app.utils.security import role_required

claims_bp = Blueprint("claims", __name__, url_prefix="/claims")
claim_service = ClaimService()


@claims_bp.route("/")
@login_required
@role_required("viewer")
def list_claims():
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "")
    provider = request.args.get("provider", "")
    payload = claim_service.paginate(
        q=q,
        status=status,
        provider=provider,
        page=get_page(),
        per_page=get_per_page(),
    )
    pagination = payload["pagination"]
    return render_template(
        "claims/list.html",
        claims=pagination.items,
        pagination=pagination,
        q=q,
        status=status,
        provider=provider,
        providers=payload["providers"],
    )


@claims_bp.route("/new", methods=["GET", "POST"])
@login_required
@role_required("assistant")
def create_claim():
    form = ClaimForm()
    claim_service.apply_form_choices(form)
    if form.validate_on_submit():
        claim_service.create_from_form(form)
        flash("Sinistro cadastrado com sucesso.", "success")
        return redirect(url_for("claims.list_claims"))
    return render_template("claims/form.html", form=form, mode="new")


@claims_bp.route("/<int:claim_id>/edit", methods=["GET", "POST"])
@login_required
@role_required("assistant")
def edit_claim(claim_id):
    claim = claim_service.get_for_view(claim_id)
    form = ClaimForm(obj=claim)
    claim_service.apply_form_choices(form)
    if form.policy_id.data is None:
        form.policy_id.data = claim.policy_id or 0
    if form.validate_on_submit():
        claim_service.update_from_form(claim_id, form)
        flash("Sinistro atualizado com sucesso.", "success")
        return redirect(url_for("claims.list_claims"))
    return render_template("claims/form.html", form=form, mode="edit", claim=claim)


@claims_bp.route("/<int:claim_id>/archive", methods=["POST"])
@login_required
@role_required("assistant")
def archive_claim(claim_id):
    claim_service.archive(claim_id)
    flash("Sinistro arquivado.", "success")
    return redirect(url_for("claims.list_claims"))

from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app import db
from app.forms import DriverForm
from app.models.core import Client, Driver, AuditLog
from app.utils.security import role_required
from app.utils.query import get_page, get_per_page

drivers_bp = Blueprint("drivers", __name__, url_prefix="/drivers")

def _fill_choices(form):
    form.client_id.choices = [(c.id, c.full_name) for c in Client.query.filter_by(is_deleted=False).order_by(Client.full_name).all()]

@drivers_bp.route("/")
@login_required
@role_required("viewer")
def list_drivers():
    q = request.args.get("q", "").strip()
    query = Driver.query.join(Client).filter(Driver.is_deleted.is_(False), Client.is_deleted.is_(False))
    if q:
        query = query.filter((Driver.name.ilike(f"%{q}%")) | (Client.full_name.ilike(f"%{q}%")) | (Driver.cnh_number.ilike(f"%{q}%")))
    pagination = query.order_by(Driver.created_at.desc()).paginate(page=get_page(), per_page=get_per_page(), error_out=False)
    return render_template("drivers/list.html", drivers=pagination.items, pagination=pagination, q=q)

@drivers_bp.route("/new", methods=["GET", "POST"])
@login_required
@role_required("assistant")
def create_driver():
    form = DriverForm()
    _fill_choices(form)
    if form.validate_on_submit():
        driver = Driver()
        form.populate_obj(driver)
        db.session.add(driver)
        db.session.flush()
        db.session.add(AuditLog(action="create", entity="driver", entity_id=str(driver.id), detail=f"Condutor {driver.name}", user_id=current_user.id))
        db.session.commit()
        flash("Condutor cadastrado com sucesso.", "success")
        return redirect(url_for("drivers.list_drivers"))
    return render_template("drivers/form.html", form=form, mode="new")

@drivers_bp.route("/<int:driver_id>/edit", methods=["GET", "POST"])
@login_required
@role_required("assistant")
def edit_driver(driver_id):
    driver = Driver.query.filter_by(id=driver_id, is_deleted=False).first_or_404()
    form = DriverForm(obj=driver)
    form.obj = driver
    _fill_choices(form)
    if form.validate_on_submit():
        form.populate_obj(driver)
        db.session.add(AuditLog(action="update", entity="driver", entity_id=str(driver.id), detail=f"Condutor {driver.name}", user_id=current_user.id))
        db.session.commit()
        flash("Condutor atualizado com sucesso.", "success")
        return redirect(url_for("drivers.list_drivers"))
    return render_template("drivers/form.html", form=form, mode="edit", driver=driver)

@drivers_bp.route("/<int:driver_id>/archive", methods=["POST"])
@login_required
@role_required("manager")
def archive_driver(driver_id):
    driver = Driver.query.filter_by(id=driver_id, is_deleted=False).first_or_404()
    driver.soft_delete()
    db.session.add(AuditLog(action="archive", entity="driver", entity_id=str(driver.id), detail=f"Condutor {driver.name}", user_id=current_user.id))
    db.session.commit()
    flash("Condutor arquivado com sucesso.", "success")
    return redirect(url_for("drivers.list_drivers"))

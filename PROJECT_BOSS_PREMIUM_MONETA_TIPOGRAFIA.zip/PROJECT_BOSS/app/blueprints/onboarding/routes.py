from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import current_user
from app.forms import OnboardingSignupForm
from app.services.saas_service import provision_organization_from_signup, ensure_default_plans, get_plan_by_code
from app.models.core import OnboardingRequest, Organization, SaaSPlan, OrganizationSubscription
from app import db

onboarding_bp = Blueprint("onboarding", __name__, url_prefix="/onboarding")


@onboarding_bp.route('/start', methods=['GET', 'POST'])
def start():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard.index'))
    ensure_default_plans()
    form = OnboardingSignupForm()
    form.plan_code.choices = [(p.code, f"{p.name} — {int(float(p.monthly_price or 0))}/mês") for p in SaaSPlan.query.filter_by(is_active=True).order_by(SaaSPlan.monthly_price.asc()).all()]
    if form.validate_on_submit():
        try:
            org, admin, sub = provision_organization_from_signup(
                organization_name=form.organization_name.data,
                organization_slug=form.organization_slug.data,
                contact_name=form.contact_name.data,
                contact_email=form.contact_email.data,
                password=form.password.data,
                plan_code=form.plan_code.data,
                contact_phone=form.contact_phone.data,
            )
            flash('Workspace criado com sucesso. Faça login para continuar.', 'success')
            return redirect(url_for('auth.login', org=org.slug))
        except ValueError as exc:
            flash(str(exc), 'danger')
    plans = SaaSPlan.query.filter_by(is_active=True).order_by(SaaSPlan.monthly_price.asc()).all()
    return render_template('onboarding/start.html', form=form, plans=plans)

from flask import Blueprint, Response, render_template, request
from flask_login import login_required

from app.services.report_service import ReportService
from app.utils.filter_state import bind_filter_state
from app.utils.security import role_required

reports_bp = Blueprint("reports", __name__, url_prefix="/reports")
report_service = ReportService()


@reports_bp.route("/")
@login_required
@role_required("manager")
def index():
    filters = bind_filter_state("reports", ["period", "status", "insurance_type", "provider"])
    payload = report_service.dashboard_payload(
        period=filters.get("period", "30") or "30",
        status=filters.get("status", ""),
        insurance_type=filters.get("insurance_type", ""),
        provider=filters.get("provider", ""),
    )
    return render_template("reports/index.html", **payload)


@reports_bp.route("/expiring.csv")
@login_required
@role_required("manager")
def expiring_csv():
    try:
        days = int(request.args.get("days", "30"))
    except ValueError:
        days = 30
    content = report_service.expiring_csv_content(days=days)
    return Response(
        content,
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename=apolices_vencendo_{days}d.csv"},
    )

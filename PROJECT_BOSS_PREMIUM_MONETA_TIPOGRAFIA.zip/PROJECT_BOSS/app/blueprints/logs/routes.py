from sqlalchemy import or_
from flask import Blueprint, render_template, request
from flask_login import login_required
from app import db
from app.models.core import AuditLog
from app.models.user import User
from app.utils.security import permission_required
from app.utils.query import get_page, get_per_page

logs_bp = Blueprint("logs", __name__, url_prefix="/logs")


@logs_bp.route("/")
@login_required
@permission_required("logs.view")
def list_logs():
    q = request.args.get("q", "").strip()
    action = request.args.get("action", "").strip()
    query = AuditLog.query
    if q:
        query = query.outerjoin(User, AuditLog.user_id == User.id).filter(
            or_(
                AuditLog.detail.ilike(f"%{q}%"),
                AuditLog.entity.ilike(f"%{q}%"),
                AuditLog.action.ilike(f"%{q}%"),
                User.name.ilike(f"%{q}%"),
                User.email.ilike(f"%{q}%"),
            )
        )
    if action:
        query = query.filter(AuditLog.action == action)
    query = query.order_by(AuditLog.created_at.desc())
    pagination = query.paginate(page=get_page(), per_page=get_per_page(), error_out=False)
    action_rows = db.session.query(AuditLog.action).distinct().order_by(AuditLog.action.asc()).limit(200).all()
    action_choices = [r[0] for r in action_rows if r[0]]
    return render_template(
        "logs/list.html",
        logs=pagination.items,
        pagination=pagination,
        q=q,
        action=action,
        action_choices=action_choices,
    )

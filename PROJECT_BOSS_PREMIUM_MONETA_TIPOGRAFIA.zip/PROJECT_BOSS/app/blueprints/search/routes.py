from flask import Blueprint, render_template, request
from flask_login import login_required
from app.utils.security import role_required
from app.services.search_service import run_global_search

search_bp = Blueprint("search", __name__, url_prefix="/search")


@search_bp.route("/")
@login_required
@role_required("viewer")
def global_search():
    q = request.args.get("q", "").strip()
    results = run_global_search(q)
    counts = {k: len(v) for k, v in results.items()}
    return render_template("search/index.html", q=q, results=results, counts=counts)

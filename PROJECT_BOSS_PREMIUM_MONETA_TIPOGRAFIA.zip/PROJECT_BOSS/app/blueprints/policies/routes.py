from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import login_required

from app.forms import PolicyForm, ProposalSendForm
from app.services.policy_service import PolicyService, PolicyValidationError
from app.utils.query import get_page, get_per_page
from app.utils.security import role_required

policies_bp = Blueprint("policies", __name__, url_prefix="/policies")
policy_service = PolicyService()


@policies_bp.route("/")
@login_required
@role_required("viewer")
def list_policies():
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "")
    insurer = request.args.get("insurer", "")
    provider = request.args.get("provider", "")
    line = request.args.get("line", "").strip()
    payload = policy_service.paginate(
        q=q,
        status=status,
        insurer=insurer,
        provider=provider,
        line=line,
        page=get_page(),
        per_page=get_per_page(),
    )
    pagination = payload["pagination"]
    return render_template(
        "policies/list.html",
        policies=pagination.items,
        pagination=pagination,
        q=q,
        status=status,
        insurer=insurer,
        insurers=payload["insurers"],
        provider=provider,
        providers=payload["providers"],
        line=line,
        line_title=payload["line_title"],
        insurance_lines=payload["insurance_lines"],
    )


@policies_bp.route("/new", methods=["GET", "POST"])
@login_required
@role_required("assistant")
def create_policy():
    form = PolicyForm()
    policy_service.apply_form_choices(form)
    if form.validate_on_submit():
        try:
            policy_service.create_from_form(form)
            flash("Apólice cadastrada com sucesso.", "success")
            return redirect(url_for("policies.list_policies"))
        except PolicyValidationError as exc:
            for err in exc.errors:
                flash(err, "danger")
    return render_template("policies/form.html", form=form, mode="new")


@policies_bp.route("/<int:policy_id>/edit", methods=["GET", "POST"])
@login_required
@role_required("assistant")
def edit_policy(policy_id):
    policy = policy_service.get_for_view(policy_id)
    form = PolicyForm(obj=policy)
    form.obj = policy
    policy_service.apply_form_choices(form)
    if form.validate_on_submit():
        try:
            policy_service.update_from_form(policy_id, form)
            flash("Apólice atualizada com sucesso.", "success")
            return redirect(url_for("policies.list_policies"))
        except PolicyValidationError as exc:
            for err in exc.errors:
                flash(err, "danger")
    return render_template("policies/form.html", form=form, mode="edit", policy=policy)


@policies_bp.route("/<int:policy_id>/archive", methods=["POST"])
@login_required
@role_required("manager")
def archive_policy(policy_id):
    policy_service.archive(policy_id)
    flash("Apólice arquivada com sucesso.", "success")
    return redirect(url_for("policies.list_policies"))


@policies_bp.route("/<int:policy_id>", methods=["GET", "POST"])
@login_required
@role_required("viewer")
def view_policy(policy_id):
    policy = policy_service.get_for_view(policy_id)
    form = ProposalSendForm(
        recipient_email=policy.client.email,
        recipient_whatsapp=policy.client.whatsapp,
    )
    default_message = policy_service.build_default_message(policy)
    if request.method == "GET" and not form.message.data:
        form.message.data = default_message
    if form.validate_on_submit():
        if form.submit_whatsapp.data:
            link = policy_service.build_whatsapp_redirect(
                phone=form.recipient_whatsapp.data or policy.client.whatsapp or "",
                message=form.message.data or default_message,
            )
            return redirect(link)
        if form.submit_email.data:
            if not form.recipient_email.data:
                flash("Informe um e-mail válido para envio.", "danger")
            else:
                try:
                    policy_service.send_policy_email(
                        policy=policy,
                        recipient=form.recipient_email.data,
                        message=form.message.data or default_message,
                    )
                    flash("Proposta enviada por e-mail com sucesso.", "success")
                    return redirect(url_for("policies.view_policy", policy_id=policy.id))
                except Exception as exc:
                    flash(f"Falha no envio por e-mail: {exc}", "danger")
    return render_template("policies/view.html", policy=policy, form=form)

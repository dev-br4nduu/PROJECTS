import os

from flask import Blueprint, flash, redirect, render_template, request, send_from_directory, url_for
from flask_login import login_required

from app.forms import DocumentUploadForm
from app.services.document_service import DocumentService, DocumentValidationError
from app.utils.query import get_page, get_per_page
from app.utils.security import role_required

documents_bp = Blueprint("documents", __name__, url_prefix="/documents")
document_service = DocumentService()


@documents_bp.route("/")
@login_required
@role_required("viewer")
def list_documents():
    q = request.args.get("q", "").strip()
    category = request.args.get("category", "").strip()
    pagination = document_service.paginate(
        q=q,
        category=category,
        page=get_page(),
        per_page=get_per_page(),
    )
    return render_template(
        "documents/list.html",
        documents=pagination.items,
        pagination=pagination,
        q=q,
        category=category,
    )


@documents_bp.route("/new", methods=["GET", "POST"])
@login_required
@role_required("assistant")
def upload_document():
    form = DocumentUploadForm()
    document_service.apply_form_choices(form)
    if form.validate_on_submit():
        try:
            document_service.create_from_form(form)
        except DocumentValidationError as exc:
            flash(str(exc), "danger")
            return render_template("documents/form.html", form=form)
        flash("Documento enviado com sucesso.", "success")
        return redirect(url_for("documents.list_documents"))
    return render_template("documents/form.html", form=form)


@documents_bp.route("/<int:document_id>/download")
@login_required
@role_required("viewer")
def download_document(document_id):
    document = document_service.get_for_download(document_id)
    abs_path = os.path.join(os.path.dirname(__file__), "..", "..", document.file_path)
    directory, filename = os.path.split(os.path.abspath(abs_path))
    return send_from_directory(directory, filename, as_attachment=True, download_name=document.file_name)


@documents_bp.route("/<int:document_id>/archive", methods=["POST"])
@login_required
@role_required("assistant")
def archive_document(document_id):
    document_service.archive(document_id)
    flash("Documento arquivado.", "success")
    return redirect(url_for("documents.list_documents"))

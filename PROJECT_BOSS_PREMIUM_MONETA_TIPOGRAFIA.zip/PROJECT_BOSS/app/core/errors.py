"""Tratamento centralizado de erros HTTP."""
from __future__ import annotations

from flask import jsonify, render_template, request


def register_error_handlers(app) -> None:
    @app.errorhandler(403)
    def forbidden(error):
        if request.accept_mimetypes.best == "application/json":
            return jsonify(error="forbidden"), 403
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(error):
        if request.accept_mimetypes.best == "application/json":
            return jsonify(error="not_found"), 404
        return render_template("errors/404.html"), 404

    @app.errorhandler(500)
    def internal_error(error):
        app.logger.exception("Erro interno não tratado: %s", error)
        if request.accept_mimetypes.best == "application/json":
            return jsonify(error="internal_server_error"), 500
        return render_template("errors/500.html"), 500

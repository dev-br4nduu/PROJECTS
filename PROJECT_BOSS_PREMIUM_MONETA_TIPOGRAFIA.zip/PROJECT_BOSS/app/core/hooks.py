"""Hooks e context processors da aplicação."""
from __future__ import annotations

import os

from flask import g, url_for


def register_request_hooks(app) -> None:
    @app.before_request
    def _keep_session_alive():
        from flask import session
        from flask_login import current_user
        from app.utils.tenancy import get_request_organization_slug, get_request_organization

        session.permanent = True
        g.request_organization_slug = get_request_organization_slug()
        g.request_organization = get_request_organization()
        g.current_organization = (
            getattr(current_user, "organization", None)
            if getattr(current_user, "is_authenticated", False)
            else g.request_organization
        )

    @app.get("/health")
    def health():
        return {"status": "ok", "app": app.config.get("PRODUCT_NAME", "Boss Seguros CRM")}, 200

    @app.get("/ready")
    def ready():
        from sqlalchemy import text
        from app.extensions import db

        try:
            db.session.execute(text("SELECT 1"))
            return {
                "status": "ready",
                "database": "ok",
                "storage": app.config.get("UPLOAD_FOLDER"),
            }, 200
        except Exception as exc:
            return {"status": "degraded", "detail": str(exc)}, 503

    @app.get("/health/storage")
    def health_storage():
        path = app.config.get("UPLOAD_FOLDER")
        ok = bool(path and os.path.isdir(path) and os.access(path, os.W_OK))
        return {"status": "ok" if ok else "degraded", "path": path}, 200 if ok else 503


def register_context_processors(app) -> None:
    @app.context_processor
    def inject_brand():
        from flask import request
        from flask_login import current_user
        from app.services.saas_service import get_plan_features_for_org
        from app.utils.security import can_access
        from app.utils.tenancy import (
            current_organization_name,
            get_request_organization_slug,
        )

        def page_url(page_number):
            params = request.args.to_dict(flat=True)
            params["page"] = page_number
            return url_for(request.endpoint, **params)

        current_org = (
            getattr(current_user, "organization", None)
            if getattr(current_user, "is_authenticated", False)
            else g.request_organization
        )

        def _desktop_zoom() -> float:
            try:
                z = float(os.environ.get("BOSS_UI_ZOOM", "1") or "1")
                return max(0.75, min(1.25, z))
            except ValueError:
                return 1.0

        return {
            "is_desktop_shell": os.environ.get("DESKTOP_MODE", "").lower() == "true",
            "desktop_ui_zoom": _desktop_zoom(),
            "app_name": app.config.get("PRODUCT_NAME", "Boss Seguros CRM"),
            "brand_colors": {
                "primary": "#132f63",
                "primary_dark": "#0d2147",
                "accent": "#2958bf",
                "bg": "#f4f7fa",
            },
            "page_url": page_url,
            "can_access": lambda permission_key: can_access(current_user, permission_key),
            "current_organization_name": current_organization_name(),
            "current_workspace_slug": get_request_organization_slug(),
            "current_plan_features": get_plan_features_for_org(current_org),
        }

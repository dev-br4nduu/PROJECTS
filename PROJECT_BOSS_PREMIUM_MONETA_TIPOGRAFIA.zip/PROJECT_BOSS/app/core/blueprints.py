"""Registro central de blueprints."""
from __future__ import annotations

from flask import Flask

BLUEPRINT_IMPORTS = (
    "app.blueprints.auth.routes:auth_bp",
    "app.blueprints.dashboard.routes:dashboard_bp",
    "app.blueprints.clients.routes:clients_bp",
    "app.blueprints.policies.routes:policies_bp",
    "app.blueprints.imports.routes:imports_bp",
    "app.blueprints.admin.routes:admin_bp",
    "app.blueprints.renewals.routes:renewals_bp",
    "app.blueprints.vehicles.routes:vehicles_bp",
    "app.blueprints.drivers.routes:drivers_bp",
    "app.blueprints.claims.routes:claims_bp",
    "app.blueprints.crm.routes:crm_bp",
    "app.blueprints.documents.routes:documents_bp",
    "app.blueprints.reports.routes:reports_bp",
    "app.blueprints.agenda.routes:agenda_bp",
    "app.blueprints.logs.routes:logs_bp",
    "app.blueprints.search.routes:search_bp",
    "app.blueprints.onboarding.routes:onboarding_bp",
)

# Caminhos de módulo (sem atributo) — usado pelo PyInstaller no BossSegurosCRM.spec.
BLUEPRINT_MODULE_PATHS = tuple(s.split(":")[0] for s in BLUEPRINT_IMPORTS)


def _load(import_path: str):
    module_path, attr = import_path.split(":")
    module = __import__(module_path, fromlist=[attr])
    return getattr(module, attr)


def register_blueprints(app: Flask) -> None:
    for import_path in BLUEPRINT_IMPORTS:
        app.register_blueprint(_load(import_path))

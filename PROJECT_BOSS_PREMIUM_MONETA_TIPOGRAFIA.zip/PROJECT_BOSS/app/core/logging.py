"""Configuração de logging estruturado para a aplicação."""
from __future__ import annotations

import logging
from logging.config import dictConfig


def configure_logging(app) -> None:
    level = app.config.get("LOG_LEVEL", "INFO").upper()
    dictConfig(
        {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                "default": {
                    "format": "[%(asctime)s] %(levelname)s %(name)s: %(message)s",
                }
            },
            "handlers": {
                "console": {
                    "class": "logging.StreamHandler",
                    "formatter": "default",
                    "level": level,
                }
            },
            "root": {"level": level, "handlers": ["console"]},
        }
    )
    logging.getLogger("apscheduler").setLevel(logging.WARNING)

# -*- mode: python ; coding: utf-8 -*-
"""
Boss Seguros CRM — PyInstaller onefile (dist\\BossSegurosCRM.exe), como Moneta Tarefas.

Raiz: BOSS_SEGUROS_CRM_ROOT ou pasta do .spec (SPECPATH/SPEC).
"""
import os
import sys
from pathlib import Path

from PyInstaller.utils.hooks import collect_all

_env = os.environ.get("BOSS_SEGUROS_CRM_ROOT")
if _env:
    root = Path(os.path.abspath(_env))
else:
    _spec = globals().get("SPECPATH") or globals().get("SPEC")
    if not _spec:
        raise SystemExit(
            "BossSegurosCRM.spec: defina BOSS_SEGUROS_CRM_ROOT ou execute via PyInstaller."
        )
    root = Path(os.path.abspath(_spec)).parent

_desktop = root / "desktop.py"
if not _desktop.is_file():
    raise SystemExit(
        "BossSegurosCRM.spec: não encontrado {!s}. "
        "Defina BOSS_SEGUROS_CRM_ROOT ou execute scripts/build-desktop.bat / build-desktop.ps1.".format(
            _desktop
        )
    )

tpl = str(root / "app" / "templates")
static = str(root / "app" / "static")

datas = [(tpl, "app/templates"), (static, "app/static")]
binaries = []
hiddenimports = ["waitress"]
for package in ("pywebview", "flask", "apscheduler"):
    d, b, h = collect_all(package)
    datas += d
    binaries += b
    hiddenimports += h

# Blueprints só são carregados via __import__ em runtime; o grafo estático não os vê.
# Lista explícita (mesma fonte que app.core.blueprints.BLUEPRINT_MODULE_PATHS).
_root_str = str(root)
if _root_str not in sys.path:
    sys.path.insert(0, _root_str)
try:
    from app.core.blueprints import BLUEPRINT_MODULE_PATHS

    hiddenimports.extend(BLUEPRINT_MODULE_PATHS)
except Exception as exc:
    raise SystemExit(
        "BossSegurosCRM.spec: não foi possível carregar BLUEPRINT_MODULE_PATHS. "
        "Instale dependências (pip) na mesma versão do build e defina BOSS_SEGUROS_CRM_ROOT. "
        "Detalhe: {!r}".format(exc)
    ) from exc

block_cipher = None

a = Analysis(
    [str(_desktop.resolve())],
    pathex=[str(root)],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

_icon = root / "app" / "static" / "icons" / "bossseguros.ico"
_icon_arg = str(_icon) if _icon.is_file() else None

_kw = dict(
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
if _icon_arg:
    _kw["icon"] = _icon_arg

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name="BossSegurosCRM",
    **_kw,
)

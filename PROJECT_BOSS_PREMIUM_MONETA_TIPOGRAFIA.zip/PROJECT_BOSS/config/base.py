"""Configuração base do Boss Seguros CRM."""
from __future__ import annotations

import os
from datetime import timedelta

from dotenv import load_dotenv

# Carrega variáveis em camadas: .env do projeto e .env.local para persistência local.
load_dotenv()
load_dotenv(".env.local", override=True)


def _default_database_url() -> str:
    return os.getenv(
        "DATABASE_URL",
        os.getenv("POSTGRES_URL", "sqlite:///boss_seguros.db"),
    )


class Config:
    PRODUCT_NAME = os.getenv("PRODUCT_NAME", "Boss Seguros CRM")
    PRODUCT_CLIENT = os.getenv("PRODUCT_CLIENT", "Boss Corretora de Seguros")

    SECRET_KEY = os.getenv("SECRET_KEY", "change-this-secret-key")
    REQUIRE_STRONG_SECRET = os.getenv("REQUIRE_STRONG_SECRET", "true").lower() == "true"
    ENV_NAME = os.getenv("APP_ENV", "development")

    SQLALCHEMY_DATABASE_URI = _default_database_url()
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_pre_ping": True,
        "pool_recycle": 300,
    }

    WTF_CSRF_TIME_LIMIT = None

    REMEMBER_COOKIE_HTTPONLY = True
    REMEMBER_COOKIE_SAMESITE = os.getenv("REMEMBER_COOKIE_SAMESITE", "Lax")
    REMEMBER_COOKIE_SECURE = os.getenv(
        "REMEMBER_COOKIE_SECURE",
        os.getenv("SESSION_COOKIE_SECURE", "false"),
    ).lower() == "true"
    REMEMBER_COOKIE_DURATION = timedelta(days=int(os.getenv("REMEMBER_COOKIE_DAYS", "180")))
    REMEMBER_COOKIE_REFRESH_EACH_REQUEST = True

    SESSION_COOKIE_NAME = os.getenv("SESSION_COOKIE_NAME", "boss_seguros_session")
    SESSION_COOKIE_DOMAIN = os.getenv("SESSION_COOKIE_DOMAIN") or None
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = os.getenv("SESSION_COOKIE_SECURE", "false").lower() == "true"
    SESSION_REFRESH_EACH_REQUEST = True
    PERMANENT_SESSION_LIFETIME = timedelta(days=int(os.getenv("SESSION_DAYS", "180")))

    PREFERRED_URL_SCHEME = os.getenv("PREFERRED_URL_SCHEME", "http")
    APP_BASE_URL = os.getenv("APP_BASE_URL", "http://localhost:5000")

    MAX_LOGIN_ATTEMPTS = int(os.getenv("MAX_LOGIN_ATTEMPTS", "5"))
    LOGIN_LOCK_MINUTES = int(os.getenv("LOGIN_LOCK_MINUTES", "15"))

    BEHIND_PROXY = os.getenv("BEHIND_PROXY", "false").lower() == "true"
    PROXY_FIX_X_FOR = int(os.getenv("PROXY_FIX_X_FOR", "1"))
    PROXY_FIX_X_PROTO = int(os.getenv("PROXY_FIX_X_PROTO", "1"))
    PROXY_FIX_X_HOST = int(os.getenv("PROXY_FIX_X_HOST", "1"))
    PROXY_FIX_X_PORT = int(os.getenv("PROXY_FIX_X_PORT", "1"))
    PROXY_FIX_X_PREFIX = int(os.getenv("PROXY_FIX_X_PREFIX", "1"))

    MAIL_SERVER = os.getenv("MAIL_SERVER", "localhost")
    MAIL_PORT = int(os.getenv("MAIL_PORT", 25))
    MAIL_USE_TLS = os.getenv("MAIL_USE_TLS", "false").lower() == "true"
    MAIL_USE_SSL = os.getenv("MAIL_USE_SSL", "false").lower() == "true"
    MAIL_USERNAME = os.getenv("MAIL_USERNAME")
    MAIL_PASSWORD = os.getenv("MAIL_PASSWORD")
    MAIL_DEFAULT_SENDER = os.getenv("MAIL_DEFAULT_SENDER", "no-reply@example.com")

    ENABLE_SCHEDULER = os.getenv("ENABLE_SCHEDULER", "false").lower() == "true"
    UPLOAD_FOLDER = os.getenv("UPLOAD_FOLDER", "uploads")
    MAX_CONTENT_LENGTH = int(os.getenv("MAX_CONTENT_LENGTH", str(16 * 1024 * 1024)))
    ALLOWED_UPLOAD_EXTENSIONS = os.getenv(
        "ALLOWED_UPLOAD_EXTENSIONS",
        "pdf,png,jpg,jpeg,webp,xlsx,xls,doc,docx",
    )
    PASSWORD_RESET_EXPIRES_HOURS = int(os.getenv("PASSWORD_RESET_EXPIRES_HOURS", "6"))
    PASSWORD_MIN_LENGTH = int(os.getenv("PASSWORD_MIN_LENGTH", "10"))
    PASSWORD_REQUIRE_UPPER = os.getenv("PASSWORD_REQUIRE_UPPER", "true").lower() == "true"
    PASSWORD_REQUIRE_LOWER = os.getenv("PASSWORD_REQUIRE_LOWER", "true").lower() == "true"
    PASSWORD_REQUIRE_DIGIT = os.getenv("PASSWORD_REQUIRE_DIGIT", "true").lower() == "true"
    PASSWORD_REQUIRE_SYMBOL = os.getenv("PASSWORD_REQUIRE_SYMBOL", "true").lower() == "true"
    WHATSAPP_DEFAULT_DDI = os.getenv("WHATSAPP_DEFAULT_DDI", "55")

    MULTI_TENANT_MODE = os.getenv("MULTI_TENANT_MODE", "true").lower() == "true"
    TENANT_STRATEGY = os.getenv("TENANT_STRATEGY", "path")
    ROOT_HOST = os.getenv("ROOT_HOST")
    DEFAULT_ORGANIZATION_SLUG = os.getenv("DEFAULT_ORGANIZATION_SLUG", "boss-default")
    REQUIRE_ORG_ON_LOGIN = os.getenv("REQUIRE_ORG_ON_LOGIN", "false").lower() == "true"

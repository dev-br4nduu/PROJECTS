@echo off
setlocal EnableExtensions
REM Pure ASCII: avoids cmd.exe mangling UTF-8/Unicode (do not use chcp 65001 here).

cd /d "%~dp0.."
set "BOSS_SEGUROS_CRM_ROOT=%CD%"

set "PY_CMD="
if exist ".venv-desktop\Scripts\python.exe" set "PY_CMD=.venv-desktop\Scripts\python.exe"
if defined PY_CMD goto have_py
if defined PYTHON set "PY_CMD=%PYTHON%"
if defined PY_CMD goto have_py
where python >nul 2>&1 && set "PY_CMD=python" && goto have_py
where py >nul 2>&1 && set "PY_CMD=py" && goto have_py

echo No Python found. Activate venv or set PYTHON=path\to\python.exe
pause
exit /b 1

:have_py
echo Using: %PY_CMD%
"%PY_CMD%" -c "import sys; print(sys.version.split()[0], sys.executable)"
echo.

echo [1/2] Dependencies: install-dependencies.py --desktop --build
"%PY_CMD%" "%~dp0install-dependencies.py" --desktop --build
if errorlevel 1 (
  echo Dependency install failed. See messages above.
  pause
  exit /b 1
)

echo.
echo Replacing dist\BossSegurosCRM.exe - close the app if running; OneDrive may lock files.
taskkill /F /IM BossSegurosCRM.exe >nul 2>&1
timeout /t 2 /nobreak >nul
if exist "dist\BossSegurosCRM.exe" (
  del /F /Q "dist\BossSegurosCRM.exe" 2>nul
  if exist "dist\BossSegurosCRM.exe" (
    echo ERROR: could not delete dist\BossSegurosCRM.exe
    echo Close the program and retry, or pause OneDrive sync for this folder.
    pause
    exit /b 1
  )
)

echo [2/2] PyInstaller BossSegurosCRM.spec - may take several minutes...
"%PY_CMD%" -m PyInstaller --noconfirm --clean BossSegurosCRM.spec
if errorlevel 1 (
  echo PyInstaller failed. See messages above.
  pause
  exit /b 1
)

echo.
echo Done: dist\BossSegurosCRM.exe
echo Data folder: BossSegurosData next to the executable.
echo Optional shortcut: scripts\Criar-Atalho-Desktop.ps1 or scripts\create-desktop-shortcut.ps1
echo.
pause
endlocal

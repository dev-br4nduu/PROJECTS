param(
    [string]$Host = "localhost",
    [int]$Port = 5432,
    [string]$Database = "boss_seguros",
    [string]$User = "postgres",
    [string]$OutputFile = ".\backup_boss_seguros.dump"
)
$ErrorActionPreference = "Stop"
pg_dump -h $Host -p $Port -U $User -F c -b -v -f $OutputFile $Database
Write-Host "Backup gerado em $OutputFile"

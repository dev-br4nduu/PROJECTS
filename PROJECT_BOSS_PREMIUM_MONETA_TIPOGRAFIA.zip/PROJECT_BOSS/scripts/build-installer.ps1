Param(
    [string]$Python = "python",
    [string]$InnoSetupCompiler = "C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
)

$ErrorActionPreference = "Stop"
Set-Location (Resolve-Path "$PSScriptRoot\..")

Write-Host "[1/4] Limpando builds anteriores..."
Remove-Item -Recurse -Force build, dist, dist_installer -ErrorAction SilentlyContinue

Write-Host "[2/4] Instalando dependências de empacotamento (adaptadas ao Python)..."
& $Python "scripts\install-dependencies.py" --desktop --build --postgres
if ($LASTEXITCODE -ne 0) { throw "Falha ao instalar dependências." }

Write-Host "[3/4] Gerando executável desktop..."
& $Python -m PyInstaller BossSegurosCRM.spec --noconfirm
if ($LASTEXITCODE -ne 0) { throw "Falha ao gerar executável com PyInstaller." }

if (!(Test-Path $InnoSetupCompiler)) {
    throw "ISCC.exe não encontrado em: $InnoSetupCompiler"
}

Write-Host "[4/4] Gerando instalador..."
& $InnoSetupCompiler ".\scripts\BossSegurosCRM.iss"
if ($LASTEXITCODE -ne 0) { throw "Falha ao gerar instalador com Inno Setup." }

Write-Host "Concluído. Verifique a pasta dist_installer." -ForegroundColor Green

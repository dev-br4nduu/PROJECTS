#!/usr/bin/env python3
"""
Instala dependências do Boss Seguros CRM conforme o Python em uso.

- Python antigo: atualiza pip/setuptools/wheel antes de instalar (melhora wheels).
- Python recente (ex. 3.13+): se pywebview falhar (pythonnet), tenta instalação alternativa.
- Falha com mensagem clara se a versão for inferior à mínima suportada.
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

# Alinhado ao Flask 3.1.x (Requires-Python >=3.9 no PyPI).
MIN_PY = (3, 9)
# PyInstaller 6+ e stack atual testados principalmente até esta linha; versões mais novas
# usam os mesmos passos com fallback para pywebview.
RECOMMENDED_MAX = (3, 12)


def _root() -> Path:
    return Path(__file__).resolve().parent.parent


def _pip(args: list[str], *, quiet: bool) -> int:
    cmd = [sys.executable, "-m", "pip", *args]
    if quiet:
        cmd.append("-q")
    env = os.environ.copy()
    # Evita surpresas com site-packages do utilizador em builds.
    env.setdefault("PIP_DISABLE_PIP_VERSION_CHECK", "1")
    return subprocess.call(cmd, cwd=_root(), env=env)


def _upgrade_packaging_tools(quiet: bool) -> None:
    """Ajuda Python mais antigo a obter wheels pré-compilados."""
    _pip(
        ["install", "--upgrade", "pip", "setuptools", "wheel"],
        quiet=quiet,
    )


def _install_file(path: Path, *, quiet: bool, extra: list[str] | None = None) -> int:
    args = ["install", "-r", str(path)]
    if extra:
        args.extend(extra)
    return _pip(args, quiet=quiet)


def _install_desktop_with_fallback(quiet: bool) -> int:
    req = _root() / "requirements-desktop.txt"
    if not req.is_file():
        return 0
    print("[Boss] Instalando dependências desktop (pywebview)...")
    if _install_file(req, quiet=quiet) == 0:
        return 0

    v = sys.version_info
    print(
        "[Boss] Instalação desktop padrão falhou "
        f"(Python {v.major}.{v.minor}; ex.: pythonnet sem wheel). "
        "Tentando pywebview sem dependências opcionais...",
        file=sys.stderr,
    )
    if _pip(["install", "-r", str(_root() / "requirements.txt")], quiet=quiet) != 0:
        return 1
    if _pip(["install", "pywebview>=5.4,<6", "--no-deps"], quiet=quiet) != 0:
        return 1
    for pkg in (
        "proxy_tools>=0.1.0",
        "bottle>=0.12.0",
        "typing_extensions>=4.0.0",
    ):
        if _pip(["install", pkg], quiet=quiet) != 0:
            return 1
    print("[Boss] pywebview instalado em modo compatível.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--desktop",
        action="store_true",
        help="Inclui requirements-desktop.txt (com fallback automático).",
    )
    parser.add_argument(
        "--build",
        action="store_true",
        help="Inclui requirements-build.txt (PyInstaller).",
    )
    parser.add_argument(
        "--postgres",
        action="store_true",
        help="Inclui requirements-postgres.txt.",
    )
    parser.add_argument(
        "--dev",
        action="store_true",
        help="Inclui requirements-dev.txt (pytest, black, ruff).",
    )
    parser.add_argument(
        "--quiet",
        "-q",
        action="store_true",
        help="pip -q",
    )
    parser.add_argument(
        "--skip-upgrade-pip",
        action="store_true",
        help="Não atualiza pip/setuptools/wheel antes (mais rápido, menos robusto em Python antigo).",
    )
    args = parser.parse_args()

    v = sys.version_info
    print(f"[Boss] Python {v.major}.{v.minor}.{v.micro} — {sys.executable}")

    if v[:2] < MIN_PY:
        print(
            f"ERRO: Python {MIN_PY[0]}.{MIN_PY[1]}+ é necessário (Flask 3.1 / stack atual).",
            file=sys.stderr,
        )
        return 1

    if v[:2] > RECOMMENDED_MAX:
        print(
            f"[Boss] Aviso: versão acima de {RECOMMENDED_MAX[0]}.{RECOMMENDED_MAX[1]} — "
            "algumas dependências podem precisar do fallback automático (desktop).",
            file=sys.stderr,
        )

    os.chdir(_root())

    if not args.skip_upgrade_pip:
        _upgrade_packaging_tools(args.quiet)

    base = _root() / "requirements.txt"
    if not base.is_file():
        print(f"ERRO: não encontrado {base}", file=sys.stderr)
        return 1

    print("[Boss] Instalando requirements.txt...")
    if _install_file(base, quiet=args.quiet) != 0:
        print("[Boss] Falha ao instalar requirements.txt.", file=sys.stderr)
        return 1

    if args.desktop:
        if _install_desktop_with_fallback(args.quiet) != 0:
            return 1

    if args.build:
        br = _root() / "requirements-build.txt"
        if br.is_file():
            print("[Boss] Instalando requirements-build.txt...")
            if _install_file(br, quiet=args.quiet) != 0:
                return 1
        if not args.quiet:
            try:
                r = subprocess.run(
                    [sys.executable, "-m", "PyInstaller", "--version"],
                    cwd=_root(),
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                if r.returncode == 0:
                    print(f"[Boss] PyInstaller {r.stdout.strip()}")
            except OSError:
                pass

    if args.postgres:
        pg = _root() / "requirements-postgres.txt"
        if pg.is_file():
            print("[Boss] Instalando requirements-postgres.txt...")
            if _install_file(pg, quiet=args.quiet) != 0:
                return 1

    if args.dev:
        dv = _root() / "requirements-dev.txt"
        if dv.is_file():
            print("[Boss] Instalando requirements-dev.txt...")
            if _install_file(dv, quiet=args.quiet) != 0:
                return 1

    print("[Boss] Dependências concluídas.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

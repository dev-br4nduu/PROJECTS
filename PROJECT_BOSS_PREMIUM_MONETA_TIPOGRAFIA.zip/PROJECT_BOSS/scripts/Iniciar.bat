@echo off
setlocal EnableExtensions
cd /d "%~dp0.."
where py >nul 2>&1 && (set PY=py) || (set PY=python)
echo [Boss CRM] Syncing requirements.txt ...
"%PY%" "%~dp0install-dependencies.py" --quiet --skip-upgrade-pip
echo [Boss CRM] Dev server - see URL below (auto port).
"%PY%" run.py
pause
endlocal

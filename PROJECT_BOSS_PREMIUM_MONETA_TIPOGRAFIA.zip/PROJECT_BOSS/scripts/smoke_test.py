from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from werkzeug.security import generate_password_hash

from app import create_app, db
from app.models.user import User
from app.models.core import Organization
from config import DevelopmentConfig


class SmokeConfig(DevelopmentConfig):
    TESTING = True
    WTF_CSRF_ENABLED = False
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    SECRET_KEY = 'smoke-test'


def main() -> int:
    app = create_app(SmokeConfig)
    with app.app_context():
        db.create_all()
        org = Organization(name='Smoke Org', slug='smoke-org', is_active=True)
        db.session.add(org)
        db.session.flush()
        db.session.add(User(organization_id=org.id, name='Smoke Admin', email='smoke@boss.com', role='admin', is_active=True, password_hash=generate_password_hash('Admin@123')) )
        db.session.commit()
        client = app.test_client()
        assert client.get('/auth/login').status_code == 200
        login = client.post('/auth/login', data={'email': 'smoke@boss.com', 'password': 'Admin@123', 'organization_slug': 'smoke-org'}, follow_redirects=False)
        assert login.status_code in (302, 303)
        assert client.get('/health').status_code == 200
        assert client.get('/ready').status_code in (200, 503)
    print('Smoke test OK')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

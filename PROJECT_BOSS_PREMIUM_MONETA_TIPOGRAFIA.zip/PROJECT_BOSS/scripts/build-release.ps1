$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Root = (Resolve-Path -LiteralPath $Root).Path
$env:BOSS_SEGUROS_CRM_ROOT = $Root
Set-Location -LiteralPath $Root

Write-Host "==> Etapa 1: Build desktop"
& powershell -ExecutionPolicy Bypass -File "$Root\scripts\build-desktop.ps1"

$Inno = Get-Command ISCC.exe -ErrorAction SilentlyContinue
if (-not $Inno) {
    Write-Host "Inno Setup não encontrado. Instale o Inno Setup 6 para gerar o instalador." -ForegroundColor Yellow
    exit 0
}

Write-Host "==> Etapa 2: Gerando instalador"
& $Inno.Source "$Root\scripts\BossSegurosCRM.iss"
Write-Host "Instalador criado em $Root\dist_installer"

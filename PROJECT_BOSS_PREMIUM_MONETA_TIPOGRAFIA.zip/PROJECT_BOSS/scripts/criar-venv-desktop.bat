@echo off
setlocal EnableExtensions
REM Pure ASCII for cmd.exe compatibility.

cd /d "%~dp0.."

set "PY_CMD="
if defined PYTHON set "PY_CMD=%PYTHON%"
if defined PY_CMD goto have_py
where python >nul 2>&1 && set "PY_CMD=python" && goto have_py
where py >nul 2>&1 && set "PY_CMD=py" && goto have_py

echo No Python found. Add Python to PATH or set PYTHON=path\to\python.exe
pause
exit /b 1

:have_py
echo Using: %PY_CMD%
"%PY_CMD%" -c "import sys; print(sys.executable); print(sys.version)"
echo.

echo Creating .venv-desktop ...
"%PY_CMD%" -m venv .venv-desktop
if errorlevel 1 (
  echo Failed to create venv.
  pause
  exit /b 1
)

call ".venv-desktop\Scripts\activate.bat"
python "%~dp0install-dependencies.py" --desktop --build
if errorlevel 1 (
  echo Dependency install failed.
  pause
  exit /b 1
)

echo.
echo Ready. To build the .exe:
echo   .venv-desktop\Scripts\activate
echo   scripts\build-desktop.bat
echo.
pause
endlocal

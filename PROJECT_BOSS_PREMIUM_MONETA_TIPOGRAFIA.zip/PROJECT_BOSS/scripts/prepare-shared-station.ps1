param(
  [string]$InstallDir = "$env:ProgramFiles\Boss Seguros CRM",
  [string]$DatabaseUrl,
  [string]$StorageRoot
)

$envFile = Join-Path $InstallDir ".env"
if (!(Test-Path $InstallDir)) { throw "Diretório não encontrado: $InstallDir" }
if (!(Test-Path $envFile)) { New-Item -Path $envFile -ItemType File | Out-Null }

$content = Get-Content $envFile -ErrorAction SilentlyContinue
$content = $content | Where-Object { $_ -notmatch '^(DATABASE_URL|UPLOAD_FOLDER|SESSION_COOKIE_SECURE|REMEMBER_COOKIE_SECURE|BEHIND_PROXY)=' }
$content += "DATABASE_URL=$DatabaseUrl"
$content += "UPLOAD_FOLDER=$StorageRoot"
$content += "SESSION_COOKIE_SECURE=false"
$content += "REMEMBER_COOKIE_SECURE=false"
$content += "BEHIND_PROXY=false"
Set-Content -Path $envFile -Value $content -Encoding UTF8
Write-Host "Estação preparada para base compartilhada."

from __future__ import annotations

import os
import time
import urllib.request
import webbrowser

HOST = os.environ.get('BOSS_HOST', '127.0.0.1')
PORT = os.environ.get('BOSS_PORT', '5000')
TARGET = f'http://{HOST}:{PORT}/auth/login'
HEALTH = f'http://{HOST}:{PORT}/health'

for _ in range(60):
    try:
        with urllib.request.urlopen(HEALTH, timeout=1) as response:
            if response.status == 200:
                webbrowser.open(TARGET)
                raise SystemExit(0)
    except Exception:
        time.sleep(1)

webbrowser.open(TARGET)

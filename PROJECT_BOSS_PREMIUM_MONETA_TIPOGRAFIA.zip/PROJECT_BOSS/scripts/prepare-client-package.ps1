Param(
    [Parameter(Mandatory=$true)][string]$InstallPath,
    [Parameter(Mandatory=$false)][string]$DatabaseUrl = "",
    [Parameter(Mandatory=$false)][string]$StorageRoot = "",
    [Parameter(Mandatory=$false)][string]$SecretKey = ""
)

$ErrorActionPreference = "Stop"
$install = Resolve-Path $InstallPath
$dataDir = Join-Path $install "BossSegurosData"
New-Item -ItemType Directory -Force -Path $dataDir | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $dataDir "uploads") | Out-Null

if ([string]::IsNullOrWhiteSpace($SecretKey)) {
    $SecretKey = -join ((33..126) | Get-Random -Count 64 | ForEach-Object {[char]$_})
}

$envPath = Join-Path $dataDir ".env"
if (!(Test-Path $envPath)) {
    New-Item -ItemType File -Path $envPath | Out-Null
}

$lines = @()
$lines += "FLASK_ENV=production"
$lines += "SECRET_KEY=$SecretKey"
$lines += "REMEMBER_COOKIE_DURATION_DAYS=3650"
$lines += "PERMANENT_SESSION_LIFETIME_DAYS=3650"
if ($DatabaseUrl) { $lines += "DATABASE_URL=$DatabaseUrl" }
if ($StorageRoot) { $lines += "STORAGE_ROOT=$StorageRoot" }
Set-Content -Path $envPath -Value ($lines -join "`r`n") -Encoding UTF8

Write-Host "Arquivo .env preparado em $envPath" -ForegroundColor Green

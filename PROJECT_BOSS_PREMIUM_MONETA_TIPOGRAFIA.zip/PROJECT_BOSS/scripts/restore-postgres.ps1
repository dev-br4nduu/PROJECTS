param(
    [string]$Host = "localhost",
    [int]$Port = 5432,
    [string]$Database = "boss_seguros",
    [string]$User = "postgres",
    [string]$InputFile = ".\backup_boss_seguros.dump"
)
$ErrorActionPreference = "Stop"
pg_restore -h $Host -p $Port -U $User -d $Database -v $InputFile
Write-Host "Restauração concluída"

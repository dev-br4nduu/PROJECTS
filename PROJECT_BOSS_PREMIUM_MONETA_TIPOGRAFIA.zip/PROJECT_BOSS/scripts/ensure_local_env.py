from __future__ import annotations

import secrets
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ENV_LOCAL = ROOT / '.env.local'
DATA_DIR = ROOT / 'data'
UPLOAD_DIR = DATA_DIR / 'uploads'
DB_FILE = DATA_DIR / 'boss_seguros.db'


def generate_secret_key() -> str:
    return secrets.token_urlsafe(64)


def parse_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for line in path.read_text(encoding='utf-8').splitlines():
        line = line.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        k, v = line.split('=', 1)
        values[k.strip()] = v.strip()
    return values


def main() -> int:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

    current = parse_env(ENV_LOCAL)
    changed = False

    defaults = {
        'APP_ENV': 'production',
        'BOSS_HOST': '127.0.0.1',
        'BOSS_PORT': os.environ.get('BOSS_PORT', '5000'),
        'DATABASE_URL': f'sqlite:///{DB_FILE.as_posix()}',
        'UPLOAD_FOLDER': UPLOAD_DIR.as_posix(),
        'DEFAULT_ORGANIZATION_SLUG': 'boss-default',
        'REQUIRE_ORG_ON_LOGIN': 'false',
        'ENABLE_SCHEDULER': 'false',
        'SESSION_COOKIE_SECURE': 'false',
        'REMEMBER_COOKIE_SECURE': 'false',
        'SESSION_DAYS': '3650',
        'REMEMBER_COOKIE_DAYS': '3650',
    }

    if not current.get('SECRET_KEY') or current.get('SECRET_KEY') == 'change-this-secret-key':
        current['SECRET_KEY'] = generate_secret_key()
        changed = True

    for k, v in defaults.items():
        if current.get(k) != v:
            current[k] = v
            changed = True

    if changed or not ENV_LOCAL.exists():
        lines = ['# Arquivo local gerado automaticamente para execução via navegador.']
        for key in sorted(current.keys()):
            lines.append(f'{key}={current[key]}')
        ENV_LOCAL.write_text('\n'.join(lines) + '\n', encoding='utf-8')
        print(f'[Boss] Ambiente local preparado em: {ENV_LOCAL}')
    else:
        print(f'[Boss] Ambiente local já estava pronto: {ENV_LOCAL}')

    print(f'[Boss] Banco local: {DB_FILE}')
    print(f'[Boss] Uploads: {UPLOAD_DIR}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

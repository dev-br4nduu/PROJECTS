; Inno Setup script - Boss Seguros CRM
#define MyAppName "Boss Seguros CRM"
#define MyAppVersion "3.7"
#define MyAppPublisher "Moneta / Boss"
#define MyAppExeName "BossSegurosCRM.exe"

[Setup]
AppId={{A0E1F7AA-D9D8-4A58-9B1A-9F36A7F1D001}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
OutputDir=dist_installer
OutputBaseFilename=BossSegurosCRM-Setup
Compression=lzma
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
DisableDirPage=no
ArchitecturesInstallIn64BitMode=x64compatible
SetupIconFile=app\static\icons\bossseguros.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
ChangesAssociations=no
CloseApplications=no
DisableProgramGroupPage=yes

[Languages]
Name: "portuguesebrazil"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "Criar atalho na Área de Trabalho"; GroupDescription: "Atalhos:"; Flags: checked

[Dirs]
Name: "{app}\BossSegurosData"
Name: "{app}\BossSegurosData\uploads"

[Files]
Source: "dist\BossSegurosCRM.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: ".env.desktop.local.example"; DestDir: "{app}\BossSegurosData"; DestName: ".env"; Flags: onlyifdoesntexist
Source: "app\static\icons\bossseguros.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "LEIA-ME-USUARIO.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "LEIA-ME-PRIMEIRO.txt"; DestDir: "{app}"; Flags: ignoreversion isreadme

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\bossseguros.ico"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\bossseguros.ico"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Abrir Boss Seguros CRM"; Flags: nowait postinstall skipifsilent

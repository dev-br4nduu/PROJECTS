# Cria atalho "Boss Seguros CRM" na Area de Trabalho apontando para dist\BossSegurosCRM.exe
# Uso:  powershell -ExecutionPolicy Bypass -File scripts\Criar-Atalho-Desktop.ps1

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$exe = Join-Path $root "dist\BossSegurosCRM.exe"
if (-not (Test-Path -LiteralPath $exe)) {
    Write-Host "Nao encontrado: $exe" -ForegroundColor Red
    Write-Host "Gere o executavel primeiro: scripts\build-desktop.bat" -ForegroundColor Yellow
    exit 1
}
$desk = [Environment]::GetFolderPath("Desktop")
$lnkPath = Join-Path $desk "Boss Seguros CRM.lnk"
$w = New-Object -ComObject WScript.Shell
$s = $w.CreateShortcut($lnkPath)
$s.TargetPath = (Resolve-Path -LiteralPath $exe).Path
$s.WorkingDirectory = Split-Path -Parent $s.TargetPath
$s.Description = "Boss Seguros CRM"
$s.IconLocation = "$($s.TargetPath),0"
$s.Save()
Write-Host "Atalho criado: $lnkPath" -ForegroundColor Green

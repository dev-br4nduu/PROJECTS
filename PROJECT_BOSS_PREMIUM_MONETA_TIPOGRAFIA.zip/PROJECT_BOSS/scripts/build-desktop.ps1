$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Root = (Resolve-Path -LiteralPath $Root).Path
$env:BOSS_SEGUROS_CRM_ROOT = $Root
Set-Location -LiteralPath $Root

$InstallDeps = Join-Path $Root "scripts\install-dependencies.py"
Write-Host "Instalando dependências (adaptadas ao Python em uso)..."
if (Get-Command python -ErrorAction SilentlyContinue) {
    python $InstallDeps --desktop --build
} elseif (Get-Command py -ErrorAction SilentlyContinue) {
    py -3 $InstallDeps --desktop --build
} else {
    throw "Python não encontrado (comando 'python' ou 'py')."
}
if ($LASTEXITCODE -ne 0) {
    throw "Falha em scripts/install-dependencies.py"
}

Write-Host "Gerando executável desktop..."
pyinstaller --noconfirm --clean BossSegurosCRM.spec

$exe = Join-Path $Root "dist\BossSegurosCRM.exe"
Write-Host "Build concluído: $exe"
Write-Host "Atalho (opcional): .\scripts\Criar-Atalho-Desktop.ps1 ou .\scripts\create-desktop-shortcut.ps1"

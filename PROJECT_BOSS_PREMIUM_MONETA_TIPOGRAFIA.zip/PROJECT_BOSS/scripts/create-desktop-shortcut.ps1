# Cria atalho .lnk na Área de Trabalho (sem .bat).
# Uso:
#   .\scripts\create-desktop-shortcut.ps1
#   .\scripts\create-desktop-shortcut.ps1 -ExePath "C:\caminho\BossSegurosCRM.exe"
Param(
    [Parameter(Mandatory = $false)][string]$ExePath = "",
    [Parameter(Mandatory = $false)][string]$ShortcutName = "Boss Seguros CRM"
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Root = (Resolve-Path -LiteralPath $Root).Path

if (-not $ExePath) {
    $ExePath = Join-Path $Root "dist\BossSegurosCRM.exe"
}

if (-not (Test-Path -LiteralPath $ExePath)) {
    Write-Error "Executável não encontrado: $ExePath`nExecute antes scripts\build-desktop.ps1"
}

$resolved = (Resolve-Path -LiteralPath $ExePath).Path
$workDir = Split-Path -Parent $resolved
$desktop = [Environment]::GetFolderPath("Desktop")
$linkPath = Join-Path $desktop "$ShortcutName.lnk"

$ws = New-Object -ComObject WScript.Shell
$shortcut = $ws.CreateShortcut($linkPath)
$shortcut.TargetPath = $resolved
$shortcut.WorkingDirectory = $workDir
$shortcut.Description = "Boss Seguros CRM — aplicativo desktop"
$shortcut.IconLocation = "$resolved,0"
$shortcut.Save()

Write-Host "Atalho criado: $linkPath" -ForegroundColor Green

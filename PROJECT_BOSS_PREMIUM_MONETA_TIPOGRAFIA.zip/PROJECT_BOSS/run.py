import os
import socket
import sys
from contextlib import closing

if sys.version_info < (3, 9):
    raise SystemExit(
        "Boss Seguros CRM requer Python 3.9 ou superior "
        f"(ambiente: {sys.version_info.major}.{sys.version_info.minor})."
    )

from app import create_app
from app.cli import register_cli

app = create_app()
register_cli(app)


def _dev_listen_port() -> int:
    """
    Porta do servidor de desenvolvimento.
    - Sem FLASK_RUN_PORT / PORT: porta livre automática (não depende de 5000).
    - FLASK_RUN_PORT=0 ou vazio após trim: idem.
    - FLASK_RUN_PORT=N: usa N (erro se ocupada).
    """
    raw = os.environ.get("FLASK_RUN_PORT") or os.environ.get("PORT")
    if raw is None or str(raw).strip() == "":
        with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("127.0.0.1", 0))
            return int(s.getsockname()[1])
    try:
        want = int(str(raw).strip())
    except ValueError:
        want = 0
    if want <= 0:
        with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("127.0.0.1", 0))
            return int(s.getsockname()[1])
    return want


if __name__ == "__main__":
    host = os.environ.get("FLASK_RUN_HOST", "127.0.0.1")
    port = _dev_listen_port()
    print(f" * Boss Seguros CRM — http://{host}:{port}/")
    app.run(debug=True, host=host, port=port)

@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "VENV=%CD%\.venv"
set "PYTHON_EXE="

if exist "%VENV%\Scripts\python.exe" (
    set "PYTHON_EXE=%VENV%\Scripts\python.exe"
) else (
    where py >nul 2>&1 && (
        py -3 -m venv "%VENV%"
    ) || (
        python -m venv "%VENV%"
    )
    if exist "%VENV%\Scripts\python.exe" set "PYTHON_EXE=%VENV%\Scripts\python.exe"
)

if not defined PYTHON_EXE (
    echo [ERRO] Nao foi possivel preparar o ambiente Python.
    pause
    exit /b 1
)

echo [Boss] Preparando dependencias...
"%PYTHON_EXE%" "%CD%\scripts\install-dependencies.py" --quiet --skip-upgrade-pip
if errorlevel 1 (
    echo [ERRO] Falha ao instalar dependencias.
    pause
    exit /b 1
)

echo [Boss] Preparando ambiente local...
"%PYTHON_EXE%" "%CD%\scripts\ensure_local_env.py"
if errorlevel 1 (
    echo [ERRO] Falha ao preparar o ambiente local.
    pause
    exit /b 1
)

start "BossBrowser" /min "%PYTHON_EXE%" "%CD%\scripts\open_browser_when_ready.py"

echo [Boss] Iniciando servidor web...
"%PYTHON_EXE%" "%CD%\browser_server.py"

pause
endlocal

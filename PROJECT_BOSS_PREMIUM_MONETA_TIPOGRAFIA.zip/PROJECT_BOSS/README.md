# Boss Seguros CRM

## Execução recomendada no Windows

Para abrir o sistema via navegador com inicialização automática, use:

```bat
INICIAR_NAVEGADOR.bat
```

Esse arquivo:
- cria `.venv` se necessário
- instala dependências
- prepara `.env.local` com `SECRET_KEY` persistente
- cria banco SQLite local em `./data/`
- abre o sistema no navegador
- inicia o servidor estável com Waitress, sem debug/reloader

Acesso padrão:
- E-mail: `admin@bossseguros.com`
- Senha: `Admin@123`
- Workspace: `boss-default`

---


CRM para corretora de seguros com foco em operação comercial, apólices, sinistros, documentos, renovações e base multi-tenant.

## O que foi profissionalizado nesta versão
- limpeza de arquivos duplicados, caches e documentos de refatoração temporários
- organização por camadas: `blueprints`, `services`, `repositories`, `models`
- configuração separada por ambiente em `config/`
- bootstrap mais previsível em `app/core/`
- tratamento centralizado de erros e logging estruturado
- refatoração dos módulos `clients`, `policies`, `claims`, `documents` e `renewals` para service/repository pattern
- padronização de qualidade com `pytest`, `ruff`, `black`, `.editorconfig` e `Makefile`

## Estrutura principal
```txt
app/
  blueprints/
  core/
  extensions.py
  models/
  repositories/
  services/
  templates/
  utils/
config/
  base.py
  development.py
  production.py
  testing.py
tests/
  unit/
```

## Execução local
Requer **Python 3.9+**. Dependências com intervalos de versão; o script abaixo adapta-se ao interpretador em uso.

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
python scripts/install-dependencies.py --dev
python run.py
```

## Qualidade
```bash
make test
make lint
```

## Próximos passos recomendados
1. Migrar `admin`, `crm`, `imports` e `reports` para a mesma arquitetura.
2. Adicionar coverage mínima em CI e testes de integração por blueprint.
3. Criar API pública autenticada, billing e trilha de observabilidade.


## Fase 3 de profissionalização

- refatoração dos módulos `admin`, `crm`, `imports` e `reports`
- extração de serviços e repositórios dedicados
- redução adicional de acoplamento nas rotas Flask
- consolidação dos indicadores gerenciais em `ReportService`

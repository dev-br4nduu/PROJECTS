Boss Seguros CRM — empacotamento desktop (.exe)
================================================

Saida do build
--------------
O PyInstaller gera **um único ficheiro**:

  dist\BossSegurosCRM.exe

(mesma sistemática que o projeto Moneta Tarefas / painel tarefas: pasta `scripts`
e resultado em `dist`.)

Ícone do executável
-------------------
- **app\static\icons\bossseguros.ico** — usado pelo `BossSegurosCRM.spec`.

Dados ao correr o .exe
----------------------
- Pasta **BossSegurosData** ao lado do `.exe` (base de dados, uploads, etc.).
- Opcional: copiar **.env.desktop.local.example** para **BossSegurosData\.env**
  se precisar de variáveis específicas.

Erro: PermissionError / Acesso negado (dist\BossSegurosCRM.exe)
--------------------------------------------------------------
O PyInstaller precisa **substituir** o ficheiro antigo. O Windows bloqueia se:

- O **BossSegurosCRM.exe** ainda estiver a correr — feche a janela do app.
- O **OneDrive** estiver a sincronizar a pasta — pause a sincronização ou copie
  o projeto para um disco local (ex.: `C:\Apps\PROJECT_BOSS`).

O **scripts\build-desktop.bat** tenta terminar `BossSegurosCRM.exe` e apagar o
`.exe` antigo antes do build.

Ficheiros .bat (cmd.exe)
------------------------
Os scripts em `scripts\*.bat` usam **apenas ASCII** e **não** chamam `chcp 65001`
no início: em muitos PCs, UTF-8 + `chcp 65001` faz o `cmd` partir comandos
(`set` vira `et`, `%PY_CMD%` falha). Mensagens longas estão em inglês nos .bat
por estabilidade; use PowerShell (`build-desktop.ps1`) se preferir UTF-8.

Versão do Python (3.9+)
-----------------------
O projeto usa **intervalos** em `requirements.txt` para o pip resolver na sua
versão. O script **`scripts\install-dependencies.py`**:

- atualiza pip/setuptools/wheel (útil em Python mais antigo);
- aplica **fallback** automático se `pywebview` falhar (Python muito recente /
  sem wheel para `pythonnet`);
- recusa versões abaixo de **Python 3.9** (exigência do Flask 3.1).

Exemplos na raiz do projeto:

  python scripts\install-dependencies.py
  python scripts\install-dependencies.py --desktop --build
  python scripts\install-dependencies.py --postgres --dev

Qual intérprete usam os .bat?
-----------------------------
1. Se existir **.venv-desktop** → `python` desse ambiente.
2. Senão, a variável **PYTHON** (caminho completo para `python.exe`).
3. Senão, o comando **python** no PATH.
4. Senão, o launcher **py**.

Fluxo típico com venv
---------------------
1. `scripts\criar-venv-desktop.bat`
2. `.venv-desktop\Scripts\activate`
3. `scripts\build-desktop.bat`

Equivalente em PowerShell (na raiz do projeto):

  .\scripts\build-desktop.ps1

Atalho na Área de Trabalho
--------------------------
- `scripts\Criar-Atalho-Desktop.ps1`
- ou `scripts\create-desktop-shortcut.ps1`

Desenvolvimento sem .exe (Flask)
--------------------------------
- `Iniciar-Boss.bat` na raiz, ou `scripts\Iniciar.bat`.

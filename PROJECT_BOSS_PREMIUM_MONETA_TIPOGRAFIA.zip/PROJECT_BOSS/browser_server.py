from __future__ import annotations

import os
from pathlib import Path

from waitress import serve

from app import create_app, db
from app.cli import ensure_admin_and_lookups


def ensure_local_structure() -> None:
    data_root = Path(os.environ.get("BOSS_DATA_DIR", "data")).resolve()
    data_root.mkdir(parents=True, exist_ok=True)
    (data_root / "uploads").mkdir(parents=True, exist_ok=True)


def bootstrap() -> None:
    app = create_app()
    with app.app_context():
        db.create_all()
        ensure_admin_and_lookups()
    host = os.environ.get("BOSS_HOST", "127.0.0.1")
    port = int(os.environ.get("BOSS_PORT", os.environ.get("PORT", "5000")))
    print(f" * Boss Seguros CRM disponível em http://{host}:{port}/auth/login")
    serve(app, host=host, port=port, threads=8)


if __name__ == "__main__":
    ensure_local_structure()
    bootstrap()

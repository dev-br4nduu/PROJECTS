# Deploy multiusuário — Boss Seguros CRM

## Cenário recomendado
Use **um PostgreSQL central** e instale o executável desktop em cada máquina. Todos os usuários compartilham a mesma base.

### Vantagens
- mesma carteira, apólices, renovações e documentos para todos;
- backup centralizado;
- governança de usuários mais simples;
- não exige navegador aberto.

## Arquitetura sugerida
1. **Servidor PostgreSQL** em uma máquina estável ou VM.
2. **Pasta de uploads** centralizada ou sincronizada por rotina de backup.
3. **Executável desktop** instalado em cada estação.
4. Em cada estação, o arquivo `BossSegurosData/.env` aponta para o mesmo `DATABASE_URL`.

## Exemplo de DATABASE_URL
`postgresql+psycopg://boss_app:senha_forte@192.168.1.50:5432/boss_seguros`

## Se as máquinas não estiverem na mesma rede
Há dois caminhos:

### Opção A — VPN / Tailscale / ZeroTier
É o mais simples. Todas as máquinas passam a enxergar o servidor PostgreSQL com IP privado seguro.

### Opção B — Hospedar o PostgreSQL em nuvem
Use uma VM Windows/Linux ou um serviço gerenciado. Cada desktop aponta para o host público protegido por firewall.

## Cenário provisório com bases separadas
Cada máquina pode usar sua própria base local. Isso funciona, mas os dados ficam isolados. Só recomendo para piloto ou demonstração.

## Arquivos que precisam existir em cada PC
- `BossSegurosCRM.exe` e a pasta do instalador;
- `BossSegurosData/.env` com o `DATABASE_URL` correto;
- `BossSegurosData/uploads` para anexos locais, se aplicável.

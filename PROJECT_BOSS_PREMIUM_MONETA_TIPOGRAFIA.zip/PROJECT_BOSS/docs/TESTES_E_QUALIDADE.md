# Testes e qualidade

## Cobertura desta etapa
- autenticação
- proteção de rota autenticada
- permissão básica de admin
- geração e validação de token de redefinição
- healthcheck e readycheck

## Rotina mínima antes de publicar versão
1. Executar `pytest`
2. Executar `python scripts/smoke_test.py`
3. Executar `flask validate-env`
4. Validar login desktop e download/upload em ambiente real

## Observações
Os testes atuais são de **smoke + integração leve**. Ainda não substituem uma suíte extensa de domínio, mas já reduzem regressões nas rotas e no bootstrap da aplicação.

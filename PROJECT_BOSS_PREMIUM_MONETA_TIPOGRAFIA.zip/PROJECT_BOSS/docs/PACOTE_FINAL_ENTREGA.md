# Pacote final de entrega operacional

## Itens do pacote
- código-fonte da aplicação
- scripts de build desktop
- script Inno Setup
- exemplos de `.env`
- migrações
- documentação de deploy multiusuário
- documentação de backup/restore
- testes automatizados e smoke test

## Estratégia recomendada
- **servidor PostgreSQL central**
- **pasta compartilhada para documentos**, quando a operação exigir anexos centralizados
- **instalador desktop em cada estação** apontando para o mesmo banco

## Critérios de aceite técnico
- login persistente
- endpoints de health e ready respondendo
- `validate-env` sem erros
- smoke test passando
- rotas principais abrindo com usuário admin e viewer

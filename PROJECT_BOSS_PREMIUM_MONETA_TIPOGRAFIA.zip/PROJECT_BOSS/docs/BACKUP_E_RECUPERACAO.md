# Backup e recuperação

## Banco de dados

Use os scripts existentes:
- `scripts/backup-postgres.ps1`
- `scripts/restore-postgres.ps1`

## Anexos / documentos

Mantenha cópia da pasta configurada em `UPLOAD_FOLDER` ou `STORAGE_ROOT`.

## Frequência sugerida

- banco: diário
- documentos: diário ou a cada 4h, conforme criticidade

## Teste de restauração

Valide mensalmente a restauração em ambiente separado.

# SaaS Multi-tenant

## O que foi aplicado
- isolamento lógico por `organization_id`
- login com workspace por slug
- suporte a resolução do workspace por querystring, header ou subdomínio
- CRUD de workspaces para `platform_admin`
- usuários únicos por workspace

## Estratégias
- `TENANT_STRATEGY=path`: usa `?org=slug` ou campo no login
- `TENANT_STRATEGY=subdomain`: usa `slug.seudominio.com` com `ROOT_HOST` configurado

## Comandos úteis
- `flask seed-platform-admin`
- `flask create-organization acme "Acme Corretora" --admin-email admin@acme.com`
- `flask seed-demo --org-slug acme --org-name "Acme Corretora"`

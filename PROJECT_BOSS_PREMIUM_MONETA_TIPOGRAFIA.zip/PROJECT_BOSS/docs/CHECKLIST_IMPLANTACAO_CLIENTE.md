# Checklist de implantação no cliente

## Antes de instalar

- [ ] PostgreSQL central disponível e acessível
- [ ] Banco criado
- [ ] Usuário de aplicação criado
- [ ] Pasta compartilhada de storage criada, se aplicável
- [ ] Porta do PostgreSQL liberada
- [ ] WebView2 Runtime instalado nas máquinas cliente

## Durante a instalação

- [ ] Executar o instalador como administrador
- [ ] Confirmar criação do atalho
- [ ] Validar abertura da janela dedicada sem navegador exposto
- [ ] Validar ausência de console visível

## Pós-instalação

- [ ] Configurar `.env` em `BossSegurosData`
- [ ] Executar migrações do banco
- [ ] Criar usuário administrador inicial
- [ ] Validar login
- [ ] Validar dashboard
- [ ] Validar upload/download de documentos
- [ ] Validar envio de e-mail
- [ ] Validar notificação manual
- [ ] Validar renovação e status

## Multiusuário

- [ ] Segunda estação instalada
- [ ] Ambas conectadas ao mesmo PostgreSQL
- [ ] Ambas apontando para o mesmo `STORAGE_ROOT`, se compartilhado
- [ ] Concorrência básica validada com dois logins simultâneos

## Aceite

- [ ] Atalho funcional
- [ ] Sessão persistente funcionando
- [ ] Performance aceitável
- [ ] Backup inicial executado
- [ ] Restore testado em ambiente de homologação

# Segurança e operação final

## Melhorias entregues nesta fase

- bloqueio temporário após tentativas inválidas de login
- endpoint de saúde do storage
- validação de ambiente mais rígida em produção
- suporte a proxy reverso com `ProxyFix`
- comando CLI para desbloqueio de usuários

## Checklist de produção

1. gerar `SECRET_KEY` forte
2. usar PostgreSQL em vez de SQLite
3. ativar `SESSION_COOKIE_SECURE=true` e `REMEMBER_COOKIE_SECURE=true` com HTTPS
4. configurar SMTP real
5. definir rotina de backup do banco e anexos
6. revisar permissões por perfil antes do go-live

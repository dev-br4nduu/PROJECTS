# Windows build e instalação

## Objetivo

Gerar um executável desktop do Boss Seguros CRM sem console aparente e empacotar um instalador profissional para o cliente final.

## Pré-requisitos da máquina de build

- Windows 10/11 64-bit
- Python 3.9 ou superior (recomendado 3.11–3.12 para pywebview no Windows)
- pip atualizado (o script de instalação atualiza automaticamente quando necessário)
- Inno Setup 6 instalado
- Microsoft Edge WebView2 Runtime
- PostgreSQL acessível no ambiente de destino

## Passo a passo

### 1. Criar venv e instalar dependências

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python scripts/install-dependencies.py --postgres --desktop --build --dev
```

### 2. Rodar smoke test e testes

```powershell
pytest
python .\scripts\smoke_test.py
```

### 3. Gerar o executável e o instalador

```powershell
.\scripts\build-installer.ps1
```

### 4. Resultado esperado

- `dist\BossSegurosCRM.exe`
- `dist_installer\BossSegurosCRM-Setup.exe`

## Instalação no cliente

### 1. Instalar o programa

Executar `BossSegurosCRM-Setup.exe` como administrador.

### 2. Preparar o arquivo .env do cliente

Exemplo com PostgreSQL central e storage compartilhado:

```powershell
.\scripts\prepare-client-package.ps1 `
  -InstallPath "C:\Program Files\Boss Seguros CRM" `
  -DatabaseUrl "postgresql+psycopg://boss_app:senha@10.0.0.25:5432/bossseguros" `
  -StorageRoot "\\SRV-ARQ\BossSeguros\storage"
```

### 3. Abrir o programa

Abrir o atalho do Desktop ou Menu Iniciar.

## Observações

- o launcher desktop sobe o servidor local com Waitress e abre a UI em janela dedicada via pywebview
- a sessão persistente depende da `SECRET_KEY` permanecer estável no diretório `BossSegurosData`
- use PostgreSQL central para cenários multiusuário reais
- mantenha `STORAGE_ROOT` em compartilhamento SMB se documentos precisarem ser comuns a todas as estações

# Homologação final — Boss Seguros CRM

Este documento consolida a validação final para implantar o sistema em cliente real.

## Escopo de homologação

1. Acesso e autenticação
2. Cadastro de clientes
3. Cadastro de veículos, condutores e produtos
4. Emissão e manutenção de apólices
5. Fluxo de renovação
6. Envio de propostas por e-mail e WhatsApp
7. Upload e download de documentos
8. Dashboard e KPIs
9. Notificações automáticas e manuais
10. Operação multiusuário com PostgreSQL central

## Cenários mínimos de aceite

### 1. Login persistente
- Usuário entra no sistema
- Fecha a janela
- Reabre o aplicativo
- Continua autenticado quando o ambiente local e o remember cookie estiverem válidos

### 2. Cadastro operacional
- Criar cliente PF e PJ
- Inativar cliente
- Marcar cliente para reconquista
- Validar documento duplicado

### 3. Produtos e apólices
- Seguro Auto exige veículo
- Convênio Médico exige operadora
- Residencial exige endereço do risco
- Eletrônicos exige item segurado
- Consórcio exige titular do contrato

### 4. Renovação
- Criar apólice com vencimento em 20 dias
- Confirmar entrada na régua interna e externa
- Alterar renovação para `renovado`
- Confirmar interrupção da régua e disparo de sucesso

### 5. Propostas
- Abrir proposta por WhatsApp Web
- Enviar proposta por e-mail
- Confirmar lançamento em auditoria

### 6. Multiusuário
- Abrir em duas estações apontando para o mesmo PostgreSQL
- Confirmar que ambas enxergam os mesmos dados
- Confirmar upload e download em storage compartilhado

## Evidências recomendadas
- prints de tela por módulo
- planilha de cenários executados
- registro do usuário homologador
- data e versão da build

## Critério de aprovação
A aprovação ocorre quando:
- não houver bloqueadores de operação
- dashboard, cadastro, renovação, documentos e envios estiverem funcionais
- a instalação em pelo menos 2 estações estiver estável

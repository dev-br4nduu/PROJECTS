# SaaS Onboarding e Provisioning

## O que esta fase resolve
1. Receber novos clientes na plataforma
2. Criar automaticamente um workspace
3. Criar o admin inicial
4. Associar um plano SaaS
5. Registrar uma assinatura inicial em trial

## Fluxo
- Cliente acessa `/onboarding/start`
- Escolhe plano
- Informa empresa, workspace e admin
- Plataforma provisiona tudo automaticamente
- Cliente é redirecionado para o login do workspace

## Próximas camadas
- confirmação de e-mail
- cobrança/billing
- onboarding guiado dentro do produto
- aceites legais e políticas de LGPD por workspace

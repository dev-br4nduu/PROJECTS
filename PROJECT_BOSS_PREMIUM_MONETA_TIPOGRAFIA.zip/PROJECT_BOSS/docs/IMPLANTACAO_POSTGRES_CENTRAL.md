# Implantação multiusuário com PostgreSQL central

## Topologia recomendada

- 1 servidor Windows ou Linux com PostgreSQL
- 1 pasta compartilhada para documentos e anexos
- 1 instalador desktop por estação de trabalho
- todos os clientes apontando para o mesmo `DATABASE_URL` e `STORAGE_ROOT`

## Variáveis principais

- `DATABASE_URL` apontando para o PostgreSQL central
- `UPLOAD_FOLDER` ou `STORAGE_ROOT` apontando para pasta compartilhada
- `SESSION_COOKIE_SECURE=true` quando houver HTTPS/túnel seguro
- `BEHIND_PROXY=true` se houver proxy reverso

## Recomendação operacional

- liberar acesso ao PostgreSQL apenas pela rede interna/VPN
- manter backup diário do banco
- manter backup dos anexos em janela separada
- usar usuários individuais do sistema para auditoria

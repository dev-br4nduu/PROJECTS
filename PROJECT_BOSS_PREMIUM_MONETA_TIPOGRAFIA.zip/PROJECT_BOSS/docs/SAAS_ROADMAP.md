# Boss Seguros CRM — Base SaaS

## O que esta fase entrega
- busca global
- persistencia de filtros por modulo
- politica de senha mais forte
- endurecimento basico de upload
- auditoria com metadata de IP e rota
- ativos de deploy web: Dockerfile, compose e Nginx
- pipeline inicial de CI

## O que ainda e a proxima camada para SaaS pleno
- isolamento multi-tenant forte por organizacao/workspace
- billing/assinatura
- onboarding self-service
- MFA opcional para perfis administrativos
- object storage (S3/compatível) e CDN
- observabilidade centralizada com alertas
- LGPD operacional com retenção e descarte parametrico

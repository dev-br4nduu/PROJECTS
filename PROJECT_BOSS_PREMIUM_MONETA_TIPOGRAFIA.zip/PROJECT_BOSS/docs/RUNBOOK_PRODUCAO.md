# Runbook de produção — Boss Seguros CRM

## Checklist inicial
- criar banco PostgreSQL `boss_seguros`;
- criar usuário dedicado `boss_app`;
- preencher `.env.production.example`;
- rodar migrações do Alembic;
- validar SMTP;
- validar login, dashboard e envio de proposta.

## Migração inicial
```powershell
$env:FLASK_APP="run.py"
$env:DATABASE_URL="postgresql+psycopg://boss_app:senha@localhost:5432/boss_seguros"
flask db upgrade
```

## Backup
Use `scripts/backup-postgres.ps1` diariamente.

## Restore
Use `scripts/restore-postgres.ps1` em ambiente controlado.

## Atualização do cliente desktop
1. gerar novo instalador;
2. instalar por cima da versão atual;
3. preservar `BossSegurosData/.env` e a pasta de uploads.

# Checklist de aceite operacional

## Infraestrutura
- [ ] PostgreSQL central configurado
- [ ] Backup testado
- [ ] Restore testado
- [ ] STORAGE_ROOT acessível
- [ ] SECRET_KEY de produção configurada
- [ ] SMTP validado
- [ ] Healthcheck OK
- [ ] Readycheck OK

## Aplicativo desktop
- [ ] Instalador executado sem erro
- [ ] Atalho criado na área de trabalho
- [ ] Aplicação abre sem console
- [ ] Ícone correto na janela
- [ ] Ícone correto no atalho
- [ ] Sessão persistente funcionando

## Fluxos de negócio
- [ ] Cliente criado
- [ ] Veículo criado
- [ ] Apólice criada
- [ ] Renovação atualizada
- [ ] Proposta enviada por e-mail
- [ ] Link de WhatsApp aberto corretamente
- [ ] Documento anexado
- [ ] Dashboard consistente

## Segurança e operação
- [ ] Lock de login testado
- [ ] Desbloqueio via CLI testado
- [ ] Cookies e proxy revisados
- [ ] Permissões por perfil testadas
- [ ] Usuários inativos impedidos de entrar

## Homologação
- [ ] Usuário-chave aprovou a operação
- [ ] Usuário-chave aprovou o visual
- [ ] Usuário-chave aprovou os KPIs
- [ ] Usuário-chave aprovou renovação e propostas
- [ ] Projeto liberado para produção

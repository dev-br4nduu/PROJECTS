# Arquitetura do Boss Seguros CRM

## Objetivo
Transformar o projeto em uma base mais vendável, previsível e sustentável para evolução SaaS.

## Camadas
- **Blueprints**: interface HTTP e renderização.
- **Services**: regras de negócio e orquestração.
- **Repositories**: acesso a dados e composição de queries.
- **Models**: entidades ORM.
- **Core**: bootstrap, hooks, registro de blueprints, logging e error handling.
- **Config**: configuração separada por ambiente.

## Decisões aplicadas nesta refatoração
1. Remoção de artefatos duplicados, caches e documentos transitórios do repositório.
2. Centralização das extensões Flask em `app/extensions.py`.
3. Registro central de blueprints em `app/core/blueprints.py`.
4. Criação de services e repositories para `clients`, `policies`, `claims`, `documents` e `renewals`.
5. Separação da configuração em pacote `config/`.
6. Inclusão de padrões de qualidade: `ruff`, `black`, `pytest`, `.editorconfig` e `Makefile`.
7. Inclusão de logging estruturado e tratamento centralizado de erros HTTP.

## Módulos já migrados
- `clients`
- `policies`
- `claims`
- `documents`
- `renewals`

## Módulos prioritários para próxima onda
- `admin`
- `crm`
- `imports`
- `reports`

## Roadmap de produto vendável
- Auditoria expandida por tenant e por usuário
- Billing / assinatura
- Catálogo de planos
- API pública autenticada
- Observabilidade (Sentry + logs estruturados)
- Filas assíncronas para e-mails e documentos
- Versionamento de documentos e trilha de aprovação


## Avanço da refatoração — fase 3

Os módulos `admin`, `crm`, `imports` e `reports` agora seguem o mesmo padrão das áreas já refatoradas:

- `routes.py` fica restrito ao papel de controller HTTP
- regras de negócio ficam em `app/services/`
- consultas e agregações ficam em `app/repositories/`
- auditoria operacional segue centralizada em `app/services/audit_service.py`

### Novos serviços

- `AdminService`
- `CRMService`
- `ImportAppService`
- `ReportService`

### Novos repositórios

- `OrganizationRepository`
- `SMTPSettingsRepository`
- `UserRepository`
- `ProviderRepository`
- `SaaSPlanRepository`
- `SubscriptionRepository`
- `NotificationRepository`
- `CRMOpportunityRepository`
- `ImportBatchRepository`

### Resultado arquitetural

Com isso, os módulos mais densos do sistema deixam de concentrar persistência, regra de negócio e renderização no mesmo arquivo, reduzindo acoplamento e preparando a base para:

- API pública
- testes de integração por caso de uso
- automação comercial e billing
- versionamento de regras de negócio

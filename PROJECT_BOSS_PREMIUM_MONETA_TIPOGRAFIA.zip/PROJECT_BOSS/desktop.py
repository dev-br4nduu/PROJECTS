"""
Boss Seguros CRM — launcher desktop.

Sobe o servidor Flask local (Waitress) e abre uma janela nativa via pywebview
(Edge WebView2 no Windows). Interface dedicada, sem navegador externo.

Ajustes de janela (Windows): tamanho com base na área útil do monitor, DPI
aware, zoom via BOSS_UI_ZOOM (e variável CSS --boss-ui-zoom no app).
"""
from __future__ import annotations

import os
import socket
import sys
import threading
import time
from contextlib import closing
from pathlib import Path


LOCK_FILE_NAME = ".boss_seguros.lock"


def _pid_process_alive(pid: int) -> bool:
    """True se o PID ainda existe (Windows). Usado para remover lock obsoleto."""
    if pid <= 0:
        return False
    if sys.platform != "win32":
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False
    try:
        import ctypes

        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        h = ctypes.windll.kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if h:
            ctypes.windll.kernel32.CloseHandle(h)
            return True
    except Exception:
        pass
    return False


def _remove_stale_lock_file(lock_path: Path) -> None:
    """
    Se o .exe anterior terminou sem libertar bem o lock (OneDrive, kill, crash),
    o ficheiro fica com PID antigo — apagar para permitir nova abertura.
    """
    if not lock_path.is_file():
        return
    try:
        raw = lock_path.read_text(encoding="utf-8").strip()
        if raw.isdigit() and not _pid_process_alive(int(raw)):
            lock_path.unlink(missing_ok=True)
    except OSError:
        try:
            lock_path.unlink(missing_ok=True)
        except OSError:
            pass


def _release_single_instance_lock(
    lock_handle: object | None, data_dir: Path | None
) -> None:
    """Fecha o handle e remove o ficheiro para a próxima execução não falhar."""
    if lock_handle is not None:
        try:
            lock_handle.close()
        except OSError:
            pass
    if data_dir is not None:
        try:
            (data_dir / LOCK_FILE_NAME).unlink(missing_ok=True)
        except OSError:
            pass


def _win_set_dpi_aware() -> None:
    """Melhora nitidez em monitores com escala (125%, 150%)."""
    if sys.platform != "win32":
        return
    try:
        import ctypes

        # PROCESS_PER_MONITOR_DPI_AWARE = 2
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            import ctypes

            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def _work_area_size_win() -> tuple[int, int] | None:
    """Retorna largura e altura da área útil (sem barra de tarefas), ou None."""
    if sys.platform != "win32":
        return None
    try:
        import ctypes
        from ctypes import wintypes

        class RECT(ctypes.Structure):
            _fields_ = [
                ("left", wintypes.LONG),
                ("top", wintypes.LONG),
                ("right", wintypes.LONG),
                ("bottom", wintypes.LONG),
            ]

        r = RECT()
        # SPI_GETWORKAREA = 48
        if not ctypes.windll.user32.SystemParametersInfoW(48, 0, ctypes.byref(r), 0):
            return None
        return (r.right - r.left, r.bottom - r.top)
    except Exception:
        return None


def _ideal_window_dimensions() -> tuple[int, int, tuple[int, int]]:
    """
    (largura, altura, (largura_mín, altura_mín)).
    Usa ~90% da área útil no Windows; limites para monitores muito grandes/pequenos.
    """
    w, h = 1520, 920
    min_w, min_h = 1120, 700
    area = _work_area_size_win()
    if area:
        aw, ah = area
        w = max(1180, min(1780, int(aw * 0.90)))
        h = max(720, min(1120, int(ah * 0.88)))
        min_w = max(1024, min(1360, int(w * 0.68)))
        min_h = max(640, min(840, int(h * 0.68)))
    return (w, h, (min_w, min_h))


def _window_dimensions() -> tuple[int, int, tuple[int, int]]:
    """Permite BOSS_WINDOW_WIDTH / BOSS_WINDOW_HEIGHT no .env (opcional)."""
    w, h, mins = _ideal_window_dimensions()
    try:
        if os.environ.get("BOSS_WINDOW_WIDTH"):
            w = int(os.environ["BOSS_WINDOW_WIDTH"])
        if os.environ.get("BOSS_WINDOW_HEIGHT"):
            h = int(os.environ["BOSS_WINDOW_HEIGHT"])
    except ValueError:
        pass
    w = max(1024, min(2560, w))
    h = max(640, min(1600, h))
    return w, h, mins


def _apply_desktop_ui_defaults() -> None:
    """Zoom padrão da UI (1 = 100%). Ajuste em BossSegurosData\\.env: BOSS_UI_ZOOM=0.94"""
    os.environ.setdefault("BOSS_UI_ZOOM", "1")


def _find_free_port(preferred: int) -> int:
    """
    preferred == 0: porta efêmera escolhida pelo SO (sem colisão com outras apps).
    preferred > 0: tenta essa porta; se estiver ocupada, usa porta efêmera.
    """
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        if preferred <= 0:
            sock.bind(("127.0.0.1", 0))
            return int(sock.getsockname()[1])
        try:
            sock.bind(("127.0.0.1", preferred))
            return preferred
        except OSError:
            sock.bind(("127.0.0.1", 0))
            return int(sock.getsockname()[1])


def _resolve_desktop_bind_port() -> int:
    """
    Sem BOSS_DESKTOP_PORT (ou valor 0 / auto): não fixa porta — evita conflito com
    outras aplicações. Com BOSS_DESKTOP_PORT=N, tenta N primeiro.
    """
    raw = (os.environ.get("BOSS_DESKTOP_PORT") or "").strip().lower()
    if raw in ("", "0", "auto"):
        return 0
    try:
        return int(raw)
    except ValueError:
        return 0


def _acquire_single_instance_lock(data_dir: Path | None) -> object | None:
    if data_dir is None:
        return None
    lock_path = data_dir / LOCK_FILE_NAME
    _remove_stale_lock_file(lock_path)
    lock_path.touch(exist_ok=True)
    fh = lock_path.open("r+")
    try:
        if os.name == "nt":
            import msvcrt

            msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl

            fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        fh.seek(0)
        fh.truncate(0)
        fh.write(str(os.getpid()))
        fh.flush()
        return fh
    except Exception:
        fh.close()
        return None


def _prepare_desktop_env() -> Path | None:
    os.environ.setdefault("DESKTOP_MODE", "true")
    os.environ.setdefault("ENABLE_SCHEDULER", "true")

    data: Path | None = None
    frozen = getattr(sys, "frozen", False)
    if frozen:
        base = Path(sys.executable).resolve().parent
        data = base / "BossSegurosData"
        data.mkdir(parents=True, exist_ok=True)
        (data / "uploads").mkdir(parents=True, exist_ok=True)
        secret_file = data / ".secret_key"
        if not os.environ.get("SECRET_KEY"):
            if secret_file.exists():
                os.environ["SECRET_KEY"] = secret_file.read_text(encoding="utf-8").strip()
            else:
                import secrets

                key = secrets.token_hex(32)
                secret_file.write_text(key, encoding="utf-8")
                os.environ["SECRET_KEY"] = key
    try:
        from dotenv import load_dotenv

        if frozen and data is not None:
            load_dotenv(data / ".env", override=False)
        else:
            load_dotenv(override=False)
    except Exception:
        pass

    _apply_desktop_ui_defaults()

    if frozen and data is not None and not os.environ.get("DATABASE_URL") and not os.environ.get("POSTGRES_URL"):
        db_path = data / "boss_seguros.db"
        os.environ.setdefault("DATABASE_URL", f"sqlite:///{db_path.as_posix()}")
    if frozen and data is not None:
        os.environ.setdefault("UPLOAD_FOLDER", str((data / "uploads").resolve()))
    return data


def _wait_for_server(host: str, port: int, timeout_sec: float = 25.0) -> None:
    import urllib.error
    import urllib.request

    deadline = time.monotonic() + timeout_sec
    while time.monotonic() < deadline:
        try:
            urllib.request.urlopen(f"http://{host}:{port}/auth/login", timeout=0.4)
            return
        except (urllib.error.URLError, OSError):
            time.sleep(0.1)
    raise RuntimeError(f"Servidor não respondeu em http://{host}:{port}/ dentro do tempo limite.")


def _run_waitress(app, host: str, port: int) -> None:
    from waitress import serve

    serve(app, host=host, port=port, threads=8)


def _open_webview(url: str) -> None:
    import webview

    width, height, min_size = _window_dimensions()
    webview.settings["ALLOW_DOWNLOADS"] = True

    webview.create_window(
        "Boss Seguros CRM",
        url,
        width=width,
        height=height,
        min_size=min_size,
        confirm_close=True,
        user_agent="BossSegurosCRM-Desktop/1 (WebView2; dedicated)",
    )

    _gui = "edgechromium" if sys.platform == "win32" else None
    webview.start(private_mode=False, gui=_gui)


def main() -> None:
    if sys.version_info < (3, 9):
        raise SystemExit(
            "Boss Seguros CRM requer Python 3.9 ou superior "
            f"(ambiente: {sys.version_info.major}.{sys.version_info.minor})."
        )

    _win_set_dpi_aware()

    data_dir = _prepare_desktop_env()
    lock_handle = _acquire_single_instance_lock(data_dir)
    if data_dir is not None and lock_handle is None:
        raise SystemExit("Boss Seguros CRM já está aberto nesta máquina.")

    try:
        os.environ.setdefault("FLASK_DEBUG", "0")

        from config import ProductionConfig
        from app import create_app
        from app.cli import bootstrap_desktop, register_cli

        host = os.environ.get("BOSS_DESKTOP_HOST", "127.0.0.1")
        port = _find_free_port(_resolve_desktop_bind_port())
        os.environ["BOSS_DESKTOP_PORT"] = str(port)

        app = create_app(ProductionConfig)
        register_cli(app)
        bootstrap_desktop(app)

        thread = threading.Thread(target=_run_waitress, args=(app, host, port), daemon=True)
        thread.start()
        _wait_for_server(host, port)

        url = f"http://{host}:{port}/auth/login"

        try:
            _open_webview(url)
        except ImportError:
            _open_edge_app_mode_or_wait(url)
        except Exception as exc:
            print(f"pywebview não pôde iniciar ({exc!r}); usando fallback.")
            _open_edge_app_mode_or_wait(url)
    finally:
        _release_single_instance_lock(lock_handle, data_dir)


def _open_edge_app_mode_or_wait(url: str) -> None:
    import subprocess

    candidates = [
        Path(os.environ.get("PROGRAMFILES", "")) / "Microsoft" / "Edge" / "Application" / "msedge.exe",
        Path(os.environ.get("PROGRAMFILES(X86)", "")) / "Microsoft" / "Edge" / "Application" / "msedge.exe",
    ]
    w, h, _ = _window_dimensions()
    size_arg = f"--window-size={w},{h}"
    for edge in candidates:
        if edge.is_file():
            subprocess.Popen(
                [str(edge), f"--app={url}", size_arg, "--disable-extensions"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            try:
                while True:
                    time.sleep(3600)
            except KeyboardInterrupt:
                return
    raise SystemExit(
        "Instale pywebview (requirements-desktop.txt) ou o Microsoft Edge para abrir a interface dedicada."
    )


if __name__ == "__main__":
    main()
